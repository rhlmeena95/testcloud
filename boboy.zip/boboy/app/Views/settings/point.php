<?= $this->extend('layouts/main'); ?>
<?= $this->section('content'); ?>

<div class="row layout-top-spacing " id="cancel-row">
    <div class="col-2"></div>
    <div class="col-xl-8 col-lg-8 col-sm-8  layout-spacing">
        <div class="widget-content widget-content-area br-6">
            <h1 class="h3 mb-3"><strong><?= $title; ?></strong></h1>
            <form action="<?= base_url('point'); ?>" method="get">
                <?php if (1 == session()->get('branch_id')) : ?>
                    <div class="row">
                        <div class="col-sm-4"></div>
                        <div class="col-sm-8">
                            <div class="input-group">
                                <select class="custom-select" id="branch" name="branch" <?= (1 != session()->get('branch_id')) ? 'disabled' : ''; ?>>
                                    <option value="">-- Pilih Cabang -- </option>
                                    <?php foreach ($Branch as $branch) : ?>
                                        <option value="<?= $branch['branchID']; ?>" <?= ($inputBranch == $branch['branchID']) ? 'selected' : ''; ?>><?= $branch['branch_name']; ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <div class="input-group-append">
                                    <button class="btn btn-primary" type="submit">Lihat Data</button>
                                </div>
                                <div class="input-group-append">
                                    <button type="button" class="btn btn-outline-primary" data-toggle="modal" data-target="#fromCreatePoint">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-plus-square">
                                            <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
                                            <line x1="12" y1="8" x2="12" y2="16"></line>
                                            <line x1="8" y1="12" x2="16" y2="12"></line>
                                        </svg>
                                        Tambah Data Point
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php else : ?>
                    <div class="input-group-append float-right">
                        <button type="button" class="btn btn-outline-primary" data-toggle="modal" data-target="#fromCreatePoint">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-plus-square">
                                <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
                                <line x1="12" y1="8" x2="12" y2="16"></line>
                                <line x1="8" y1="12" x2="16" y2="12"></line>
                            </svg>
                            Tambah Data Point
                        </button>
                    </div>
                <?php endif; ?>
            </form>
            <br>
            <div class="table-responsive">
                <table class="multi-table table table-hover dataTable" style="width:100%">
                    <thead>
                        <tr class="text-center">
                            <th>#</th>
                            <th>Point</th>
                            <th>Nominal Minimal</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="text-center">
                        <?php if ($Point != null) :
                            $i = 1;
                            foreach ($Point as $point) : ?>
                                <tr>
                                    <td><?= $i++; ?></td>
                                    <td><?= $point['point']; ?></td>
                                    <td>Rp. <?= number_format($point['nominal_min']); ?></td>
                                    <td><button class="btn btn-primary btn-sm btnCust" data-toggle="modal" data-target="#formUpdatePoint<?= $point['id']; ?>">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-edit">
                                                <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                                                <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                                            </svg> Ubah
                                        </button>
                                        <form action="<?= base_url('point/delete'); ?>" method="post" class="d-inline">
                                            <input type="hidden" name="pointID" id="pointID" value="<?= $point['id']; ?>">
                                            <input type="hidden" name="_method" value="DELETE">
                                            <button type="submit" class="btn btn-outline-dark btn-sm" onclick="return confirm('Apakah anda yakin untuk menghapus point?')">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-trash-2">
                                                    <polyline points="3 6 5 6 21 6"></polyline>
                                                    <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                                                    <line x1="10" y1="11" x2="10" y2="17"></line>
                                                    <line x1="14" y1="11" x2="14" y2="17"></line>
                                                </svg> Hapus</button>
                                        </form>
                                    </td>
                                    <div class="modal fade" id="formUpdatePoint<?= $point['id']; ?>" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="formUpdatePointLabel" aria-hidden="true">
                                        <div class="modal-dialog modal-sm" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="formUpdatePointLabel">Ubah Data Point</h5>
                                                </div>
                                                <div class="modal-body">
                                                    <form action="<?= base_url('point/update'); ?>" method="post">
                                                        <input type="hidden" id="pointID" name="pointID" value="<?= $point['id']; ?>">
                                                        <div class="form-group">
                                                            <label for="inputPoint">Point</label>
                                                            <div class="input-group mb-5">
                                                                <input type="number" class="form-control" min="0" value="<?= $point['point']; ?>" name="inputPoint" id="inputPoint" required>
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="inputNominal">Nominal Minimal</label>
                                                            <div class="input-group mb-5">
                                                                <div class="input-group-prepend">
                                                                    <span class="input-group-text" id="basic-addon6">Rp</span>
                                                                </div>
                                                                <input type="number" class="form-control" min="0" value="<?= $point['nominal_min']; ?>" name="inputNominalMin" id="inputNominalMin" required>
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="inputNominal">Nominal Maksimal</label>
                                                            <div class="input-group mb-5">
                                                                <div class="input-group-prepend">
                                                                    <span class="input-group-text" id="basic-addon6">Rp</span>
                                                                </div>
                                                                <input type="number" class="form-control" min="0" value="<?= ($point['nominal_max'] != '9999999999') ? $point['nominal_max'] : 'Tidak Ada Maksimal'; ?>" readonly name="inputNominalMax" id="inputNominalMax" required>
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button class="btn" data-dismiss="modal"><i class="flaticon-cancel-12"></i> Kembali</button>
                                                            <button type="submit" class="btn btn-primary">Simpan</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </tr>
                            <?php endforeach; ?>
                        <?php else : ?>
                            <tr>
                                <td colspan="4" class="text-center"> Data Masih Kosong </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="col-2"></div>
</div>

<div class="modal fade" id="fromCreatePoint" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="fromCreatePointLabel" aria-hidden="true">
    <div class="modal-dialog modal-sm" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="fromCreatePointLabel">Buat Data Point</h5>
            </div>
            <div class="modal-body">
                <form action="<?= base_url('point/create'); ?>" method="post">
                    <div class="form-group">
                        <label for="inputPoint">Point</label>
                        <div class="input-group mb-5">
                            <input type="number" class="form-control" min="0" name="inputPoint" id="inputPoint" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="inputNominal">Nominal Minimal</label>
                        <div class="input-group mb-5">
                            <div class="input-group-prepend">
                                <span class="input-group-text" id="basic-addon6">Rp</span>
                            </div>
                            <input type="number" class="form-control" min="0" name="inputNominalMin" id="inputNominalMin" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn" data-dismiss="modal"><i class="flaticon-cancel-12"></i> Kembali</button>
                        <button type="submit" class="btn btn-primary">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection(); ?>