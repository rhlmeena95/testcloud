<?= $this->extend('layouts/main'); ?>
<?= $this->section('content'); ?>
<div class="row layout-top-spacing" id="cancel-row">
    <div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
        <div class="widget-content widget-content-area">
            <div class="text-right">
                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#staticBackdrop">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-plus-circle">
                        <circle cx="12" cy="12" r="10"></circle>
                        <line x1="12" y1="8" x2="12" y2="16"></line>
                        <line x1="8" y1="12" x2="16" y2="12"></line>
                    </svg>
                    Tambah Stok Awal
                </button>
            </div>
            <div class="table-responsive">
                <table class="table table-striped dataTable" style="width:100%">
                    <thead>
                        <tr>
                            <th>Cabang</th>
                            <th>Periode</th>
                            <th>Produk</th>
                            <th>Stok Awal</th>
                            <th>Nominal (Rp)</th>
                            <th class="no-content">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($InitialStock as $initialStock) : ?>
                            <tr>
                                <td><?= $initialStock['branch_name']; ?></td>
                                <td><?= $initialStock['stock_initial_period']; ?></td>
                                <td><?= $initialStock['product_name']; ?></td>
                                <td><?= $initialStock['stock_initial_quantity']; ?></td>
                                <td><?= number_format($initialStock['stock_initial_nominal']); ?></td>
                                <td>
                                    <form action="<?= base_url('initialStock/deleteInitialStock'); ?> " method="post">
                                        <input type="hidden" name="_method" value="DELETE">
                                        <input type="hidden" name="branchID" value="<?= $initialStock['branch_id']; ?>">
                                        <input type="hidden" name="period" value="<?= $initialStock['stock_initial_period']; ?>">
                                        <input type="hidden" name="quantity" value="<?= $initialStock['stock_initial_quantity']; ?>">
                                        <input type="hidden" name="nominal" value="<?= $initialStock['stock_initial_nominal']; ?>">
                                        <input type="hidden" name="productID" value="<?= $initialStock['product_id']; ?>">
                                        <button type="submit" class="btn btn-outline-danger mb-2 mr-2" onclick="return confirm('Anda yakin akan menghapus stok awal <?= $initialStock['product_name']; ?> ?')">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="red" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x-circle table-cancel">
                                                <circle cx="12" cy="12" r="10"></circle>
                                                <line x1="15" y1="9" x2="9" y2="15"></line>
                                                <line x1="9" y1="9" x2="15" y2="15"></line>
                                            </svg>
                                            Hapus
                                        </button>
                                    </form>
                                </td>
                            <?php endforeach; ?>
                            </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="staticBackdrop" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="staticBackdropLabel">Tambah Data Stok Awal</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="<?= base_url('initialStock/createInitialStock'); ?>" method="post">
                <div class="modal-body">
                    <div class="form-group">
                        <label for="period">Periode</label>
                        <input type="number" class="form-control" id="period" name="inputPeriod" value="<?= date('Y'); ?>" readonly>
                    </div>
                    <div class="form-group">
                        <label for="inputBranch">Cabang</label>
                        <select class="form-control" id="inputBranch" name="inputBranch" <?= (1 != session()->get('branch_id')) ? 'disabled' : ''; ?>>
                            <option value="" selected>-- Pilih Cabang --</option>
                            <?php foreach ($Branch as $branch) : ?>
                                <option value="<?= $branch['id']; ?>" <?= ($branch['branchID'] == session()->get('branch_id')) ? 'selected' : ''; ?>><?= $branch['branch_name']; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="inputProduct">Produk</label>
                        <select class="form-control selectpicker" id="inputProduct" name="inputProduct" data-live-search="true">
                            <option value="" selected>-- Pilih Produk --</option>
                            <?php foreach ($Products as $product) : ?>
                                <option value="<?= $product['productID']; ?>"><?= $product['product_sku']; ?> - <?= $product['product_name']; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="inputQuantity">Jumlah Stok Awal</label>
                        <input type="number" min="0" class="form-control" id="inputQuantity" name="inputQuantity" placeholder="0" required>
                    </div>
                    <div class="form-group">
                        <label for="inputNominal">Nominal Awal</label>
                        <input type="number" min="0" class="form-control" id="inputNominal" name="inputNominal" placeholder="0" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Simpan Data</button>
                    <button type="button" class="btn btn-light" data-dismiss="modal">Batal</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?= $this->endSection(); ?>