<?php

namespace App\Models;

use CodeIgniter\Model;


class InventoryModel extends Model
{
    public function getInitialStock($InitialStockID = false)
    {
        if ($InitialStockID) {
            return $this->db->table('stock_initial')
                ->join('branch', 'stock_initial.branch_id = branch.id')
                ->join('products', 'stock_initial.product_id = products.id')
                ->where(['stock_initial.id' => $InitialStockID])
                ->get()->getRowArray();
        } else {
            return $this->db->table('stock_initial')
                ->join('branch', 'stock_initial.branch_id = branch.id')
                ->join('products', 'stock_initial.product_id = products.id')
                ->join('product_subdepartment', 'products.product_subdepartment_id = product_subdepartment.product_subdep_code')
                ->where([
                    'branch_id' => session()->get('branch_id'),
                ])
                ->get()->getResultArray();
        }
    }

    public function checkInitialStock($branchID, $period, $productID)
    {
        return $this->db->table('stock_initial')->where([
            'branch_id'             => $branchID,
            'stock_initial_period'  => $period,
            'product_id'            => $productID
        ])->countAllResults();
    }

    public function createInitialStock($dataInitialStock)
    {
        $product            = $this->db->table('products')->getWhere(['id' =>  $dataInitialStock['inputProduct']])->getRowArray();
        $stock              =  $this->db->table('stock_product')->getWhere(['product_id' => $dataInitialStock['inputProduct'], 'branch_id' => session()->get('branch_id')])->getRowArray();
        $calculation        = $product['product_stock'] - $stock['stock_product_qty_new'];
        $totalStock         = $calculation + $dataInitialStock['inputQuantity'];
        $totalNominal       = ($product['product_selling_price'] * $product['product_stock']) + $dataInitialStock['inputNominal'];

        $this->db->transBegin();
        $checkBranchStock = $this->db->table('stock_initial')->where([
            'branch_id'                     => session()->get('branch_id'),
            'product_id'                    => $dataInitialStock['inputProduct']
        ])->countAllResults();
        if ($checkBranchStock > 0) {
            $this->db->table('stock_initial')->update([
                'stock_initial_quantity'        => $dataInitialStock['inputQuantity'],
                'stock_initial_nominal'         => $dataInitialStock['inputNominal'],
                'stock_initial_created_by'      => session()->get('user_id'),
                'stock_initial_created_at'      => date('Y-m-d H:i:s')
            ], [
                'branch_id'                     => session()->get('branch_id'),
                'product_id'                    => $dataInitialStock['inputProduct'],
                'stock_initial_period'          => $dataInitialStock['inputPeriod'],
            ]);
        } else {
            $this->db->table('stock_initial')->insert([
                'branch_id'                     => session()->get('branch_id'),
                'product_id'                    => $dataInitialStock['inputProduct'],
                'stock_initial_period'          => $dataInitialStock['inputPeriod'],
                'stock_initial_quantity'        => $dataInitialStock['inputQuantity'],
                'stock_initial_nominal'         => $dataInitialStock['inputNominal'],
                'stock_initial_created_by'      => session()->get('user_id'),
                'stock_initial_created_at'      => date('Y-m-d H:i:s')
            ]);
        }

        $checkBranchStock = $this->db->table('stock_product')->where([
            'branch_id'                     => session()->get('branch_id'),
            'product_id'                    => $dataInitialStock['inputProduct']
        ])->countAllResults();
        if ($checkBranchStock > 0) {
            $this->db->table('stock_product')->update([
                'stock_product_name'       => $product['product_name'],
                'stock_product_qty_new'    => $dataInitialStock['inputQuantity']
            ], [
                'branch_id'                => session()->get('branch_id'),
                'product_id'               => $dataInitialStock['inputProduct']
            ]);
        } else {
            $this->db->table('stock_product')->insert([
                'branch_id'                => session()->get('branch_id'),
                'product_id'               => $dataInitialStock['inputProduct'],
                'stock_product_subdep_id'  => $product['product_subdepartment_id'],
                'stock_product_name'       => $product['product_name'],
                'stock_product_qty_new'    => $dataInitialStock['inputQuantity'],
            ]);
        }

        $this->db->table('products')->update([
            'product_stock'             => $totalStock,
        ], [
            'id'               => $dataInitialStock['inputProduct']
        ]);
        if ($this->db->transStatus() === false) {
            $this->db->transRollback();
            return false;
        } else {
            $this->db->transCommit();
            return true;
        }
    }

    public function deleteInitialStock($dataInitialStock)
    {
        $product            = $this->db->table('products')->getWhere(['id' =>  $dataInitialStock['productID']])->getRowArray();
        $totalProductStock  = $product['product_stock'] - $dataInitialStock['quantity'];
        $totalNominal       = ($product['product_selling_price'] * $product['product_stock']) - $dataInitialStock['nominal'];
        if ($totalNominal != 0 || $totalProductStock != 0) {
            $productPrice   = $totalNominal / $totalProductStock;
        } else {
            $productPrice   = 0;
        }
        $this->db->transBegin();
        $this->db->table('stock_initial')->delete(
            [
                'branch_id'             => $dataInitialStock['branchID'],
                'product_id'            => $dataInitialStock['productID'],
                'stock_initial_period'  => $dataInitialStock['period']
            ]
        );
        $this->db->table('stock_product')->update([
            'stock_product_qty_new'    => 0
        ], [
            'branch_id'                => $dataInitialStock['branchID'],
            'product_id'               => $dataInitialStock['productID']
        ]);
        $this->db->table('products')->update([
            'product_stock'             => $totalProductStock,
            'product_selling_price'             => $productPrice
        ], [
            'id'               => $dataInitialStock['productID']
        ]);
        if ($this->db->transStatus() === false) {
            $this->db->transRollback();
            return false;
        } else {
            $this->db->transCommit();
            return true;
        }
    }
    public function getIntialStockByPeriodProduct($period, $product, $branch)
    {
        if (is_null($period)) {
            return $this->db->table('stock_initial')->getWhere(['stock_initial_period' => $period, 'product_id' => 0])->getRowArray();
        } else {
            return $this->db->table('stock_initial')->getWhere(['stock_initial_period' => $period, 'product_id' => $product, 'branch_id' => $branch])->getRowArray();
        }
    }
    public function getStockCard($productID)
    {
        return $this->db->table('stock_card')->where(['branch_id' => session()->get('branch_id'), 'stock_card.product_id' => $productID])->get()->getResultArray();
    }
    public function getStockCardByBranch($branch, $productID)
    {
        return $this->db->table('stock_card')->where(['branch_id' => $branch, 'stock_card.product_id' => $productID])->get()->getResultArray();
    }
    public function checkStock($productID, $purchaseID)
    {
        return $this->db->table('stock_card')
            ->where(['purchase_id' => $purchaseID, 'product_id' => $productID])
            ->get()->getRowArray();
    }
    public function getStockTransfer($stockTransferID = false,)
    {
        if ($stockTransferID) {
            return $this->db->table('stock_transfer')
                ->select('*, stock_transfer.id AS stockTransferID, branch.id AS branchID')
                ->join('employee', 'stock_transfer.request_by = employee.id')
                ->join('branch', 'stock_transfer.branch_destination = branch.id')
                ->getWhere([
                    'stock_transfer.id'     => $stockTransferID
                ])->getRowArray();
        } else {
            return $this->db->table('stock_transfer')
                ->select('*, stock_transfer.id AS stockTransferID, branch.id AS branchID')
                ->join('employee', 'stock_transfer.request_by = employee.id')
                ->join('branch', 'stock_transfer.branch_destination = branch.id')
                ->getWhere([
                    'branch_origin'         => session()->get('branch_id'),
                ])->getResultArray();
        }
    }
    public function getStockTransferRequest($stockTransferID = false)
    {
        return $this->db->table('stock_transfer')
            ->select('*, stock_transfer.id AS stockTransferID, branch.id AS branchID')
            ->join('employee', 'stock_transfer.request_by = employee.id')
            ->join('branch', 'stock_transfer.branch_destination, stock_transfer.branch_origin = branch.id')
            ->getWhere([
                'stock_transfer.id'      => $stockTransferID,
            ])->getRowArray();
    }
    public function getStockTransferByBranchDestination($branch = false)
    {
        if ($branch) {
            return $this->db->table('stock_transfer')
                ->select('*, stock_transfer.id AS stockTransferID, branch.id AS branchID')
                ->join('employee', 'stock_transfer.request_by = employee.id')
                ->join('branch', 'stock_transfer.branch_origin = branch.id')
                ->orderBy('request_at', 'DESC')
                ->getWhere([
                    'branch_destination'    => $branch
                ])->getResultArray();
        }
        return $this->db->table('stock_transfer')
            ->select('*, stock_transfer.id AS stockTransferID, branch.id AS branchID')
            ->join('employee', 'stock_transfer.request_by = employee.id')
            ->join('branch', 'stock_transfer.branch_origin = branch.id')
            ->orderBy('request_at', 'DESC')
            ->getWhere([
                'branch_destination'    => session()->get('branch_id')
            ])->getResultArray();
    }
    public function getStockTransferByBranchOrigin($branch = null)
    {
        if ($branch) {
            return $this->db->table('stock_transfer')
                ->select('*, stock_transfer.id AS stockTransferID, branch.id AS branchID')
                ->join('employee', 'stock_transfer.request_by = employee.id')
                ->join('branch', 'stock_transfer.branch_destination = branch.id')
                ->orderBy('request_at', 'DESC')
                ->getWhere([
                    'branch_origin' => $branch,
                ])->getResultArray();
        }
        return $this->db->table('stock_transfer')
            ->select('*, stock_transfer.id AS stockTransferID, branch.id AS branchID')
            ->join('employee', 'stock_transfer.request_by = employee.id')
            ->join('branch', 'stock_transfer.branch_destination = branch.id')
            ->orderBy('request_at', 'DESC')
            ->getWhere([
                'branch_origin'         => session()->get('branch_id'),
            ])->getResultArray();
    }

    public function getStockTransferProduct($stockTransferProduct)
    {
        return $this->db->table('stock_transfer_product')->where(['stock_transfer_id' => $stockTransferProduct])->get()->getResultArray();
    }
    public function getStockTransferProductbyProduct($stockTransferProduct)
    {
        return $this->db->table('stock_transfer_product')->where(['id' => $stockTransferProduct])->get()->getRowArray();
    }
    public function createStockTransfer($RequestData, $RequestProduct)
    {
        if ($RequestData['inputBranch'] == "-- Pilih Cabang -- ") {
            return false;
        } else {
            $this->db->transBegin();
            # Insert data pembelian
            $idStockTransfer = random_string('alnum', 5);
            if ($RequestData && $RequestProduct != null) {
                $this->db->table('stock_transfer')->insert([
                    'id'                            => $idStockTransfer,
                    'branch_origin'                 => session()->get('branch_id'),
                    'branch_destination'            => $RequestData['inputBranch'],
                    'status'                        => 1,
                    'request_by'                    => session()->get('user_id'),
                    'request_at'                    => date('Y-m-d H:i:s')
                ]);

                # Looping jumlah data produk di keranjang
                foreach ($RequestProduct as $product) {
                    $per                = str_replace(" per ", "/", $product['name']);
                    $perdua             = str_replace(" perdua ", "/", $per);
                    $and                = str_replace(" dan ", "+", $perdua);
                    $dandua             = str_replace(" dan2 ", "&", $and);
                    $petikdua           = str_replace(" petikdua ", '"', $dandua);
                    $petik              = str_replace(" petik ", "'", $petikdua);
                    $titikdua           = str_replace(" titikdua ", ":", $petik);
                    $garis              = str_replace(" garis ", "|", $titikdua);
                    $petikbalik         = str_replace(" petikbalik ", "`", $garis);
                    $bebas              = str_replace(" bebas ", "~", $petikbalik);
                    $strip              = str_replace(" strip ", "-", $bebas);
                    $open               = str_replace(" kurungbuka ", "(", $strip);
                    $name               = str_replace(" kurungtutup ", ")", $open);

                    # Insert data produk pembelian
                    $this->db->table('stock_transfer_product')->insert([
                        'stock_transfer_id'                 => $idStockTransfer,
                        'product_id'                        => $product['id'],
                        'stock_transfer_product_name'       => $name,
                        'stock_transfer_product_quantity'   => $product['qty'],
                        'stock_order_price_product'         => $product['price']
                    ]);
                    $productStockTransfer   = $this->db->table('stock_product')->getWhere(['branch_id' => session()->get('branch_id'), 'product_id' => $product['id']])->getRowArray();
                    $newStockProduct      = $productStockTransfer['stock_product_qty_new'] -  $product['qty'];
                    if ($newStockProduct <= 0) {
                        $newStockProduct = 0;
                    }
                    $productstock            = $this->db->table('products')->getWhere(['id' =>  $product['id']])->getRowArray();
                    $stock  = $productstock['product_stock'] -  $productStockTransfer['stock_product_qty_new'];
                    if ($stock <= 0) {
                        $stock = 0;
                    }
                    $newStock = $stock +  $newStockProduct;
                    if ($newStock <= 0) {
                        $newStock = 0;
                    }
                    $this->db->table('products')->update(['product_stock' => $newStock, 'product_updated_at' => date('Y-m-d H:i:s')], ['id' => $product['id']]);

                    $this->db->table('stock_product')->update(['stock_product_qty_new' => $newStockProduct], ['branch_id' => session()->get('branch_id'), 'product_id' => $product['id']]);
                    # insert data product di tabel stock_card cabang yang member
                    $branchName = $this->db->table('branch')->getWhere(['id' => $RequestData['inputBranch']])->getRowArray();
                    $this->db->table('stock_card')->insert([
                        'branch_id'                 => session()->get('branch_id'),
                        'product_id'                => $product['id'],
                        'sales_id'                  => 'Transfer Stok Ke ' . $branchName['branch_name'],
                        'stock_card_outcome'        => $product['qty'],
                        'stock_card_created_at'     => date('Y-m-d H:i:s'),
                        'stock_card_total'          => $newStockProduct
                    ]);
                }
                if ($this->db->transStatus() === false) {
                    $this->db->transRollback();
                    return false;
                } else {
                    $this->db->transCommit();
                    return $idStockTransfer;
                }
            } else {
                $this->db->transRollback();
                return false;
            }
        }
    }
    public function updateStatusStockTransferReq($stockTransferProduct, $stockTransfer, $ProductReceive)
    {
        $this->db->transBegin();
        if ($stockTransferProduct && $stockTransfer && $ProductReceive != null) {
            if ($ProductReceive == $stockTransferProduct['stock_transfer_product_quantity']) {
                #Update Produk Yang Diterima
                $this->db->table('stock_transfer_product')->update([
                    'stock_transfer_product_receive' => $ProductReceive,
                    'stock_order_price_product'     => $stockTransferProduct['stock_order_price_product']
                ], ['product_id' => $stockTransferProduct['product_id'], 'stock_transfer_id' => $stockTransferProduct['stock_transfer_id']]);

                $period = date('Y');
                $initialStockCheck = $this->db->table('stock_initial')->getWhere(['branch_id' => $stockTransfer['branch_destination'], 'stock_initial_period' => $period, 'product_id' => $stockTransferProduct['product_id']])->getRowArray();
                if ($initialStockCheck == null) {
                    $this->db->table('stock_initial')->insert([
                        'branch_id'                     => $stockTransfer['branch_destination'],
                        'product_id'                    => $stockTransferProduct['product_id'],
                        'stock_initial_period'          => $period,
                        'stock_initial_quantity'        => $ProductReceive,
                        'stock_initial_nominal'         => 0,
                        'stock_initial_created_by'      => session()->get('user_id'),
                        'stock_initial_created_at'      => date('Y-m-d H:i:s')
                    ]);
                }
                $productStockTransfer   = $this->db->table('stock_product')->getWhere(['branch_id' => session()->get('branch_id'), 'product_id' => $stockTransferProduct['product_id']])->getRowArray();
                $product    = $this->db->table('products')->getWhere(['id' =>  $stockTransferProduct['product_id']])->getRowArray();
                if ($productStockTransfer == null) {
                    $newStockProduct      = $ProductReceive;
                    $this->db->table('stock_product')->insert([
                        'branch_id'                 => session()->get('branch_id'),
                        'product_id'                => $stockTransferProduct['product_id'],
                        'stock_product_subdep_id'   => $product['product_subdepartment_id'],
                        'stock_product_name'        => $stockTransferProduct['stock_transfer_product_name'],
                        'stock_product_qty_new'     => $newStockProduct,
                        'stock_product_price'       => $stockTransferProduct['stock_order_price_product']
                    ]);
                } else {
                    $newStockProduct      = $productStockTransfer['stock_product_qty_new'] + $ProductReceive;
                    if ($newStockProduct <=  0) {
                        $newStockProduct = 0;
                    }
                    $this->db->table('stock_product')->update(['stock_product_qty_new' => $newStockProduct], ['branch_id' => $stockTransfer['branch_destination'], 'product_id' => $stockTransferProduct['product_id']]);
                }
                $branchName = $this->db->table('branch')->getWhere(['id' => $stockTransfer['branch_origin']])->getRowArray();
                $stock   = $product['product_stock'] + $productStockTransfer['stock_product_qty_new'];
                if ($stock <= 0) {
                    $stock = 0;
                }
                $newStock = $stock + $newStockProduct;
                $this->db->table('products')->update(['product_stock' => $newStock, 'product_updated_at' => date('Y-m-d H:i:s')], ['id' => $stockTransferProduct['product_id']]);

                # Insert data product di tabel stock_card cabang yang menerima
                $stockCardID =  $this->db->table('stock_card')->where(['branch_id' => session()->get('branch_id'), 'product_id' => $stockTransferProduct['product_id']])->selectMax('id')->get()->getRowArray();

                $this->db->table('stock_card')->insert([
                    'branch_id'                 => $stockTransfer['branch_destination'],
                    'product_id'                => $stockTransferProduct['product_id'],
                    'purchase_id'               => 'Menerima Stok dari ' . $branchName['branch_name'],
                    'stock_card_income'         => $ProductReceive,
                    'stock_card_created_at'     => date('Y-m-d H:i:s'),
                    'stock_card_total'          => $newStockProduct
                ]);
            } else {
                $this->db->transRollback();
                return 'Kosong';
            }

            if ($this->db->transStatus() === false) {
                $this->db->transRollback();
                return false;
            } else {
                $this->db->transCommit();
                return true;
            }
        } else {
            $this->db->transRollback();
            return false;
        }
    }
    public function updateStatusStockTransferConfirm($stockTransferStatus, $stockTransferID)
    {
        #Update Status Stock Transfer
        return $this->db->table('stock_transfer')->update([
            'status'           => $stockTransferStatus,
            'shipped_by'        => session()->get('user_id'),
            'shipped_at'        => date('Y-m-d H:i:s')
        ], ['branch_destination' => session()->get('branch_id'), 'id' => $stockTransferID]);
    }
    public function updateStatusStockTransfer($stockTransfer, $stockTransferStatus)
    {
        return $this->db->table('stock_transfer')->update([
            'status'            => $stockTransferStatus,
            'received_by'        => session()->get('user_id'),
            'received_at'        => date('Y-m-d H:i:s')
        ], ['id' => $stockTransfer]);
    }
    public function getProductStockOpname($branch = false)
    {
        if ($branch) {
            return $this->db->table('stock_opname')
                ->select('*, products.id AS productID')
                ->join('products', 'stock_opname.stock_opname_product_id = products.id')
                ->join('product_subdepartment', 'products.product_subdepartment_id = product_subdepartment.product_subdep_code')
                ->orderBy('product_subdep_name')
                ->where(['stock_opname_branch_id' => $branch])
                ->get()->getRowArray();
        }
        return $this->db->table('stock_opname')
            ->select('*, products.id AS productID')
            ->join('products', 'stock_opname.stock_opname_product_id = products.id')
            ->join('product_subdepartment', 'products.product_subdepartment_id = product_subdepartment.product_subdep_code')
            ->orderBy('product_subdep_name')
            ->where(['stock_opname_branch_id' => session()->get('branch_id')])
            ->get()->getRowArray();
    }
    public function getStockOpname($branch = false)
    {
        if ($branch) {
            return $this->db->table('stock_opname')
                ->select('*, products.id AS productID')
                ->join('products', 'stock_opname.stock_opname_product_id = products.id')
                ->join('product_subdepartment', 'products.product_subdepartment_id = product_subdepartment.product_subdep_code')
                ->orderBy('product_subdep_name')
                ->where(['stock_opname_branch_id' => $branch])
                ->get()->getResultArray();
        } else {
            return $this->db->table('stock_opname')
                ->join('products', 'stock_opname.stock_opname_product_id = products.id')
                ->join('product_subdepartment', 'products.product_subdepartment_id = product_subdepartment.product_subdep_code')
                ->orderBy('product_subdep_name')
                ->where(['stock_opname_branch_id' => session()->get('branch_id')])
                ->get()->getResultArray();
        }
    }
    public function getStockProduct($Branch = false)
    {
        if ($Branch) {
            return $this->db->table('stock_product')
                ->join('branch', 'stock_product.branch_id = branch.id')
                ->join('products', 'stock_product.product_id = products.id')
                ->join('product_subdepartment', 'stock_product.stock_product_subdep_id = product_subdepartment.product_subdep_code')
                ->where(['stock_product.branch_id' => $Branch])
                ->orderBy('product_subdepartment.id', "ASC")
                ->get()->getResultArray();
        }
        return $this->db->table('stock_product')
            ->join('branch', 'stock_product.branch_id = branch.id')
            ->join('products', 'stock_product.product_id = products.id')
            ->join('product_subdepartment', 'stock_product.stock_product_subdep_id = product_subdepartment.product_subdep_code')
            ->where(['stock_product.branch_id' => session()->get('branch_id')])
            ->orderBy('product_subdepartment.id', "ASC")
            ->get()->getResultArray();
    }
    public function getStockProductByBranchandSubdepartment($branch = false, $subdepartment = false)
    {
        if ($branch && $subdepartment) {
            return $this->db->table('stock_product')
                ->join('branch', 'stock_product.branch_id = branch.id')
                ->join('products', 'stock_product.product_id = products.id')
                ->join('product_subdepartment', 'stock_product.stock_product_subdep_id = product_subdepartment.product_subdep_code')
                ->where(['stock_product.branch_id' => $branch, 'stock_product.stock_product_subdep_id' => $subdepartment])
                ->get()->getResultArray();
        }
        return $this->db->table('stock_product')
            ->join('branch', 'stock_product.branch_id = branch.id')
            ->join('products', 'stock_product.product_id = products.id')
            ->join('product_subdepartment', 'stock_product.stock_product_subdep_id = product_subdepartment.product_subdep_code')
            ->where(['stock_product.branch_id' => session()->get('branch_id')])
            ->get()->getResultArray();
    }
    public function getStockProductBysubdepartment($subdepartment)
    {
        return $this->db->table('stock_product')
            ->join('branch', 'stock_product.branch_id = branch.id')
            ->join('products', 'stock_product.product_id = products.id')
            ->join('product_subdepartment', 'stock_product.stock_product_subdep_id = product_subdepartment.product_subdep_code')
            ->where('stock_product.stock_product_qty_new >', 0)
            ->where(['stock_product.branch_id' => session()->get('branch_id'), 'stock_product.stock_product_subdep_id' => $subdepartment])
            ->get()->getResultArray();
    }
    public function checkStockProductStock($productID)
    {
        return $this->db->table('stock_product')
            ->join('branch', 'stock_product.branch_id = branch.id')
            ->join('products', 'stock_product.product_id = products.id')
            ->join('product_subdepartment', 'products.product_subdepartment_id = product_subdepartment.product_subdep_code')
            ->orderBy('product_subdep_name')
            ->where(['branch_id' => session()->get('branch_id'), 'product_id' => $productID])
            ->get()->getRowArray();
    }
    public function getLastUpdateStockOpname($productID)
    {
        return $this->db->table('stock_opname')->getWhere(['stock_opname_product_id' => $productID, 'stock_opname_branch_id' => session()->get('branch_id')])->getResultArray();
    }
    public function saveStockOpname($dataInputStockOpname, $product)
    {
        $this->db->transBegin();
        if ($dataInputStockOpname['param'] == 1) {
            $param = 1;
        } else {
            $param = 0;
        }
        $stockDifference = $dataInputStockOpname['totalstock'] - $dataInputStockOpname['storage'];

        $this->db->table('stock_opname')->insert([
            'stock_opname_product_id'   => $dataInputStockOpname['productId'],
            'stock_opname_branch_id'    => session()->get('branch_id'),
            'stock_opname_product_name' => $product['stock_product_name'],
            'stock_opname_qty'          => $product['stock_product_qty_new'],
            'stock_opname_qty_display'  => 0,
            'stock_opname_qty_storage'  => $dataInputStockOpname['storage'],
            'stock_opname_difference'   => $stockDifference,
            'stock_opname_description'  => $dataInputStockOpname['inputNotes'],
            'stock_opname_is_change'    => $param,
            'stock_opname_created_at'   => date('Y-m-d H:i:s'),
        ]);
        if ($param == 1) {
            $productsStock          = $this->db->table('stock_product')->getWhere(['branch_id' => session()->get('branch_id'), 'product_id' => $dataInputStockOpname['productId']])->getRowArray();
            $newAllProductStock     = $productsStock['stock_product_qty_new'] - $stockDifference;
            if ($newAllProductStock <= 0) {
                $newAllProductStock = 0;
            }
            #update tabel Product
            $products       = $this->db->table('products')->getWhere(['id' => $dataInputStockOpname['productId']])->getRowArray();
            $productsStockBranch1          = $this->db->table('stock_product')->select('stock_product_qty_new')->getWhere(['branch_id' => 1, 'product_id' => $dataInputStockOpname['productId']])->getRowArray();
            $productsStockBranch2          = $this->db->table('stock_product')->select('stock_product_qty_new')->getWhere(['branch_id' => 2, 'product_id' => $dataInputStockOpname['productId']])->getRowArray();
            $productsStockBranch3          = $this->db->table('stock_product')->select('stock_product_qty_new')->getWhere(['branch_id' => 3, 'product_id' => $dataInputStockOpname['productId']])->getRowArray();
            if ($newAllProductStock <= 0) {
                $newAllProductStock = 0;
            }
            if (session()->get('branch_id') == 1) {
                $newAllStock          = $productsStockBranch2['stock_product_qty_new'] + $productsStockBranch3['stock_product_qty_new'] +  $newAllProductStock;
            } elseif (session()->get('branch_id') == 2) {
                $newAllStock          = $productsStockBranch1['stock_product_qty_new'] + $productsStockBranch3['stock_product_qty_new'] +  $newAllProductStock;
            } elseif (session()->get('branch_id') == 3) {
                $newAllStock          = $productsStockBranch1['stock_product_qty_new'] + $productsStockBranch2['stock_product_qty_new'] +  $newAllProductStock;
            }
            if ($newAllStock <= 0) {
                $newAllStock = 0;
            }
            $this->db->table('products')->update(['product_stock' => $newAllStock, 'product_updated_at' => date('Y-m-d H:i:s')], ['id' => $dataInputStockOpname['productId']]);

            #Update Tabel stock_product
            $this->db->table('stock_product')->update(['stock_product_qty_new' => $newAllProductStock], ['branch_id' => session()->get('branch_id'), 'product_id' => $dataInputStockOpname['productId']]);
            $this->db->table('stock_initial')->update(['stock_initial_quantity' => $newAllProductStock, 'stock_initial_updated_at' => date('Y-m-d H:i:s')], ['branch_id' => session()->get('branch_id'), 'product_id' => $dataInputStockOpname['productId']]);
            if ($stockDifference > 0) {
                $this->db->table('stock_card')->insert([
                    'branch_id'                 => session()->get('branch_id'),
                    'product_id'                => $dataInputStockOpname['productId'],
                    'sales_id'                  => 'Selisih Stock Opname',
                    'stock_card_outcome'        => $stockDifference,
                    'stock_card_outcome_nominal' => '0',
                    'stock_card_created_at'     => date('Y-m-d H:i:s'),
                    'stock_card_total'          => $newAllProductStock
                ]);
            } else {
                $this->db->table('stock_card')->insert([
                    'branch_id'                 => session()->get('branch_id'),
                    'product_id'                => $dataInputStockOpname['productId'],
                    'purchase_id'               => 'Selisih Stock Opname',
                    'stock_card_income'         => $stockDifference,
                    'stock_card_income_nominal' => '0',
                    'stock_card_created_at'     => date('Y-m-d H:i:s'),
                    'stock_card_total'          => $newAllProductStock
                ]);
            }
        }

        if ($this->db->transStatus() === false) {
            $this->db->transRollback();
            return false;
        } else {
            $this->db->transCommit();
            return true;
        }
    }
    public function getOutComeProduct($productID, $branch)
    {
        $getLastID = $this->db->table('stock_card')->where(['branch_id' => $branch, 'product_id' => $productID])->where(['stock_card_outcome >' => 0])->selectMax('id')->get()->getRowArray();
        $outcome = $this->db->table('stock_card')
            ->select('*')
            ->where(['id' => $getLastID])
            ->get()->getRowArray();
        return $outcome['stock_card_outcome'];
    }
}
