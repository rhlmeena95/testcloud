<?php

namespace App\Controllers;

use App\Models\SyncModel;
use App\Models\SalesModel;
use App\Controllers\BaseController;
use App\Models\SyncServerModel;

class Syncronize extends BaseController
{

    function __construct()
    {
        $this->SyncModel = new SyncModel();
        $this->SyncServerModel = new SyncServerModel();
        $this->SalesModel = new SalesModel();
    }
    public function index()
    {
        $data = array_merge($this->data, [
            'category'          => 'Penjualan',
            'title'             => 'Data Singkron',
        ]);
        return view('settings/syncronize', $data);
    }
    public function syncCustomer()
    {
        set_time_limit(0);
        $param = $this->request->getGet('id');
        if ($param) {
            $syncCustomer = $this->SyncServerModel->syncCustomer();
        } else {
            $syncCustomer = $this->SyncModel->syncCustomer();
        }
        if ($syncCustomer) {
            if ($param) {
                session()->setFlashdata('notif_success', '<b>Berhasil Download Data Server</b>');
            } else {
                session()->setFlashdata('notif_success', '<b>Berhasil di upload</b>');
            }
            $this->cart->destroy();
            return redirect()->to(base_url('sync'));
        } else {
            session()->setFlashdata('notif_error', '<b>Gagal upload data, Kecepetan internet anda kurang stabil</b>');
            return redirect()->to(base_url('sync'));
        }
    }
    public function syncProduct()
    {
        set_time_limit(0);
        $param = $this->request->getGet('id');
        if ($param == 1) {
            $syncProduct = $this->SyncServerModel->syncProduct();
        } elseif ($param == 2) {
            $syncProduct = $this->SyncModel->downloadDataStockServer();
        } else {
            $syncProduct = $this->SyncModel->syncProduct();
        }
        if ($syncProduct == true) {
            if ($param == 1) {
                session()->setFlashdata('notif_success', '<b>Berhasil Download Data Server</b>');
            } elseif ($param == 2) {
                session()->setFlashdata('notif_success', '<b>Berhasil Download Data Stock Server</b>');
            } else {
                session()->setFlashdata('notif_success', '<b>Berhasil di upload</b>');
            }
            $this->cart->destroy();
            return redirect()->to(base_url('sync'));
        } elseif ($syncProduct == 'product') {
            session()->setFlashdata('notif_error', '<b>Gagal upload data. data product server belum terdownload</b>');
            return redirect()->to(base_url('sync'));
        } else {
            if ($param == 1) {
                session()->setFlashdata('notif_error', '<b>Gagal download data server</b>');
            } elseif ($param == 2) {
                session()->setFlashdata('notif_error', '<b>Gagal dowwnload data stock server</b>');
            } else {
                session()->setFlashdata('notif_error', '<b>Gagal upload data, Kecepetan internet anda kurang stabil</b>');
            }
            return redirect()->to(base_url('sync'));
        }
    }
    public function syncProductCategory()
    {
        set_time_limit(0);
        $param = $this->request->getGet('id');
        if ($param) {
            $syncProductCategory = $this->SyncServerModel->syncProductCategory();
        } else {
            $syncProductCategory = $this->SyncModel->syncProductCategory();
        }
        if ($syncProductCategory) {
            if ($param) {
                session()->setFlashdata('notif_success', '<b>Berhasil Download Data Server</b>');
            } else {
                session()->setFlashdata('notif_success', '<b>Berhasil di upload</b>');
            }
            $this->cart->destroy();
            return redirect()->to(base_url('sync'));
        } else {
            session()->setFlashdata('notif_error', '<b>Gagal upload data, Kecepetan internet anda kurang stabil</b>');
            return redirect()->to(base_url('sync'));
        }
    }
    public function syncSalesOrder()
    {
        set_time_limit(0);
        $syncSalesOrder = $this->SyncModel->syncSalesOrder();
        if ($syncSalesOrder === true) {
            session()->setFlashdata('notif_success', '<b>Berhasil di upload</b>');
            $this->cart->destroy();
            return redirect()->to(base_url('sync'));
        } else if ($syncSalesOrder === "Employee") {
            session()->setFlashdata('notif_error', '<b>Gagal upload data, Data pegawai belum di upload</b>');
            return redirect()->to(base_url('sync'));
        } else if ($syncSalesOrder === "Customer") {
            session()->setFlashdata('notif_error', '<b>Gagal upload data, Data Customer belum di upload</b>');
            return redirect()->to(base_url('sync'));
        } elseif ($syncSalesOrder == "product") {
            session()->setFlashdata('notif_error', '<b>Gagal upload data, Data produk belum di upload</b>');
            return redirect()->to(base_url('sync'));
        } else {
            session()->setFlashdata('notif_error', '<b>Gagal upload data, Kecepetan internet anda kurang stabil</b>');
            return redirect()->to(base_url('sync'));
        }
    }
    public function syncEmployee()
    {
        set_time_limit(0);
        $param = $this->request->getGet('id');
        if ($param) {
            $syncEmployee = $this->SyncServerModel->syncEmployee();
        } else {
            $syncEmployee = $this->SyncModel->syncEmployee();
        }
        if ($syncEmployee) {
            if ($param) {
                session()->setFlashdata('notif_success', '<b>Berhasil Download Data Server</b>');
            } else {
                session()->setFlashdata('notif_success', '<b>Berhasil di upload</b>');
            }
            $this->cart->destroy();
            return redirect()->to(base_url('sync'));
        } else {
            session()->setFlashdata('notif_error', '<b>Gagal upload data, Kecepetan internet anda kurang stabil</b>');
            return redirect()->to(base_url('sync'));
        }
    }
    public function syncStockTransfer()
    {
        set_time_limit(0);
        $param = $this->request->getGet('id');
        if ($param) {
            $syncStockTransfer = $this->SyncServerModel->syncStockTransfer();
        } else {
            $syncStockTransfer = $this->SyncModel->syncStockTransfer();
        }
        if ($syncStockTransfer === true) {
            if ($param) {
                session()->setFlashdata('notif_success', '<b>Berhasil Download Data Server</b>');
            } else {
                session()->setFlashdata('notif_success', '<b>Berhasil di upload</b>');
            }
            $this->cart->destroy();
            return redirect()->to(base_url('sync'));
        } elseif ($syncStockTransfer === 'employee') {
            session()->setFlashdata('notif_error', '<b>Download data karyawan terlebih dahulu</b>');
            return redirect()->to(base_url('sync'));
        } else {
            session()->setFlashdata('notif_error', '<b>Gagal upload data, Kecepetan internet anda kurang stabil</b>');
            return redirect()->to(base_url('sync'));
        }
    }

    public function syncStockOpname()
    {
        set_time_limit(0);
        $param = $this->request->getGet('id');
        if ($param) {
            $syncStockOpname = $this->SyncServerModel->syncStockOpname();
        } else {
            $syncStockOpname = $this->SyncModel->syncStockOpname();
        }
        if ($syncStockOpname === true) {
            if ($param) {
                session()->setFlashdata('notif_success', '<b>Berhasil Download Data Server</b>');
            } else {
                session()->setFlashdata('notif_success', '<b>Berhasil di upload</b>');
            }
            $this->cart->destroy();
            return redirect()->to(base_url('sync'));
        } else {
            session()->setFlashdata('notif_error', '<b>Gagal upload data, Kecepetan internet anda kurang stabil</b>');
            return redirect()->to(base_url('sync'));
        }
    }
    public function syncPurchaseOrder()
    {
        set_time_limit(0);
        $param = $this->request->getGet('id');
        if ($param) {
            $syncPurchaseOrder = $this->SyncServerModel->syncPurchaseOrder();
        } else {
            $syncPurchaseOrder = $this->SyncModel->syncPurchaseOrder();
        }
        if ($syncPurchaseOrder === true) {
            if ($param) {
                session()->setFlashdata('notif_success', '<b>Berhasil Download Data Server</b>');
            } else {
                session()->setFlashdata('notif_success', '<b>Berhasil di upload</b>');
            }
            $this->cart->destroy();
            return redirect()->to(base_url('sync'));
        } elseif ($syncPurchaseOrder === 'created') {
            session()->setFlashdata('notif_error', '<b>Download data karyawan terlebih dahulu</b>');
            return redirect()->to(base_url('sync'));
        } elseif ($syncPurchaseOrder === 'returned') {
            session()->setFlashdata('notif_error', '<b>Download data karyawan terlebih dahulu</b>');
            return redirect()->to(base_url('sync'));
        } else {
            session()->setFlashdata('notif_error', '<b>Gagal upload data, Kecepetan internet anda kurang stabil</b>');
            return redirect()->to(base_url('sync'));
        }
    }
}
