<?= $this->extend('layouts/main'); ?>
<?= $this->section('content'); ?>

<div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
    <div class="widget-content widget-content-area br-6">
        <div class="card-header">
            <h3>
                Form Registrasi Pelanggan/Member
            </h3>
        </div>
        <div class="card component-card_3 my-3">
            <div class="card-body">
                <form action="<?= base_url('customers/saveCustomers'); ?>" method="post">
                    <!-- <div class="row">
                        <div class="col-8">
                            <div class="form-group">
                                <label for="inputBranchId">Cabang</label>
                                <select name="inputBranchId" id="inputBranchId" class="form-control" required <./?= (1 != session()->get('branch_id')) ? 'disabled' : ''; ?>>
                                    <option>-- Pilih Cabang --</option>
                                    </?php foreach ($Branch as $branch) : ?>
                                        <option value="</?= $branch['id']; ?>" <./?= ($branch['branchID'] == session()->get('branch_id')) ? 'selected' : ''; ?>></?= $branch['branch_name']; ?></option>
                                    <.?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                    </div> -->
                    <div class="form-group">
                        <label for="inputCustomerFullname">Nama Lengkap Pelanggan</label>
                        <input type="text" class="form-control" name="inputCustomerFullname" id="inputCustomerFullname" required>
                    </div>
                    <div class="row">
                        <div class="col-4">
                            <div class="form-group">
                                <label for="inputCustomerBirthday">Tanggal lahir Pelanggan</label>
                                <input type="text" class="form-control flatpickr flatpickr-input basicFlatpickr active" name="inputCustomerBirthday" id="inputCustomerBirthday" required>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="form-group">
                                <label for="inputCustomerTelephone">Nomor Telepon Pelanggan</label>
                                <input type="text" class="form-control" name="inputCustomerTelephone" id="inputCustomerTelephone" required>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="form-group">
                                <label for="inputCustomerEmail">Email Pelanggan</label>
                                <input type="text" class="form-control" name="inputCustomerEmail" id="inputCustomerEmail" required>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="inputCustomerAddress">Alamat</label>
                        <textarea class="form-control" id="inputCustomerAddress" name="inputCustomerAddress"></textarea>
                    </div>
                    <div class="row">
                        <div class="col-4">
                            <div class="form-group Province">
                                <label for="inputCustomerProvince">Provinsi</label>
                                <select id="Province" name="inputCustomerProvince" class="form-control selectpicker provinceID" data-live-search="true" required>
                                    <option selected>Pilih Provinsi...</option>
                                    <?php foreach ($Province as $province) : ?>
                                        <option value="<?= $province['id']; ?>"><?= $province['province_name']; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-4" id="form_City">
                            <div class="form-group">
                                <label for="inputCustomerCity">Kabupaten/Kota</label>
                                <select id="city" name="inputCustomerCity" class="form-control " required>
                                    <option selected>Pilih Kabupaten/Kota...</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-4" id="form_Subdistrict">
                            <div class="form-group">
                                <label for="inputCustomerSubdistrict">Kecamatan</label>
                                <select id="subdistrict" name="inputCustomerSubdistrict" class="form-control" required>
                                    <option selected>Pilih Kecamatan...</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <!-- <div class="row">
                        <div class="col-6">
                            <div class="form-group">
                                <label for="inputCustomerStartEffective">Member Berlaku Mulai</label>
                                <input type="text" class="form-control flatpickr flatpickr-input basicFlatpickr active" name="inputCustomerStartEffective" id="inputCustomerStartEffective" required>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label for="inputCustomerEndEffective">Member Berlaku Hingga</label>
                                <input type="text" class="form-control flatpickr flatpickr-input basicFlatpickr active" name="inputCustomerEndEffective" id="inputCustomerEndEffective" required>
                            </div>
                        </div>
                    </div> -->
                    <div class="row">
                        <div class="col-7">
                            <div class="form-group">
                                <label for="inputCustomerIsActive">Status Member</label>
                                <select class="form-control" id="inputCustomerIsActive" name="inputCustomerIsActive">
                                    <option>Pilih Status Pelanggan....</option>
                                    <option value="1">Aktif</option>
                                    <option value="0">Tidak Aktif</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <hr>
                    <div class="d-grid gap-2 mt-3 float-right">
                        <a href="<?= base_url('cashier'); ?>" class="btn btn-dark d-inline">Kembali ke Kasir</a>
                        <button class="btn btn-primary" type="submit" value="1" name="inputan">Simpan Data </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        $('.Province').on('change', ".provinceID", function() {
            const provinsi = $("#Province").val();
            // // console.log(provinsi);
            $.ajax({
                url: "<?= base_url('customers/getCity'); ?>",
                method: "POST",
                type: 'JSON',
                data: {
                    province: provinsi,
                },
                success: function(result) {
                    $("#city").html(result);
                }
            });
        });
        $('#form_City').on('change', "#city", function() {
            const kota = $("#city").val();
            // // console.log(kota);
            $.ajax({
                url: "<?= base_url('customers/getSubdistrict'); ?>",
                method: "POST",
                type: 'JSON',
                data: {
                    city: kota,
                },
                success: function(result) {
                    $("#subdistrict").html(result);
                }
            });
        });
    });
</script>
<?= $this->endSection(); ?>