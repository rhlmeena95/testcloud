<?php

namespace App\Models;

use CodeIgniter\Model;

class EmployeeModel extends Model
{
    public function getAttendance($branch,  $month)
    {
        if ($branch && $month) {
            return $this->db->table('transaction')
                ->select('*, transaction.branch AS transactionBranch, transaction.id AS transactionID,branch.id AS branchID')
                ->join('users', 'transaction.opening_by = users.id')
                ->join('branch', 'transaction.branch = branch.id')
                ->where(['transaction.branch' => $branch, 'MONTH(opening_at)' => short_bulan($month)])
                ->orderBy('opening_at', 'DESC')
                ->get()->getResultArray();
        }
    }
    public function getAttandanceByMonth($month)
    {
        return $this->db->table('transaction')
            ->select('*, transaction.branch AS transactionBranch, transaction.id AS transactionID, branch.id AS branchID')
            ->join('users', 'transaction.opening_by = users.id')
            ->join('branch', 'transaction.branch = branch.id')
            ->where(['transaction.branch' => session()->get('branch_id'), 'MONTH(opening_at)' => short_bulan($month)])
            ->get()->getResultArray();
    }
    public function getEmployee($EmployeeNIP = false)
    {
        if ($EmployeeNIP) {
            return $this->db->table('employee')
                ->select('*, employee.id AS employeeID, employee.nip AS employeeNIP, branch.id AS branchID, users.id AS usersID')
                ->join('users', 'employee.nip = users.nip')
                ->join('user_role', 'users.role = user_role.id')
                ->join('branch', 'users.branch = branch.id')
                ->where(['employee.nip' => $EmployeeNIP])
                ->get()->getRowArray();
        } else {
            return $this->db->table('employee')
                ->select('*, employee.id AS employeeID, employee.nip AS employeeNIP, branch.id AS branchID, users.id AS usersID')
                ->join('users', 'employee.nip = users.nip')
                ->join('user_role', 'users.role = user_role.id')
                ->join('branch', 'users.branch = branch.id')
                ->get()->getResultArray();
        }
    }
    public function getEmployeeById($Employeeid)
    {
        $user = $this->db->table('users')->getWhere(['id' => $Employeeid])->getRowArray();
        return $this->db->table('employee')->where(['employee.nip' => $user['nip']])->get()->getRowArray();
    }
    public function getEmployeeByBranch($branchID = false)
    {
        if ($branchID) {
            return $this->db->table('employee')
                ->select('*, employee.id AS employeeID, employee.nip AS employeeNIP, branch.id AS branchID, users.id AS usersID')
                ->join('users', 'employee.nip = users.nip')
                ->join('user_role', 'users.role = user_role.id')
                ->join('branch', 'users.branch = branch.id')
                ->where([' branch.id' => $branchID])
                ->get()->getResultArray();
        } else {
            return $this->db->table('employee')
                ->select('*, employee.id AS employeeID, employee.nip AS employeeNIP, branch.id AS branchID, users.id AS usersID')
                ->join('users', 'employee.nip = users.nip')
                ->join('user_role', 'users.role = user_role.id')
                ->join('branch', 'users.branch = branch.id')
                ->where([' branch.id' => session()->get('branch_id')])
                ->get()->getResultArray();
        }
    }
    public function createEmployee($dataEmployee)
    {
        $branchCode = $dataEmployee['inputEmployeeBranch'];
        $date = date('ymd');
        $getId = $this->db->table('employee')->selectMax('employee.id')->get()->getRowArray();
        if ($getId['id'] != null) {
            $nip = $getId['id'] + 1;
            $nipnumber = sprintf("%03s", $nip);
        } else {
            $nipnumber = 001;
        }

        $this->db->transBegin();
        $this->db->table('employee')->insert([
            'nip'                       => $date . $branchCode . $nipnumber,
            'employee_name'             => $dataEmployee['inputEmployeeName'],
            'employee_address'          => $dataEmployee['inputEmployeeAddress'],
            'employee_province_id'      => $dataEmployee['inputProvince'],
            'employee_city_id'          => $dataEmployee['inputCity'],
            'employee_subdistrict_id'   => $dataEmployee['inputSubdistrict'],
            'employee_telephone'        => $dataEmployee['inputEmployeeTelephone'],
            'employee_created_at'       => date('Y-m-d H:i;s'),
        ]);
        $this->db->table('users')->insert([
            'nip'                   => $date . $branchCode . $nipnumber,
            'fullname'              => $dataEmployee['inputEmployeeName'],
            'username'              => $dataEmployee['inputUsername'],
            'password'              => password_hash($dataEmployee['inputPassword'], PASSWORD_DEFAULT),
            'role'                  => $dataEmployee['inputEmployeeRole'],
            'branch'                => $dataEmployee['inputEmployeeBranch'],
            'created_at'            => date('Y-m-d H:i;s'),
        ]);
        if ($this->db->transStatus() === false) {
            $this->db->transRollback();
            return false;
        } else {
            $this->db->transCommit();
            return true;
        }
    }
    public function updateEmployee($dataEmployee)
    {
        $this->db->transBegin();
        $this->db->table('employee')->update([
            'employee_name'             => $dataEmployee['inputEmployeeName'],
            'employee_address'          => $dataEmployee['inputEmployeeAddress'],
            'employee_province_id'      => $dataEmployee['inputProvince'],
            'employee_city_id'          => $dataEmployee['inputCity'],
            'employee_subdistrict_id'   => $dataEmployee['inputSubdistrict'],
            'employee_telephone'        => $dataEmployee['inputEmployeeTelephone'],
            'employee_updated_at'       => date('Y-m-d H:i;s'),
        ], ['nip' => $dataEmployee['inputNipEmployee']]);
        $this->db->table('users')->update([
            'fullname'              => $dataEmployee['inputEmployeeName'],
            'username'              => $dataEmployee['inputUsername'],
            'password'              => password_hash($dataEmployee['inputPassword'], PASSWORD_DEFAULT),
            'role'                  => $dataEmployee['inputEmployeeRole'],
            'branch'                => $dataEmployee['inputEmployeeBranch'],
            'updated_at'            => date('Y-m-d H:i;s'),
        ], ['nip' => $dataEmployee['inputNipEmployee']]);
        if ($this->db->transStatus() === false) {
            $this->db->transRollback();
            return false;
        } else {
            $this->db->transCommit();
            return true;
        }
    }
    public function deleteEmployee($EmployeeID)
    {
        return $this->db->table('employee')->delete(['id' => $EmployeeID]);
    }



    // public function getShifting()
    // {
    //     return $this->db->table('shift')->where(['shift_branch_id' => session()->get('branch_id')])->get()->getResultArray();
    // }
    // public function getAttandance($EmployeeNIP)
    // {
    //     return $this->db->table('attandance')
    //         ->select('*, employee.id as employeeID, attandance.id as attandanceID, shift.id as ShiftID')
    //         ->join('employee', 'employee.nip = attandance.attandance_nip')
    //         ->join('shift', 'shift.id = attandance.attandance_shift_id')
    //         ->orderBy('attandance_date')
    //         ->where(['attandance_nip' => $EmployeeNIP])->get()->getResultArray();
    // }
    // public function getShiftEmployee($EmployeeNIP, $month)
    // {
    //     return $this->db->table('attandance')
    //         ->select('*, employee.id as employeeID, attandance.id as attandanceID, shift.id as ShiftID')
    //         ->join('employee', 'employee.nip = attandance.attandance_nip')
    //         ->join('shift', 'shift.id = attandance.attandance_shift_id')
    //         ->orderBy('attandance_date')
    //         ->where(['attandance_nip' => $EmployeeNIP, 'MONTH(attandance_date)' => $month])->get()->getResultArray();
    // }
    // public function createShift($dataShifting)
    // {
    //     return $this->db->table('shift')->insert([
    //         'shift_branch_id'           => session()->get('branch_id'),
    //         'shift_name'                => $dataShifting['shiftName'],
    //         'shift_started'             => $dataShifting['started'],
    //         'shift_ended'               => $dataShifting['ended'],
    //         'shift_created_at'          => date('Y-m-d H:i;s')
    //     ]);
    // }
    // public function updateShit($dataShift)
    // {
    //     return $this->db->table('shift')->update([
    //         'shift_branch_id'           => session()->get('branch_id'),
    //         'shift_name'                => $dataShift['shiftName'],
    //         'shift_started'             => $dataShift['started'],
    //         'shift_ended'               => $dataShift['ended'],
    //         'shift_updated_at'          => date('Y-m-d H:i;s')
    //     ], ['id' => $dataShift['idShift']]);
    // }
    // public function createShiftManagement($dataShiftManagement)
    // {
    //     if ($dataShiftManagement != null) {
    //         foreach ($dataShiftManagement as $dataShift) {
    //             $this->db->table('attandance')->insert([
    //                 'attandance_branch_id'      => session()->get('branch_id'),
    //                 'attandance_shift_id'       => $dataShift['inputEmployeeShift'],
    //                 'attandance_nip'            => $dataShift['inputEmployee'],
    //                 'attandance_date'           => $dataShift['inputDateShift'],
    //                 'attandance_created_at'     => date('Y-m-d H:i;s'),
    //             ]);
    //         }
    //         return true;
    //     } else {
    //         return false;
    //     }
    // }

    // public function updateShiftManagement($dataShiftEmployee)
    // {
    //     return  $this->db->table('attandance')->update([
    //         'attandance_branch_id'      => session()->get('branch_id'),
    //         'attandance_shift_id'       => $dataShiftEmployee['inputEmployeeShift'],
    //         'attandance_nip'            => $dataShiftEmployee['inputEmployee'],
    //         'attandance_date'           => $dataShiftEmployee['inputDateShift'],
    //         'attandance_updated_at'     => date('Y-m-d H:i;s')
    //     ], ['id' => $dataShiftEmployee['inputEmployeeID']]);
    // }
    // public function deleteShiftManagement($dataShiftEmployee)
    // {
    //     return $this->db->table('attandance')->delete(['id' => $dataShiftEmployee]);
    // }
}
