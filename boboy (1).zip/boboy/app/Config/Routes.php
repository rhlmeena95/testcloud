<?php

namespace Config;

// Create a new instance of our RouteCollection class.
$routes = Services::routes();

// Load the system's routing file first, so that the app and ENVIRONMENT
// can override as needed.
if (file_exists(SYSTEMPATH . 'Config/Routes.php')) {
	require SYSTEMPATH . 'Config/Routes.php';
}

/**
 * --------------------------------------------------------------------
 * Router Setup
 * --------------------------------------------------------------------
 */
$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('Home');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
$routes->setAutoRoute(true);

/*
 * --------------------------------------------------------------------
 * Route Definitions
 * --------------------------------------------------------------------
 */

// We get a performance increase by specifying the default
// route since we don't have to scan directories.

//Common Routes
$routes->get('/', 'Welcome::index');
$routes->post('GetLogin', 'Welcome::index');
$routes->get('blocked', 'Welcome::forbiddenPage');
$routes->get('register', 'Welcome::register');
$routes->post('register', 'Welcome::registration');
$routes->get('home', 'Common\Dashboard::index');

$routes->get('cart/insertCart', 'Common\Cart::insertCart');
$routes->post('cart/insertCart', 'Common\Cart::insertCart');
$routes->get('cart/loadCart', 'Common\Cart::loadCart');
$routes->get('cart/showCart', 'Common\Cart::showCart');
$routes->post('cart/removeCart', 'Common\Cart::removeCart');
$routes->post('cart/destroyCart', 'Common\Cart::destroyCart');
$routes->get('cart/insertStockCart', 'Common\Cart::insertStockCart');
$routes->post('cart/insertStockCart', 'Common\Cart::insertStockCart');
$routes->get('cart/loadStockCart', 'Common\Cart::loadStockCart');
$routes->get('cart/showStockCart', 'Common\Cart::showStockCart');
$routes->post('cart/removeStockCart', 'Common\Cart::removeStockCart');
$routes->post('cart/destroyStockCart', 'Common\Cart::destroyStockCart');
$routes->get('cart/loadSalesReturnCart', 'Common\Cart::loadSalesReturnCart');
$routes->get('cart/showSalesReturnCart', 'Common\Cart::showSalesReturnCart');
$routes->get('cart/salesReturnCart', 'Common\Cart::salesReturnCart');
$routes->post('cart/showChasierCart', 'Common\Cart::showChasierCart');
$routes->get('cart/insertChasierCart', 'Common\Cart::insertChasierCart');
$routes->post('cart/insertChasierCart', 'Common\Cart::insertChasierCart');
$routes->post('cart/updateCartChasier', 'Common\Cart::updateCashierCart');
$routes->post('cart/updateCartChasierDiscount', 'Common\Cart::updateCashierCartDiscount');
$routes->post('cart/updateCashierCartDiscountMember', 'Common\Cart::updateCashierCartDiscountMember');
$routes->post('cart/updateCashierCartDiscountBonus', 'Common\Cart::updateCashierCartDiscountBonus');
$routes->get('cart/loadChasierCart', 'Common\Cart::loadChasierCart');
$routes->post('cart/destroyChasierCart', 'Common\Cart::destroyChasierCart');
$routes->post('cart/removeCartChasier', 'Common\Cart::removeCartChasier');
$routes->get('cart/continueTransaction', 'Common\Cart::continueTransaction');
$routes->post('cart/continueTransaction', 'Common\Cart::continueTransaction');
$routes->get('cart/searchProduct', 'Common\Cart::searchProduct');
$routes->post('cart/searchProduct', 'Common\Cart::searchProduct');
$routes->post('cart/showChasierCart', 'Common\Cart::showChasierCart');


// Setting Routes

$routes->get('discount', 'Settings\Discount::index');
$routes->post('discount/create', 'Settings\Discount::createDiscount');
$routes->post('discount/update', 'Settings\Discount::updateDiscount');
$routes->post('discount/updateStatus', 'Settings\Discount::updateStatusDiscount');
$routes->get('margin', 'Settings\Margin::index');
$routes->get('voidPeriod', 'Settings\VoidPeriod::index');
$routes->post('voidPeriod/update', 'Settings\VoidPeriod::updateVoidPeriod');
$routes->post('voidPeriod/checkVoidTransaction', 'Settings\VoidPeriod::checkVoidTransaction');
$routes->get('print', 'Sales\SalesOrder::printPreview');
$routes->post('print/save', 'Sales\SalesOrder::savePrint');
$routes->post('print/update', 'Sales\SalesOrder::updatePrintPreview');
$routes->get('point', 'Master\Customers::point');
$routes->post('point/update', 'Master\Customers::updatePoint');
$routes->post('point/create', 'Master\Customers::createPoint');
$routes->delete('point/delete', 'Master\Customers::deletePoint');

//Master Product Category Routes
$routes->get('productCategory', 'Master\Products::index');
$routes->post('productCategory/createProductDivisi', 'Master\Products::createProductDivisi');
$routes->post('productCategory/updateProductDivisi', 'Master\Products::updateProductDivisi');
$routes->delete('productCategory/deleteProductDivisi', 'Master\Products::deleteProductDivisi');
$routes->post('productCategory/createProductDepartment', 'Master\Products::createProductDepartment');
$routes->post('productCategory/updateProductDepartment', 'Master\Products::updateProductDepartment');
$routes->delete('productCategory/deleteProductDepartment', 'Master\Products::deleteProductDepartment');
$routes->post('productCategory/createProductSubdepartment', 'Master\Products::createProductSubdepartment');
$routes->post('productCategory/updateProductSubdepartment', 'Master\Products::updateProductSubdepartment');
$routes->delete('productCategory/deleteProductSubdepartment', 'Master\Products::deleteProductSubdepartment');

# Master Product 
$routes->get('product', 'Master\Products::product');
$routes->get('product/printBarcode', 'Master\Products::printBarcodeProduct');
$routes->get('product/formCreate', 'Master\Products::createProduct');
$routes->post('product/createProduct', 'Master\Products::saveProduct');
$routes->post('product/updateProduct', 'Master\Products::updateProduct');
$routes->get('product/saveUpdateProduct', 'Master\Products::saveUpdateProduct');
$routes->delete('product/deleteProducts', 'Master\Products::deleteProducts');
$routes->get('product/productAjax', 'Master\Products::productAjax');
$routes->post('product/dataProduct', 'Master\Products::getDataProduct');
$routes->get('product/updateStockProduct', 'Master\Products::saveUpdateStockProduct');
$routes->post('product/save', 'Master\Products::updateProductStock');


#Master Branch
$routes->get('branch', 'Master\Branchs::index');
$routes->post('branch/createBranch', 'Master\Branchs::createBranch');
$routes->post('branch/updateBranch', 'Master\Branchs::updateBranch');
$routes->delete('branch/deleteBranch', 'Master\Branchs::deleteBranch');

#Master PaymentMethod
$routes->get('paymentMethod', 'Master\PaymentMethod::index');
$routes->post('paymentMethod/createPaymentMethod', 'Master\PaymentMethod::createPaymentMethod');
$routes->post('paymentMethod/updatePaymentMethod', 'Master\PaymentMethod::updatePaymentMethod');
$routes->delete('paymentMethod/deletePaymentMethod', 'Master\PaymentMethod::deletePaymentMethod');

#Master Suppplier
$routes->get('suppliers', 'Master\Suppliers::index');
$routes->post('suppliers/createSuppliers', 'Master\Suppliers::createSuppliers');
$routes->post('suppliers/updateSuppliers', 'Master\Suppliers::updateSuppliers');
$routes->delete('suppliers/deleteSuppliers', 'Master\Suppliers::deleteSuppliers');

#Master users
$routes->get('users', 'Master\Users::index');
$routes->post('users/save', 'Master\Users::saveUsersAccess');
$routes->get('users/userRoleAccess', 'Master\Users::userRoleAccess');
$routes->post('users/createRole', 'Master\Users::createRole');
$routes->post('users/updateRole', 'Master\Users::updateRole');
$routes->delete('users/deleteRole', 'Master\Users::deleteRole');
$routes->post('users/createUser', 'Master\Users::createUser');
$routes->post('users/updateUser', 'Master\Users::updateUser');
$routes->delete('users/deleteUser', 'Master\Users::deleteUser');
$routes->post('users/changeMenuPermission', 'Master\Users::changeMenuPermission');
$routes->post('users/changeMenuCategoryPermission', 'Master\Users::changeMenuCategoryPermission');
$routes->post('users/changeSubMenuPermission', 'Master\Users::changeSubMenuPermission');

#Master Customers
$routes->get('customers', 'Master\Customers::index');
$routes->get('customers/createCustomers', 'Master\Customers::createCustomers');
$routes->get('customers/updateCustomers', 'Master\Customers::updateCustomers');
$routes->post('customers/saveCustomers', 'Master\Customers::saveCustomers');
$routes->post('customers/saveupdateCustomers', 'Master\Customers::saveupdateCustomers');
$routes->get('customers/getCity', 'Master\Customers::getCity');
$routes->post('customers/getCity', 'Master\Customers::getCity');
$routes->get('customers/getSubdistrict', 'Master\Customers::getSubdistrict');
$routes->post('customers/getSubdistrict', 'Master\Customers::getSubdistrict');
$routes->post('customers/checkExpired', 'Master\Customers::checkCustomersExpired');
$routes->delete('customers/deleteCustomers', 'Master\Customers::deleteCustomers');


//Inventory Routes
$routes->get('handoverStuff', 'Inventory\HandoverStuff::index');
$routes->get('handoverStuff/print', 'Inventory\HandoverStuff::printBarcode');
$routes->get('handoverStuff/detail', 'Inventory\HandoverStuff::detailHandoverStuff');
$routes->post('handoverStuff/saveProductReceive', 'Inventory\HandoverStuff::saveProductReceive');
$routes->post('handoverStuff/productStockIn', 'Inventory\HandoverStuff::productStockIn');

//initial Stock
$routes->get('initialStock', 'Inventory\Stock::initialStock');
$routes->post('initialStock/createInitialStock', 'Inventory\Stock::createInitialStock');
$routes->delete('initialStock/deleteInitialStock', 'Inventory\Stock::deleteInitialStock');

//Stock Card
$routes->get('stockCard', 'Inventory\Stock::stockCard');


//Stock Opname
$routes->get('stockOpname', 'Inventory\Stock::stockOpname');
$routes->post('stockOpname/tableHistory', 'Inventory\Stock::getTableStockOpname');
$routes->get('stockOpname/history', 'Inventory\Stock::historyStockOpname');
$routes->post('stockOpname/getTable', 'Inventory\Stock::getTable');
$routes->post('stockOpname/save', 'Inventory\Stock::saveStockOpname');


//Stock Transfer
$routes->get('stockTransfer', 'Inventory\Stock::stockTransfer');
$routes->get('stockTransfer/print', 'Inventory\Stock::printStockTransferLetter');
$routes->get('stockTransfer/create', 'Inventory\Stock::createStockTransfer');
$routes->post('stockTransfer/save', 'Inventory\Stock::saveStockTransfer');
$routes->get('stockTransfer/detail', 'Inventory\Stock::detailStockTransfer');
$routes->get('requestStuff', 'Inventory\Stock::requestStockTransfer');
$routes->get('requestStuff/confirm', 'Inventory\Stock::confirmStockTransfer');
$routes->get('stockTransferHandoverStuff', 'Inventory\Stock::receiveStockTransfer');
$routes->get('stockTransferHandoverStuff/confirm', 'Inventory\Stock::receiveProductStockTransfer');
$routes->post('stockTransferHandoverStuff/updateStatusReq', 'Inventory\Stock::saveStockTransferHandoverStuff');
$routes->post('stockTransferHandoverStuff/updateStatus', 'Inventory\Stock::updateStatusStockTransfer');
$routes->post('stockTransfer/saveConfirmation', 'Inventory\Stock::saveConfimation');


//Purchasing Routes
$routes->get('purchaseOrder', 'Purchasing\PurchaseOrder::index');
$routes->get('purchaseOrder/detail', 'Purchasing\PurchaseOrder::detailPurchaseOrder');
$routes->get('createPurchaseOrder', 'Purchasing\PurchaseOrder::createPurchaseOrder');
$routes->post('createPurchaseOrder', 'Purchasing\PurchaseOrder::savePurchaseOrder');
$routes->post('purchaseOrder/updateStatusPurchaseOrder', 'Purchasing\PurchaseOrder::saveStatusPurchaseOrder');
$routes->get('purchaseReturn', 'Purchasing\PurchaseReturn::index');
$routes->get('purchaseReturn/return', 'Purchasing\PurchaseReturn::purchaseReturn');
$routes->post('purchaseReturn/save', 'Purchasing\PurchaseReturn::savePurchaseReturn');
$routes->get('purchaseReturn/detail', 'Purchasing\PurchaseReturn::index');
$routes->get('purchaseReturn/print', 'Purchasing\PurchaseReturn::print');


//Report Routes
$routes->get('branchStock', 'Report\BranchStock::index');
$routes->get('tax', 'Report\Tax::index');
$routes->get('transactionPurchase', 'Report\TransactionPurchase::index');
$routes->get('transactionSelling', 'Report\TransactionSelling::index');
$routes->get('transactionSellingProduct', 'Report\TransactionSelling::product');
$routes->post('transactionSelling/update', 'Report\TransactionSelling::updateTaxType');


//Sales Routes
$routes->get('cashier', 'Sales\SalesOrder::cashier');
$routes->post('cashier/saveTemp', 'Sales\SalesOrder::saveTempSalesOrder');
$routes->post('cashier/save', 'Sales\SalesOrder::saveSalesOrder');
$routes->post('cashier/voidSalesOrder', 'Sales\SalesOrder::voidSalesOrder');
$routes->get('cashier/openingCashier', 'Sales\SalesOrder::openingCashier');
$routes->post('cashier/saveOpeningCash', 'Sales\SalesOrder::saveOpeningCash');
$routes->post('cashier/closingCash', 'Sales\SalesOrder::closingCash');
$routes->delete('cashier/checkSalesOrder', 'Sales\SalesOrder::checkSalesOrder');
$routes->post('cashier/getDataProduct', 'Sales\SalesOrder::getDataProduct');
$routes->post('cashier/getVoidTable', 'Sales\SalesOrder::getVoidTable');
$routes->get('salesOrderHistory', 'Sales\SalesOrder::history');
$routes->post('cashier/updateStatusTransfer', 'Sales\SalesOrder::updateStatusTransferMoney');
$routes->get('cashier/print', 'Sales\SalesOrder::print');
$routes->get('cashier/printClosingCash', 'Sales\SalesOrder::printClosingChasier');
$routes->delete('cashier/cancelOrder', 'Sales\SalesOrder::cancelOrder');
$routes->post('cashier/saveCustomers', 'Sales\SalesOrder::saveCustomers');
// $routes->get('cashier/getCity', 'Sales\SalesOrder::getCity');
$routes->post('cashier/getCity', 'Sales\SalesOrder::getCity');
// $routes->get('cashier/getSubdistrict', 'Sales\SalesOrder::getSubdistrict');
$routes->post('cashier/getSubdistrict', 'Sales\SalesOrder::getSubdistrict');


//Employee Routes
$routes->get('employee', 'Employee\Employee::index');
$routes->get('employee/attendance', 'Employee\Employee::attendanceManage');
$routes->get('employee/createEmployee', 'Employee\Employee::createEmployee');
$routes->post('employee/saveEmployee', 'Employee\Employee::saveEmployee');
$routes->post('employee/updateEmployee', 'Employee\Employee::updateEmployee');
$routes->delete('employee/deleteEmployee', 'Employee\Employee::deleteEmployee');


// Syncronize
$routes->get('sync', 'Syncronize::index');
$routes->get('sync/customer', 'Syncronize::syncCustomer');
$routes->get('sync/productCategory', 'Syncronize::syncProductCategory');
$routes->get('sync/product', 'Syncronize::syncProduct');
$routes->get('sync/salesOrder', 'Syncronize::syncSalesOrder');
$routes->get('sync/employee', 'Syncronize::syncEmployee');
$routes->get('sync/stockTransfer', 'Syncronize::syncStockTransfer');
$routes->get('sync/StockOpname', 'Syncronize::syncStockOpname');
$routes->get('sync/PurchaseOrder', 'Syncronize::syncPurchaseOrder');


/*
 * --------------------------------------------------------------------
 * Additional Routing
 * --------------------------------------------------------------------
 *
 * There will often be times that you need additional routing and you
 * need it to be able to override any defaults in this file. Environment
 * based routes is one such time. require() additional route files here
 * to make that happen.
 *
 * You will have access to the $routes object within that file without
 * needing to reload it.
 */
if (file_exists(APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php')) {
	require APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php';
}
