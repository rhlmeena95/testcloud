<?= $this->extend('layouts/main'); ?>
<?= $this->section('content'); ?>
<!-- <h3 class="my-3">Formulir <strong><?= $title; ?></strong> </h3> -->

<form action="<?= base_url('createPurchaseOrder'); ?>" method="post">
    <div class="card mt-3">
        <div class="card-body">
            <div class="row justify-content-between">
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="number">Nomor Invoice</label>
                        <input type="text" class="form-control" id="number" value="<?= $InvPurchaseOrder; ?>" readonly>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="date">Tanggal Transaksi</label>
                        <input type="text" class="form-control datePicker" name="inputTransactionDate" id="date" placeholder="Add date picker" required>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="inputSupplier">Pemasok</label>
                        <select id="inputSupplier" name="inputSupplier" class="form-control selectpicker" data-live-search="true" required>
                            <option value="">-- Pilih Pemasok --</option>
                            <?php foreach ($Suppliers as $supplier) : ?>
                                <option value="<?= $supplier['supplierID']; ?>"><?= $supplier['supplier_company']; ?> - <?= $supplier['supplier_contact']; ?> </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
            </div>
            <hr>
            <div class="table-responsive">
                <table class="table table-bordered item-table">
                    <thead>
                        <tr>
                            <th class="">#</th>
                            <th>Nama Barang</th>
                            <th class="">Harga</th>
                            <th class="">Jumlah</th>
                            <th class="text-right">Subtotal</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody id="detailCart">
                    </tbody>
                </table>
            </div>
            <div class="text-right">
                <button type="button" class="btn btn-danger btn-sm resetData">Reset</button>
                <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#productList">Tambah Barang</button>
            </div>
            <hr>
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group invoice-note">
                        <label for="inputNote" class="col-form-label col-form-label-sm">Catatan Pembelian:</label>
                        <textarea class="form-control" id="inputNote" name="inputNote"></textarea>
                    </div>
                </div>
                <div class="col-md-6">
                    <button type="submit" class="btn btn-primary btn-block mt-5">Simpan Data Pembelian</button>
                </div>
            </div>
        </div>
    </div>
</form>
<div class="modal fade" id="productList" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="productListLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="productListLabel">Data Barang</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <table class="table table-striped dataTable" style="width:100%">
                    <thead>
                        <th>#</th>
                        <th>Kategori Barang</th>
                        <th>SKU</th>
                        <th>Nama Barang</th>
                        <th>Harga Beli</th>
                        <th>Jumlah</th>
                        <th>Aksi</th>
                    </thead>
                    <tbody>
                        <?php
                        $i = 1;
                        foreach ($Products as $products) : ?>
                            <tr>
                                <td><?= $i++; ?></td>
                                <td><?= $products['product_subdep_name'] ?> </td>
                                <td><?= $products['product_sku'] ?> </td>
                                <td><?= $products['product_name'] ?> </td>
                                <td>Rp. <?= number_format($products['product_purchase_price']); ?></td>
                                <td><input type="number" min="0" name="quantity" id="quantity<?= $products['productID'] ?>" class="form-control" value="1"></td>
                                <td>
                                    <button type="submit" class="btn btn-primary btn-sm btnAdd" data-id="<?= $products['productID'] ?>" data-name="<?= $products['product_name'] ?>" data-price="<?= $products['product_purchase_price'] ?>">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="6" height="6" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-plus-circle">
                                            <circle cx="12" cy="12" r="10"></circle>
                                            <line x1="12" y1="8" x2="12" y2="16"></line>
                                            <line x1="8" y1="12" x2="16" y2="12"></line>
                                        </svg> Tambah </button>
                                </td>
                            </tr>

                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<script>
    $('document').ready(function() {
        $('.dataTable').on('click', '.btnAdd', function() {
            const product_id = $(this).data("id");
            const price = $(this).data("price");
            const quantity = $('#quantity' + product_id).val();
            let str = $(this).data("name");
            let slash = str.replace("/", " per ");
            let slashp = slash.replace("/", " perdua ");
            let and = slashp.replace(/\+/g, " dan ");
            let and2 = and.replace("&", " dan2 ");
            let quotes = and2.replace('"', " petikdua ");
            let quote = quotes.replace("'", " petik ");
            let colon = quote.replace(":", " titikdua ");
            let line = colon.replace("|", " garis ");
            let backtig = line.replace("`", " petikbalik ");
            let free = backtig.replace("~", " bebas ");
            let strip = free.replace("-", " strip ");
            let tag = strip.replace("(", " kurungbuka ");
            let name = tag.replace(")", " kurungtutup ");

            $.ajax({
                url: "<?= base_url('cart/insertCart'); ?>",
                method: "POST",
                type: 'JSON',
                data: {
                    id: product_id,
                    name: name,
                    qty: quantity,
                    price: price
                },
                success: function(result) {
                    $('#detailCart').html(result);
                    $('#productList').modal('hide');
                }
            });

        });
        // Load shopping cart
        $('#detailCart').load("<?= base_url('cart/loadCart'); ?>");

        $(document).on('click', '.removeCartId', function() {
            const row_id = $(this).attr("id");

            $.ajax({
                url: "<?= base_url('cart/removeCart'); ?>",
                method: "POST",
                type: 'JSON',
                data: {
                    rowid: row_id,
                },
                success: function(result) {
                    $('#detailCart').html(result);
                }
            });
        });
        $(document).on('click', '.resetData', function() {
            const row_id = $(this).attr("id");

            $.ajax({
                url: "<?= base_url('cart/destroyCart'); ?>",
                method: "POST",
                type: 'JSON',
                data: {
                    rowid: row_id,
                },
                success: function(result) {
                    $('#detailCart').html(result);
                }
            });
        });
    });
</script>
<?= $this->endSection(); ?>