<?= $this->extend('layouts/main'); ?>
<?= $this->section('content'); ?>
<div class="row layout-top-spacing" id="cancel-row">
    <div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
        <div class="widget-content widget-content-area br-6">
            <div class="row">
                <div class="col-6">
                    <h3 class="h3 mb-3"><strong><?= $title; ?> <?= ($Date) ? date_indo($Date) : ''; ?></strong></h3>
                </div>
                <div class="col-6">
                    <form action="<?= base_url('salesOrderHistory'); ?>" method="get">
                        <div class="input-group">
                            <input type="date" class="custom-select" name="d" id="date" value="<?= ($Date) ? $Date : ''; ?>" required autofocus>
                            <div class="input-group-append">
                                <button class="btn btn-primary" type="submit">Lihat Data</button>
                            </div>
                    </form>
                </div>
            </div>
        </div>
        <br>
        <?php if ($TotalTransaction) : ?>
            <table style="border: 2px solid;">
                <tr>
                    <td style='text-align:left; font-size:15pt; padding: 15px; color:black'> Grand Total Transaksi Harian : <b>RP. <?= number_format($TotalTransaction['sales_order_total']  - $TotalTransaction['sales_order_discount']); ?></b></td>
                </tr>
                <tr>
                    <td style='text-align:left; font-size:15pt;  padding: 15px; color:black'> Grand Total Produk Harian : <b><?= $qty['sales_order_quantity']; ?></b> pcs</td>
                </tr>
                <tr>
                    <td style=' padding: 15px; color:black'>
                        <div class="n-chk text-right">
                            <input type="checkbox" class="form-check-input BtnStatus" id="transferOwner" <?= ($TotalTransaction['sales_order_transfer_owner'] == 1) ? 'disabled' : ''; ?> <?= ($TotalTransaction['sales_order_transfer_owner'] == 1) ? 'checked' : ''; ?> name="transferToOwner" value="1" data-date="<?= $Date; ?>">
                            <label class="form-check-label" for="transferToOwner" style="color:black">Sudah Dikirimkan</label>
                        </div>
                    </td>
                </tr>
            </table>
        <?php endif; ?>
        <div class="table-responsive">
            <table class="table dataTable">
                <thead class="text-center">
                    <th>#</th>
                    <th>Invoice</th>
                    <th>Nama Member</th>
                    <th>Tanggal Transaksi</th>
                    <th>Status Transaksi</th>
                    <th>Total Transaksi</th>
                    <th>Aksi</th>
                </thead>
                <tbody>
                    <?php
                    if ($SalesOrder != null) :
                        $i = 1;
                        foreach ($SalesOrder as $salesOrder) : ?>
                            <tr class="text-center">
                                <td><?= $i++; ?></td>
                                <td><?= $salesOrder['sales_order_invoices']; ?></td>
                                <td><?= ($salesOrder['customer_id'] == 1) ? 'Umum' : $salesOrder['customer_fullname']; ?></td>
                                <td><?php $prdate = new DateTime($salesOrder['sales_order_created_at']);
                                    echo date_indo($prdate->format('Y-m-d')) . ', ' . $prdate->format('H:i'); ?></td>
                                <td class="text-center"><?php if ($salesOrder['sales_order_status'] == 1) : ?>
                                        <span class="badge badge-success"> Berhasil </span>
                                    <?php elseif ($salesOrder['sales_order_status'] == 2) : ?>
                                        <span class="badge badge-danger"> Dibatalkan </span>
                                    <?php elseif ($salesOrder['sales_order_status'] == 0) : ?>
                                        <span class="badge badge-warning"> Ditunda </span>
                                    <?php endif; ?>
                                </td>
                                <td>Rp. <?= number_format($salesOrder['sales_order_total'] - $salesOrder['sales_order_discount']); ?></td>
                                <td><a class="btn btn-primary" href="<?= base_url('salesOrderHistory?id=' . $salesOrder['sales_order_invoices'] . '&p=' . $salesOrder['sales_order_transaction_id']); ?> ">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-zoom-in">
                                            <circle cx="11" cy="11" r="8"></circle>
                                            <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                                            <line x1="11" y1="8" x2="11" y2="14"></line>
                                            <line x1="8" y1="11" x2="14" y2="11"></line>
                                        </svg>
                                        Detail
                                    </a>
                                    <?php if ($CheckTransaction) : ?>
                                        <?php if ($CheckTransaction['id'] == $salesOrder['sales_order_transaction_id']) : ?>
                                            <button class="btn btn-danger btnVoid" data-toggle="modal" data-target="#voidModal<?= $salesOrder['salesOrderID']; ?>" onclick="return confirm('Apakah Anda yakin melakukan void transaksi ?')">Void</button>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <!-- Void Modal -->
                            <div class="modal fade" id="voidModal<?= $salesOrder['salesOrderID']; ?>" tabindex="-1" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title">Void</h5>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <div class="modal-body">
                                            <form action="<?= base_url('cashier/voidSalesOrder'); ?>" method="post">
                                                <input type="hidden" id="SalesID" name="salesOrderId" value="<?= $salesOrder['salesOrderID']; ?>">
                                                <input type="hidden" name="inputSalesOrderStatus" value="2">
                                                <label for="inputReasonVoid">Alasan Pembatalan Transaksi</label>
                                                <textarea name="inputReasonVoid" class="form-control" id=" inputReasonVoid" cols="50" rows="3"></textarea>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="submit" class="btn btn-primary">Simpan</button>
                                        </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
</div>



<script>
    $('.BtnStatus').click(function() {
        let status = $('#transferOwner').val();
        let date = $(this).data("date");
        // console.log(date);
        $.ajax({
            url: " <?= base_url('cashier/updateStatusTransfer'); ?>",
            type: 'POST',
            data: {
                status: status,
                date: date
            },
            success: function() {
                location.reload();
            }
        });
    });
</script>
<?= $this->endSection(); ?>