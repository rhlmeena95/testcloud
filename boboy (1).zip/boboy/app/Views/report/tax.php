<?= $this->extend('layouts/main'); ?>
<?= $this->section('content'); ?>
<div class="row layout-top-spacing">
	<div class="col-xl-12 col-lg-12 col-md-12 col-12 layout-spacing">
		<div class="widget">
			<div class="widget-content">
				<div class="row">
					<div class="col-sm-6"></div>
					<div class="col-sm-6 mb-3">
						<form action="<?= base_url('tax'); ?>" method="get">
							<div class="input-group">
								<?php if (session()->get('branch_id') == 1) : ?>
									<select class="custom-select" id="branch" name="branch" <?= (1 != session()->get('branch_id')) ? 'disabled' : ''; ?>>
										<option value="">-- Pilih Cabang -- </option>
										<?php foreach ($Branch as $branch) : ?>
											<option value="<?= $branch['branchID']; ?>" <?= ($inputBranch == $branch['branchID']) ? 'selected' : ''; ?>><?= $branch['branch_name']; ?></option>
										<?php endforeach; ?>
									</select>
								<?php endif; ?>
								<select class="custom-select" id="month" name="m" aria-label="Example select with button addon" required>
									<option value="">-- Pilih Bulan --</option>
									<?php
									for ($i = 1; $i <= 12; $i++) : ?>
										<option value="<?= $i; ?>" <?= ($month) ? ($i == $month) ? 'selected' : '' : ''; ?>><?= bulan($i); ?> </option>
									<?php endfor; ?>
								</select>
								<div class="input-group-append">
									<button class="btn btn-primary" type="submit">Lihat Data</button>
									<!-- <button class="btn btn-info" type="button" onclick="return PrintDiv()">Cetak/Print</button> -->
								</div>
							</div>
						</form>
					</div>
				</div>
				<?php if ($Tax != null && $SalesOrder != null) : ?>
					<h4 class="text-center mt-5">
						<b>Laporan Pajak Perusahaan
							<?= $Tax['branch_name']; ?>
							<?= ($month) ? ' Bulan ' . bulan($month) . ' ' . date('Y') : '' ?>

						</b>
					</h4>
					<div class="mt-4 table-responsive">
						<table class="table dataTable">
							<thead>
								<th>#</th>
								<th>Tanggal Transaksi</th>
								<th>Invoice</th>
								<th>Total Transaksi</th>
								<th>Pajak</th>
							</thead>
							<tbody>
								<?php $i = 1;
								foreach ($SalesOrder as $sales) :
									if ($sales['tax_type'] == 1) :
								?>
										<tr>
											<td><?= $i++; ?></td>
											<td>
												<?php $prdate = new DateTime($sales['sales_order_created_at']);
												echo date_indo($prdate->format('Y-m-d'));  ?>
											</td>
											<td><?= $sales['sales_order_invoices']; ?></td>
											<td>Rp. <?= number_format($sales['sales_order_total']); ?></td>
											<td>Rp. <?= number_format($sales['sales_order_tax']); ?></td>
										</tr>
									<?php endif; ?>
								<?php endforeach; ?>
							</tbody>
						</table>
					</div>
					<div class="row mt-4">
						<div class="col-sm-12 col-12 order-sm-1 order-0 text-right">
							<div class="text-sm-right">
								<div class="row">
									<div class="col-sm-9 col-7 grand-total-title">
										<h5 class="">Grand Total Transaksi : </h5>
									</div>
									<div class="col-sm-3 col-5 grand-total-amount">
										<h5>RP. <?= number_format($Tax['sales_order_total']); ?></h5>
									</div>
									<div class="col-sm-9 col-7 grand-total-title">
										<h3 class=""> Total Semua Pajak : </h3>
									</div>
									<div class="col-sm-3 col-5 grand-total-amount">
										<h3>RP. <?= number_format($Tax['sales_order_tax']); ?></h3>
									</div>
								</div>
							</div>
						</div>
					</div>
				<?php else : ?>
					<div class="mt-4 table-responsive">
						<table class="table">
							<thead>
								<th>#</th>
								<th>Invoice</th>
								<th>Total Transaksi</th>
								<th>Pajak</th>
							</thead>
							<tbody>
								<tr>
									<td colspan="4" class="text-center"><b>Data Masih Kosong</b></td>
								</tr>
							</tbody>
						</table>
					</div>
				<?php endif; ?>
			</div>
		</div>
	</div>
</div>
<!-- <script>
	function PrintDiv() {
		//print('#DataPrint');
		var divContents = document.getElementById('DataPrint').innerHTML;
		var a = window.open();
		a.document.write('<html>');
		a.document.write('<body>');
		a.document.write('<head>');
		a.document.write('<link href="<?= base_url('bootstrap/css/bootstrap.css') ?>" rel="stylesheet" type="text/css">');
		a.document.write('</head>');
		a.document.write(divContents);
		a.document.write('</body></html>');
		a.document.close();
	}
</script> -->
<?= $this->endSection(); ?>