<?= $this->extend('layouts/main'); ?>
<?= $this->section('content'); ?>
<div class="row layout-top-spacing">
    <div class="col-xl-12 col-lg-12 col-md-12 col-12 layout-spacing">
        <div class="widget">
            <div class="widget-content">
                <?php if (1 == session()->get('branch_id')) : ?>
                    <form action="<?= base_url('branchStock'); ?>" method="get">
                        <div class="row">
                            <div class="col-sm-6"></div>
                            <div class="col-sm-6">
                                <div class="input-group">
                                    <select class="custom-select" id="branch" name="branch" <?= (1 != session()->get('branch_id')) ? 'disabled' : ''; ?>>
                                        <option value="">-- Pilih Cabang -- </option>
                                        <?php foreach ($Branch as $branch) : ?>
                                            <option value="<?= $branch['branchID']; ?>" <?= ($inputBranch == $branch['branchID']) ? 'selected' : ''; ?>><?= $branch['branch_name']; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                    <div class="input-group-append">
                                        <button type="submit" class="btn btn-primary">Lihat Data</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                <?php else : ?>
                    <div class="row">
                        <div class="col-sm-6">
                            <h2>Stok Cabang <?= session()->get('branch') ?></h2>
                        </div>
                    </div>
                <?php endif; ?>
                <div class="mt-2 table-responsive">
                    <table class="table dataTable">
                        <thead>
                            <th class="text-center">#</th>
                            <th class="text-center">SKU</th>
                            <th>Kategori Barang</th>
                            <th>Nama Barang</th>
                            <th class="text-center">Total Stok</th>
                            <th>Barcode</th>
                            <!-- <th>Aksi</th> -->
                        </thead>
                        <tbody>
                            <?php $i = 1;
                            foreach ($BranchStock as $branchStock) : ?>
                                <tr>
                                    <td class="text-center"><?= $i++; ?></td>
                                    <td class="text-center"><?= $branchStock['product_sku']; ?></td>
                                    <td><?= $branchStock['product_subdep_name']; ?></td>
                                    <td><?= $branchStock['stock_product_name']; ?></td>
                                    <td class="text-center"><?= $branchStock['stock_product_qty_new']; ?></td>
                                    <td><button class="btn btn-outline-success text-dark PrintBarcode" data-toggle="modal" data-target="#PrintModal<?= $branchStock['product_id']; ?>">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-printer text-success">
                                                <polyline points="6 9 6 2 18 2 18 9"></polyline>
                                                <path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"></path>
                                                <rect x="6" y="14" width="12" height="8"></rect>
                                            </svg> Barcode
                                        </button>
                                    </td>
                                    <!-- <td><a href="<?= base_url('product/updateStockProduct?id=' . $branchStock['product_id'] . '&b=' . $inputBranch); ?>" class="btn btn-outline-primary ">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-edit text-primary">
                                                <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                                                <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                                            </svg> Ubah</a>
                                    </td> -->
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php foreach ($BranchStock as $branchStock) :  ?>
    <!-- Print Modal -->
    <div class="modal fade" id="PrintModal<?= $branchStock['product_id']; ?>" tabindex="-1" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true">
        <div class="modal-dialog modal-sm" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Input Jumlah Print</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="<?= base_url('product/printBarcode'); ?>" method="get">
                        <input type="hidden" name="productID" id="IdProducT" value="<?= $branchStock['product_id']; ?>">
                        <input type="hidden" name="p" id="p" value="1">
                        <label for="total">Jumlah Yang akan di print</label>
                        <input type="number" id="inputPrint" class="form-control" min="0" placeholder="0" name="total" id="total" required>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Simpan</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; ?>


<script>
    $(document).ready(function() {
        // $('.PrintBarcode').click(function() {
        //     let product_id = $(this).data('id');
        //     // console.log(product_id);
        //     $('#IdProducT').val(product_id);
        // })
        $('#PrintModal').on('shown.bs.modal', function() {
            $('#inputPrint').focus();
        })
    })
</script>

<?= $this->endSection(); ?>