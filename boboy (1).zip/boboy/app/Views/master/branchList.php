<?= $this->extend('layouts/main'); ?>
<?= $this->section('content'); ?>
<div class="row">
	<div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
		<div class="widget-content widget-content-area ">
			<div class="text-right">
				<button class="btn btn-primary btnAdd" data-toggle="modal" data-target="#formAddNewBranchModal">
					<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-plus-square">
						<rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
						<line x1="12" y1="8" x2="12" y2="16"></line>
						<line x1="8" y1="12" x2="16" y2="12"></line>
					</svg>Tambah Cabang Baru</button>
			</div>
			<div class="table-responsive">
				<table class="table table-striped dataTable" style="width:100%">
					<thead>
						<th>#</th>
						<th>Kode Cabang</th>
						<th>Nama Cabang</th>
						<th>Pimpinan Cabang</th>
						<th>Nomor Telepon</th>
						<th>Aksi</th>
					</thead>
					<tbody>
						<?php
						$i = 1;
						foreach ($Branch as $branch) : ?>
							<tr>
								<td><?= $i++; ?> </td>
								<td><?= $branch['branch_code'] ?> </td>
								<td><?= $branch['branch_name'] ?> </td>
								<td><?= $branch['employee_name'] ?> </td>
								<td class="text-right"><?= $branch['branch_telephone'] ?> </td>
								<td class="text-right">
									<div class="btn-group  mb-4 mr-2">
										<button class="btn btn-outline-primary  text-dark btnDtl" data-toggle="modal" data-target="#formDetailBranchModal<?= $branch['branchID']; ?>">
											<svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather text-success feather-info">
												<circle cx="12" cy="12" r="10"></circle>
												<line x1="12" y1="16" x2="12" y2="12"></line>
												<line x1="12" y1="8" x2="12.01" y2="8"></line>
											</svg> Detail
										</button>
										<button type="button" class="btn btn-outline-primary dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down">
												<polyline points="6 9 12 15 18 9"></polyline>
											</svg>
											<span class="sr-only">Toggle Dropdown</span>
										</button>
										<div class="dropdown-menu text-center">
											<button class="dropdown-item btnUpdt" data-toggle="modal" data-target="#formBranchUpdateModal" data-id="<?= $branch['branchID']; ?>" data-name="<?= $branch['branch_name'] ?>" data-code="<?= $branch['branch_code'] ?>" data-manager="<?= $branch['branch_manager'] ?>" data-address="<?= $branch['branch_address'] ?>" data-province="<?= $branch['branch_province'] ?>" data-city="<?= $branch['branch_city'] ?>" data-subdistrict="<?= $branch['branch_subdistrict'] ?>" data-phone="<?= $branch['branch_telephone'] ?>">
												<svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather text-primary feather-edit">
													<path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
													<path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
												</svg> Ubah
											</button>
											<div class="dropdown-divider"></div>
											<form action="<?= base_url('branch/deleteBranch'); ?>" method="post">
												<input type="hidden" name="branchID" id="branchID" value="<?= $branch['branchID']; ?>">
												<input type="hidden" name="_method" value="DELETE">
												<button type="submit" class="dropdown-item" onclick="return confirm('Apakah anda yakin mengapus Cabang <?= $branch['branch_name'] ?>?')">
													<svg xmlns="http://www.w3.org/2000/svg" width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather text-danger feather-trash-2">
														<polyline points="3 6 5 6 21 6"></polyline>
														<path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
														<line x1="10" y1="11" x2="10" y2="17"></line>
														<line x1="14" y1="11" x2="14" y2="17"></line>
													</svg> Hapus
												</button>
											</form>
										</div>
									</div>
								</td>
							</tr>
							<!-- Modal Detail Branch -->
							<div class="modal fade" id="formDetailBranchModal<?= $branch['branchID']; ?>" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="formDetailBranchModalLabel" aria-hidden="true">
								<div class="modal-dialog modal-lg" role="document">
									<div class="modal-content">
										<div class="modal-header">
											<h5 class="modal-title" id="formDetailBranchModalLabel">Detail Cabang</h5>
											<button type="button" class="close" data-dismiss="modal" aria-label="Close">
												<span aria-hidden="true">&times;</span>
										</div>
										<div class="modal-body">
											<ul class="contacts-block list-unstyled">
												<li class="contacts-block__item mb-4">
													<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-code">
														<polyline points="16 18 22 12 16 6"></polyline>
														<polyline points="8 6 2 12 8 18"></polyline>
													</svg> <b>Kode Cabang :</b> <?= $branch['branch_code']; ?>
												</li>
												<li class="contacts-block__item mb-4">
													<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-home">
														<path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
														<polyline points="9 22 9 12 15 12 15 22"></polyline>
													</svg> <b>Nama Cabang :</b> <?= $branch['branch_name']; ?>
												</li>
												<li class="contacts-block__item mb-4">
													<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-user">
														<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
														<circle cx="12" cy="7" r="4"></circle>
													</svg> <b>Pimpinan Cabang :</b> <?= $branch['employee_name']; ?>
												</li>
												<li class="contacts-block__item mb-4">
													<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-phone">
														<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
													</svg> <b>Nomor Telepon Cabang :</b> <?= $branch['branch_telephone']; ?>
												</li>
												<li class="contacts-block__item mb-4">
													<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-map-pin">
														<path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
														<circle cx="12" cy="10" r="3"></circle>
													</svg> <b>Alamat Cabang :</b> <?= $branch['branch_address']; ?>
												</li>
												<div class="form-row mb-4">
													<div class="form-group col-md-4">
														<label for="inputProvince"> <b>Provinsi</b> </label>
														<input type="text" disabled id="inputProvince" name="inputProvince" class="form-control" value="<?= $branch['province_name']; ?>">
													</div>
													<div class="form-group col-md-4">
														<label for="inputCity"> <b>Kota/Kabupaten</b> </label>
														<input type="text" disabled id="inputCity" name="inputCity" class="form-control" value="<?= $branch['city_type']; ?> <?= $branch['city_name']; ?>">
													</div>
													<div class="form-group col-md-4">
														<label for="inputSubdistrict"><b>Kecamatan</b> </label>
														<input type="text" disabled id="inputSubdistrict" name="inputSubdistrict" class="form-control" value="<?= $branch['subdistrict_name']; ?>">
													</div>
												</div>
											</ul>
										</div>
										<div class="modal-footer">
											<button class="btn" data-dismiss="modal"><i class="flaticon-cancel-12"></i> Kembali</button>
										</div>
									</div>
								</div>
							</div>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
<!-- Modal Add Branch -->
<div class="modal fade" id="formAddNewBranchModal" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="formAddNewBranchModalLabel" aria-hidden="true">
	<div class="modal-dialog modal-lg" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="formAddNewBranchModalLabel">Tambah Data Cabang Baru</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
			</div>
			<div class="modal-body">
				<form action="<?= base_url('branch/createBranch'); ?>" method="post">
					<div class="form-group">
						<label for="inputCode">Kode Cabang</label>
						<input type="text" class="form-control" name="inputCode" id="inputCode" required>
					</div>
					<div class="form-group">
						<label for="inputBranchName">Nama Cabang</label>
						<input type="text" class="form-control" name="inputBranchName" id="inputBranchName" required>
					</div>
					<div class="form-group">
						<label for="inputBranchManager">Nama Pimpinan Cabang</label>
						<select id="inputBranchManager" name="inputBranchManager" class="form-control selectpicker" data-live-search="true" required>
							<option selected>Pilih Pimpinan Cabang</option>
							<?php foreach ($Employee as $employee) : ?>
								<option value="<?= $employee['id']; ?>"><?= $employee['employee_name']; ?></option>
							<?php endforeach; ?>
						</select>
					</div>
					<div class="form-group">
						<label for="inputBranchAddress">Alamat Cabang</label>
						<input type="text" class="form-control" name="inputBranchAddress" id="inputBranchAddress" required>
					</div>
					<div class="row">
						<div class="col-4">
							<div class="form-group Province">
								<label for="inputProvince">Provinsi</label>
								<select id="Province" name="inputProvince" class="form-control selectpicker provinceID" data-live-search="true" required>
									<option selected>Pilih Provinsi...</option>
									<?php foreach ($Province as $province) : ?>
										<option value="<?= $province['id']; ?>"><?= $province['province_name']; ?></option>
									<?php endforeach; ?>
								</select>
							</div>
						</div>
						<div class="col-4" id="form_City">
							<div class="form-group">
								<label for="inputCity">Kabupaten/Kota</label>
								<select id="city" name="inputCity" class="form-control " required>
									<option selected>Pilih Kabupaten/Kota...</option>
								</select>
							</div>
						</div>
						<div class="col-4" id="form_Subdistrict">
							<div class="form-group">
								<label for="inputSubdistrict">Kecamatan</label>
								<select id="subdistrict" name="inputSubdistrict" class="form-control" required>
									<option selected>Pilih Kecamatan...</option>
								</select>
							</div>
						</div>
					</div>
					<div class="form-group">
						<label for="inputBranchTelephone">Nomor Telepon</label>
						<input type="text" class="form-control" name="inputBranchTelephone" id="inputBranchTelephone" required>
					</div>
					<div class="modal-footer">
						<button class="btn" data-dismiss="modal"><i class="flaticon-cancel-12"></i> Kembali</button>
						<button type="submit" class="btn btn-primary">Simpan</button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
<!-- Modal Update Branch -->
<div class="modal fade" id="formBranchUpdateModal" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="formBranchUpdateModalLabel" aria-hidden="true">
	<div class="modal-dialog modal-lg" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="formBranchUpdateModalLabel">Ubah Data Cabang</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
			</div>
			<div class="modal-body">
				<form action="<?= base_url('branch/updateBranch'); ?>" method="post">
					<input type="hidden" class="form-control" name="branchID" id="idBranch" required>
					<div class="form-group">
						<label for="inputCode">Kode Cabang</label>
						<input type="text" class="form-control" name="inputCode" id="codeBranch" required>
					</div>
					<div class="form-group">
						<label for="inputBranchName">Nama Cabang</label>
						<input type="text" class="form-control" name="inputBranchName" id="nameBranch" required>
					</div>
					<div class="form-group">
						<label for="inputBranchManager">Nama Pimpinan Cabang</label>
						<select id="managerBranch" name="inputBranchManager" class="form-control" required>
							<option></option>
							<?php foreach ($Employee as $employee) : ?>
								<option value="<?= $employee['id']; ?>"><?= $employee['employee_name']; ?></option>
							<?php endforeach; ?>
						</select>
					</div>
					<div class="form-group">
						<label for="inputBranchAddress">Alamat Cabang</label>
						<textarea class="form-control" id="addressBranch" name="inputBranchAddress" required></textarea>
					</div>
					<div class="row">
						<div class="col-4 ProvinceUpdate">
							<div class="form-group Province_Update">
								<label for="inputProvince">Provinsi</label>
								<select id="provinceSupplier" name="inputProvince" class="form-control selectpicker btnselect provinceSelect" data-live-search="true" required>
									<option selected>Pilih Provinsi...</option>
									<?php foreach ($Province as $province) : ?>
										<option value="<?= $province['id']; ?>"><?= $province['province_name']; ?></option>
									<?php endforeach; ?>
								</select>
							</div>
						</div>
						<div class="col-4" id="form_City_Update">
							<div class="form-group">
								<label for="inputCity">Kabupaten/Kota</label>
								<select id="cityUpdate" name="inputCity" class="form-control " required>
									<option selected>Pilih Kabupaten/Kota...</option>
								</select>
							</div>
						</div>
						<div class="col-4" id="form_Subdistrict_Update">
							<div class="form-group">
								<label for="inputSubdistrict">Kecamatan</label>
								<select id="subdistrictUpdate" name="inputSubdistrict" class="form-control" required>
									<option selected>Pilih Kecamatan...</option>
								</select>
							</div>
						</div>
					</div>
					<div class="form-group">
						<label for="inputBranchTelephone">Nomor Telepon</label>
						<input type="text" class="form-control" name="inputBranchTelephone" id="phoneBranch" required>
					</div>
					<div class="modal-footer">
						<button class="btn" data-dismiss="modal"><i class="flaticon-cancel-12"></i> Kembali</button>
						<button type="submit" class="btn btn-primary">Simpan</button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>


<script>
	$(' .btnUpdt').click(function() {
		const branch_id = $(this).data("id");
		const branch_code = $(this).data("code");
		const branch_name = $(this).data("name");
		const branch_manager = $(this).data("manager");
		const branch_address = $(this).data("address");
		const branch_province = $(this).data("province");
		const branch_city = $(this).data("city");
		const branch_subdistrict = $(this).data("subdistrict");
		const branch_phone = $(this).data("phone");


		$('#idBranch').val(branch_id);
		$('#codeBranch').val(branch_code);
		$('#nameBranch').val(branch_name);
		$('#managerBranch').val(branch_manager);
		$('#addressBranch').val(branch_address);
		$('#provinceBranch').val(branch_province);
		$('#cityBranch').val(branch_city);
		$('#subdistrictBranch').val(branch_subdistrict);
		$('#phoneBranch').val(branch_phone);
	});
	$(document).ready(function() {
		$('.Province').on('change', ".provinceID", function() {
			const provinsi = $("#Province").val();

			$.ajax({
				url: "<?= base_url('customers/getCity'); ?>",
				method: "POST",
				type: 'JSON',
				data: {
					province: provinsi,
				},
				success: function(result) {
					$("#city").html(result);
				}
			});
		});
		$('#form_City').on('change', "#city", function() {
			const kota = $("#city").val();

			$.ajax({
				url: "<?= base_url('customers/getSubdistrict'); ?>",
				method: "POST",
				type: 'JSON',
				data: {
					city: kota,
				},
				success: function(result) {
					$("#subdistrict").html(result);
				}
			});
		});
		$(document).ready(function() {
			$('.ProvinceUpdate').on('change', ".provinceSelect", function() {
				const provinsiUpdate = $("#provinceSupplier").val();
				// console.log(provinsiUpdate);
				$.ajax({
					url: "<?= base_url('customers/getCity'); ?>",
					method: "POST",
					type: 'JSON',
					data: {
						province: provinsiUpdate,
					},
					success: function(result) {
						$("#cityUpdate").html(result);
					}
				});
			});
			$('#form_City_Update').on('change', "#cityUpdate", function() {
				const kotaUpdate = $("#cityUpdate").val();
				// console.log(kotaUpdate);
				$.ajax({
					url: "<?= base_url('customers/getSubdistrict'); ?>",
					method: "POST",
					type: 'JSON',
					data: {
						city: kotaUpdate,
					},
					success: function(result) {
						$("#subdistrictUpdate").html(result);
					}
				});
			});
		});
	});
</script>
<?= $this->endSection(); ?>