<?= $this->extend('layouts/main'); ?>
<?= $this->section('content'); ?>
<div class="container-fluid">
    <div class="card">
        <div class="card-body my-4">
            <ul class="nav nav-tabs" id="border-tabs" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active" id="divisi-tab" data-toggle="tab" data-target="#divisi" type="button" role="tab" aria-controls="divisi" aria-selected="false">Divisi</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link " id="department-tab" data-toggle="tab" data-target="#department" type="button" role="tab" aria-controls="department" aria-selected="false">Department</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="subdepartment-tab" data-toggle="tab" data-target="#subdepartment" type="button" role="tab" aria-controls="subdepartment" aria-selected="false">Subdepartment</button>
                </li>
            </ul>
            <div class="tab-content" id="border-tabsContent">
                <div class="tab-pane fade show active" id="divisi" role="tabpanel" aria-labelledby="divisi-tab">
                    <div class="mt-3">
                        <div class="row">
                            <div class="col-8">
                                <div class="table-responsive">
                                    <table class="table table-striped dataTable">
                                        <thead>
                                            <th>#</th>
                                            <th>Nama Divisi</th>
                                            <th>Aksi</th>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $i = 1;
                                            foreach ($ProductDivisi as $productdivisi) : ?>
                                                <tr>
                                                    <td><?= $i++; ?> </td>
                                                    <td><?= $productdivisi['product_divisi_name'] ?> </td>
                                                    <td>
                                                        <div class="btn-group mb-4 mr-2" role="group">
                                                            <button id="btndefault" type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Manage <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down">
                                                                    <polyline points="6 9 12 15 18 9"></polyline>
                                                                </svg></button>
                                                            <div class="dropdown-menu" aria-labelledby="btndefault">
                                                                <button class="dropdown-item btnUpdateDev" data-toggle="modal" data-target="#formUpdateDivisiModal" data-devid="<?= $productdivisi['divisiID']; ?>" data-divname="<?= $productdivisi['product_divisi_name'] ?>">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather text-primary feather-edit">
                                                                        <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                                                                        <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                                                                    </svg> Ubah</button>
                                                                <form action="<?= base_url('productCategory/deleteProductDivisi'); ?>" method="post" class="d-inline">
                                                                    <input type="hidden" name="divisiID" id="divisiID" value="<?= $productdivisi['divisiID']; ?>">
                                                                    <input type="hidden" name="_method" value="DELETE">
                                                                    <button type="submit" class="dropdown-item" onclick="return confirm('Apakah anda yakin mengapus divisi <?= $productdivisi['product_divisi_name'] ?>?')">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather text-danger feather-trash-2">
                                                                            <polyline points="3 6 5 6 21 6"></polyline>
                                                                            <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                                                                            <line x1="10" y1="11" x2="10" y2="17"></line>
                                                                            <line x1="14" y1="11" x2="14" y2="17"></line>
                                                                        </svg> Hapus
                                                                    </button>
                                                                </form>
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="card">
                                    <div class="card-header">
                                        <h5 class="fw-bold text-primary">Buat divisi Barang Baru</h5>
                                    </div>
                                    <div class="card-body">
                                        <form action="<?= base_url('productCategory/createProductDivisi'); ?>" method="post">
                                            <div class="form-group">
                                                <label for="inputProductdivisiName">Nama Divisi</label>
                                                <input type="text" class="form-control" name="inputProductDivisiName" id="inputProductDivisiName" required>
                                            </div>
                                            <hr>
                                            <div class="d-grid gap-2 mt-3">
                                                <button class="btn btn-primary float-right" type="submit">Simpan Data</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="tab-pane fade" id="department" role="tabpanel" aria-labelledby="department-tab">
                    <div class="mt-3">
                        <div class="row">
                            <div class="col-8">
                                <div class="table-responsive">
                                    <table class="table table-striped dataTable">
                                        <thead>
                                            <th>#</th>
                                            <th>Kode</th>
                                            <th>nama Department Barang</th>
                                            <th>Kategori Divisi</th>
                                            <th>Aksi</th>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $i = 1;
                                            foreach ($ProductDepartment as $productdepartment) : ?>
                                                <tr>
                                                    <td><?= $i++; ?> </td>
                                                    <td><?= $productdepartment['product_department_code'] ?> </td>
                                                    <td><?= $productdepartment['product_department_name'] ?> </td>
                                                    <td><?= $productdepartment['product_divisi_name'] ?> </td>
                                                    <td>
                                                        <div class="btn-group mb-4 mr-2" role="group">
                                                            <button id="btndefault" type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Manage <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down">
                                                                    <polyline points="6 9 12 15 18 9"></polyline>
                                                                </svg></button>
                                                            <div class="dropdown-menu" aria-labelledby="btndefault">
                                                                <button class="dropdown-item btnDep" data-toggle="modal" data-target="#formUpdateDepartmentModal" data-id="<?= $productdepartment['departmentID']; ?>" data-code="<?= $productdepartment['product_department_code'] ?>" data-name="<?= $productdepartment['product_department_name'] ?>" data-categorydiv="<?= $productdepartment['product_divisi_id'] ?>">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather text-primary feather-edit">
                                                                        <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                                                                        <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                                                                    </svg> Ubah</button>
                                                                <form action="<?= base_url('productCategory/deleteProductDepartment'); ?>" method="post" class="d-inline">
                                                                    <input type="hidden" name="departmentID" id="departmentID" value="<?= $productdepartment['departmentID']; ?>">
                                                                    <input type="hidden" name="_method" value="DELETE">
                                                                    <button type="submit" class="dropdown-item" onclick="return confirm('Apakah anda yakin mengapus department <?= $productdepartment['product_department_name'] ?>?')">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather text-danger feather-trash-2">
                                                                            <polyline points="3 6 5 6 21 6"></polyline>
                                                                            <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                                                                            <line x1="10" y1="11" x2="10" y2="17"></line>
                                                                            <line x1="14" y1="11" x2="14" y2="17"></line>
                                                                        </svg> Hapus
                                                                    </button>
                                                                </form>
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="card">
                                    <div class="card-header">
                                        <h5 class="fw-bold text-primary">Buat Department Barang Baru</h5>
                                    </div>
                                    <div class="card-body">
                                        <form action="<?= base_url('productCategory/createProductDepartment'); ?>" method="post">
                                            <div class="form-group">
                                                <label for="inputProductDepartmentCode">Kode Department</label>
                                                <input type="text" class="form-control" name="inputProductDepartmentCode" id="inputProductDepartmentCode" value="<?= $CodeDepartment; ?>" readonly required>
                                            </div>
                                            <div class="form-group">
                                                <label for="inputProductDepartmentName">nama Department Barang</label>
                                                <input type="text" class="form-control" name="inputProductDepartmentName" id="inputProductDepartmentName" required>
                                            </div>
                                            <div class="form-group">
                                                <label for="inputProductDivisiId">Kategori Divisi</label>
                                                <select name="inputProductDivisiId" id="inputProductDivisiId" class="form-control selectpicker" data-live-search="true">
                                                    <option selected="selected">Pilih Divisi</option>
                                                    <?php foreach ($ProductDivisi as $productdivisi) : ?>
                                                        <option value="<?= $productdivisi['id']; ?>"><?= $productdivisi['product_divisi_name']; ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                            <hr>
                                            <div class="d-grid gap-2 mt-3">
                                                <button class="btn btn-primary float-right" type="submit">Simpan Data</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="tab-pane fade" id="subdepartment" role="tabpanel" aria-labelledby="subdepartment-tab">
                    <div class="mt-3">
                        <div class="row">
                            <div class="col-sm-8">
                                <div class="table-responsive">
                                    <table class="table table-striped dataTable">
                                        <thead>
                                            <th>#</th>
                                            <th>Kode</th>
                                            <th>Nama Subdepartment</th>
                                            <th>Kategori Department</th>
                                            <th>Aksi</th>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $i = 1;
                                            foreach ($ProductSubdepartment as $productsubdepartment) : ?>
                                                <tr>
                                                    <td><?= $i++; ?> </td>
                                                    <td><?= $productsubdepartment['product_subdep_code'] ?> </td>
                                                    <td><?= $productsubdepartment['product_subdep_name'] ?> </td>
                                                    <td><?= $productsubdepartment['product_department_name'] ?> </td>
                                                    <td>
                                                        <div class="btn-group mb-4 mr-2" role="group">
                                                            <button id="btndefault" type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Manage <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down">
                                                                    <polyline points="6 9 12 15 18 9"></polyline>
                                                                </svg></button>
                                                            <div class="dropdown-menu" aria-labelledby="btndefault">
                                                                <button class="dropdown-item btnSubdep" data-toggle="modal" data-target="#formUpdateSubdepartmentModal" data-id="<?= $productsubdepartment['subdepartmentID']; ?>" data-code="<?= $productsubdepartment['product_subdep_code'] ?>" data-name="<?= $productsubdepartment['product_subdep_name'] ?>" data-divisisub="<?= $productsubdepartment['divisiID'] ?>" data-departmentsubdep="<?= $productsubdepartment['product_department_id'] ?>">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather text-primary feather-edit">
                                                                        <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                                                                        <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                                                                    </svg> Ubah</button>
                                                                <form action="<?= base_url('productCategory/deleteProductSubdepartment'); ?>" method="post" class="d-inline">
                                                                    <input type="hidden" name="subdepartmentID" id="subdepartmentID" value="<?= $productsubdepartment['subdepartmentID']; ?>">
                                                                    <input type="hidden" name="_method" value="DELETE">
                                                                    <button type="submit" class="dropdown-item" onclick="return confirm('Apakah anda yakin mengapus subdepartment <?= $productsubdepartment['product_subdep_name'] ?>?')">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather text-danger feather-trash-2">
                                                                            <polyline points="3 6 5 6 21 6"></polyline>
                                                                            <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                                                                            <line x1="10" y1="11" x2="10" y2="17"></line>
                                                                            <line x1="14" y1="11" x2="14" y2="17"></line>
                                                                        </svg> Hapus</button>
                                                                </form>
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="card">
                                    <div class="card-header">
                                        <h5 class="fw-bold text-primary">Buat Subdepartment Baru</h5>
                                    </div>
                                    <div class="card-body">
                                        <form action="<?= base_url('productCategory/createProductSubdepartment'); ?>" method="post">
                                            <div class="form-group">
                                                <label for="inputProductSubdepName">Nama Subdepartment</label>
                                                <input type="text" class="form-control" name="inputProductSubdepName" id="inputProductSubdepName" required>
                                            </div>
                                            <div class="form-group">
                                                <label for="inputProductdivisiId">Kategori Divisi</label>
                                                <select name="inputProductdivisiId" id="inputProductdivisiId" class="form-control selectpicker" data-live-search="true">
                                                    <option selected="selected">Pilih divisi</option>
                                                    <?php foreach ($ProductDivisi as $productdivisi) : ?>
                                                        <option value="<?= $productdivisi['id']; ?>"><?= $productdivisi['product_divisi_name']; ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                            <div class="form-group">
                                                <label for="inputProductdepartmentId">Kategori Department</label>
                                                <select name="inputProductdepartmentId" id="inputProductdepartmentId" class="form-control selectpicker" data-live-search="true">
                                                    <option selected="selected">Pilih department</option>
                                                    <?php foreach ($ProductDepartment as $productdepartment) : ?>
                                                        <option value="<?= $productdepartment['product_department_code']; ?>"><?= $productdepartment['product_department_name']; ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                            <hr>
                                            <div class="d-grid gap-2 mt-3">
                                                <button class="btn btn-primary float-right" type="submit">Simpan Data</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal Update divisi -->
<div class="modal fade" id="formUpdateDivisiModal" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="formUpdatedivisiModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="formUpdatedivisiModalLabel">Ubah Data Kategori</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
            </div>
            <div class="modal-body">
                <form action="<?= base_url('productCategory/updateProductDivisi'); ?>" method="post">
                    <input type="hidden" name="iddivisi" id="idDivisi">
                    <div class="form-group">
                        <label for="inputProductDivisiName">Nama Divisi</label>
                        <input type="text" class="form-control" name="inputProductDivisiName" id="inputName" required>
                    </div>
            </div>
            <div class="modal-footer">
                <button class="btn" data-dismiss="modal"><i class="flaticon-cancel-12"></i> Kembali</button>
                <button type="submit" class="btn btn-primary">Simpan</button>
            </div>
            </form>
        </div>
    </div>
</div>
<!-- Modal Update department -->
<div class="modal fade" id="formUpdateDepartmentModal" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="formUpdatedepartmentModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="formUpdatedepartmentModalLabel">Ubah Data Kategori</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
            </div>
            <div class="modal-body">
                <form action="<?= base_url('productCategory/updateProductDepartment'); ?>" method="post">
                    <input type="hidden" class="form-control" name="inputProductDepartmentID" id="idDepartment" required>
                    <div class="form-group">
                        <label for="inputProductDepartmentCode">Kode Department</label>
                        <input type="text" class="form-control" name="inputProductDepartmentCode" id="codeDepartment" required readonly>
                    </div>
                    <div class="form-group">
                        <label for="inputProductDepartmentName">nama Department Barang</label>
                        <input type="text" class="form-control" name="inputProductDepartmentName" id="namedepartment" required>
                    </div>
                    <div class="form-group">
                        <label for="inputProductDivisiId">Kategori Divisi</label>
                        <select name="inputProductDivisiId" id="categoryDivisi" class="form-control">
                            <option></option>
                            <?php foreach ($ProductDivisi as $productdivisi) : ?>
                                <option value="<?= $productdivisi['id']; ?>"><?= $productdivisi['product_divisi_name']; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
            </div>
            <div class="modal-footer">
                <button class="btn" data-dismiss="modal"><i class="flaticon-cancel-12"></i> Kembali</button>
                <button type="submit" class="btn btn-primary">Simpan</button>
            </div>
            </form>
        </div>
    </div>
</div>
<!-- Modal Update Subdepartment -->
<div class="modal fade" id="formUpdateSubdepartmentModal" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="formUpdateSubdepartmentModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="formUpdateSubdepartmentModalLabel">Ubah Data Kategori</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
            </div>
            <div class="modal-body">
                <form action="<?= base_url('productCategory/updateProductSubdepartment'); ?>" method="post">
                    <input type="hidden" class="form-control" name="inputProductSubdepartmentID" id="idsubdepartment" readonly>
                    <div class="form-group">
                        <label for="inputProductSubdepCode">Kode Subdepartment</label>
                        <input type="text" class="form-control" name="inputProductSubdepCode" id="codeSubdep" readonly>
                    </div>
                    <div class="form-group">
                        <label for="inputProductSubdepName">Nama Subdepartment</label>
                        <input type="text" class="form-control" name="inputProductSubdepName" id="nameSubdep" required>
                    </div>
                    <div class="form-group">
                        <label for="inputProductDivisiId">Kategori Divisi</label>
                        <select name="inputProductDivisiId" id="divisiSubdep" class="form-control ">
                            <option></option>
                            <?php foreach ($ProductDivisi as $productdivisi) : ?>
                                <option value="<?= $productdivisi['id']; ?>"><?= $productdivisi['product_divisi_name']; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="inputProductDepartmentId">Kategori Department</label>
                        <select name="inputProductDepartmentId" id="departmentSubdep" class="form-control">
                            <option></option>
                            <?php foreach ($ProductDepartment as $productdepartment) : ?>
                                <option value="<?= $productdepartment['product_department_code']; ?>"><?= $productdepartment['product_department_name']; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
            </div>
            <div class="modal-footer">
                <button class="btn" data-dismiss="modal"><i class="flaticon-cancel-12"></i> Kembali</button>
                <button type="submit" class="btn btn-primary">Simpan</button>
            </div>
            </form>
        </div>
    </div>
</div>
<script>
    // UPDATE DIVISI
    $('.btnUpdateDev').click(function() {
        const divisi_id = $(this).data("devid");
        const name_divisi = $(this).data("divname")
        // // console.log(divisi_id);
        // // console.log(name_divisi);
        $('#inputName').val(name_divisi);
        $('#idDivisi').val(divisi_id);
    });
    // UPDATE DEPARTMENT
    $('.btnDep').click(function() {
        const department_id = $(this).data("id");
        const code_department = $(this).data("code")
        const name_department = $(this).data("name")
        const category_divisi = $(this).data("categorydiv")
        // // console.log(department_id);
        // // console.log(code_department);
        // // console.log(name_department);
        // console.log(category_divisi);
        $('#idDepartment').val(department_id);
        $('#codeDepartment').val(code_department);
        $('#namedepartment').val(name_department);
        $('#categoryDivisi').val(category_divisi);

    });
    // UPDATE SUBDEPARTMENT
    $('.btnSubdep').click(function() {
        const subdepartment_id = $(this).data("id");
        const code_subdepartment = $(this).data("code")
        const name_subdepartment = $(this).data("name")
        const category_divisi = $(this).data("divisisub")
        const category_department = $(this).data("departmentsubdep")
        // console.log(subdepartment_id);
        // console.log(code_subdepartment);
        // console.log(name_subdepartment);
        // console.log(category_divisi);
        // console.log(category_department);
        $('#idsubdepartment').val(subdepartment_id);
        $('#codeSubdep').val(code_subdepartment);
        $('#nameSubdep').val(name_subdepartment);
        $('#divisiSubdep').val(category_divisi);
        $('#departmentSubdep').val(category_department);
    });
</script>
<?= $this->endSection(); ?>