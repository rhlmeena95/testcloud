<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no">
    <title>Masuk Point Of Sale - Toko Mainan Boye</title>
    <link rel="icon" type="image/x-icon" href="assets/img/logotoko1.jpeg" />
    <!-- BEGIN GLOBAL MANDATORY STYLES -->
    <link href="https://fonts.googleapis.com/css?family=Quicksand:400,500,600,700&display=swap" rel="stylesheet">
    <link href="<?= base_url('bootstrap/css/bootstrap.css') ?>" rel="stylesheet" type="text/css" />
    <link href="<?= base_url('assets/css/plugins.css') ?>" rel="stylesheet" type="text/css" />

    <link href="<?= base_url('assets/css/auth.css') ?>" rel="stylesheet" type="text/css" />
    <!-- END GLOBAL MANDATORY STYLES -->
    <link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/theme-checkbox-radio.css') ?>">
    <link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/switches.css') ?>">
    <link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/alert.css') ?>">
    <style>
        .btn-light {
            border-color: transparent;
        }
    </style>
</head>

<body class="form">
    <div class="form-container">
        <div class="form-form">
            <div class="form-form-wrap">
                <div class="form-container">
                    <div class="form-content">
                        <?= $this->include('common/alerts'); ?>
                        <h1 class="">Masuk <a href="<?= base_url(); ?> "><span class="brand-name">BOBOY</span></a></h1>
                        <p class="signup-link">Point Of Sale Toko Mainan Boy</p>
                        <form class="text-left" action="<?= base_url('GetLogin'); ?> " method="POST">
                            <div class="form">

                                <div id="username-field" class="field-wrapper input">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-user">
                                        <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                                        <circle cx="12" cy="7" r="4"></circle>
                                    </svg>
                                    <input id="username" name="inputEmail" type="text" class="form-control" placeholder="Username">
                                </div>

                                <div id="password-field" class="field-wrapper input mb-2">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-lock">
                                        <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
                                        <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
                                    </svg>
                                    <input id="password" name="inputPassword" type="password" class="form-control" placeholder="Password">
                                </div>
                                <div class="d-sm-flex justify-content-between">
                                    <div class="field-wrapper toggle-pass">
                                        <p class="d-inline-block">Show Password</p>
                                        <label class="switch s-primary">
                                            <input type="checkbox" id="toggle-password" class="d-none">
                                            <span class="slider round"></span>
                                        </label>
                                    </div>
                                    <div class="field-wrapper">
                                        <button type="submit" class="btn btn-primary" value="">Masuk</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                        <p class="terms-conditions">© <?= date('Y'); ?> All Rights Reserved. Toko Mainan Boboy </p>

                    </div>
                </div>
            </div>
        </div>
        <div class="form-image">
            <div class="l-image">
            </div>
        </div>
    </div>


    <!-- BEGIN GLOBAL MANDATORY SCRIPTS -->
    <script src="<?= base_url('assets/js/libs/jquery-3.6.0.js') ?>"></script>
    <script src="<?= base_url('bootstrap/js/bootstrap.bundle.min.js') ?>"></script>

    <!-- END GLOBAL MANDATORY SCRIPTS -->
    <script src="<?= base_url('assets/js/auth.js') ?>"></script>

</body>

</html>