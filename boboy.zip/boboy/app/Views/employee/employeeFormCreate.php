<?= $this->extend('layouts/main'); ?>
<?= $this->section('content'); ?>
<h3 class="my-3">
    Menu <strong><?= $title; ?></strong></h3>
<div class="row">
    <div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
        <div class="widget-content widget-content-area br-6">
            <div class="card">
                <div class="card-body">
                    <form action="<?= base_url('employee/saveEmployee'); ?>" method="post">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="inputEmployeeBranch">Pegawai Cabang</label>
                                    <select name="inputEmployeeBranch" id="inputEmployeeBranch" class="form-control" required <?= (1 != session()->get('branch_id')) ? 'readonly' : ''; ?>>
                                        <option value="">-- Pilih Cabang --</option>
                                        <?php foreach ($Branch as $branch) : ?>
                                            <option value="<?= $branch['id']; ?>" <?= (session()->get('branch_id') == $branch['branchID']) ? 'selected' : ''; ?>><?= $branch['branch_name']; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>

                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="inputEmployeeName">Nama Pegawai</label>
                                    <input type="text" class="form-control" name="inputEmployeeName" id="inputEmployeeName" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="inputEmployeeTelephone">Nomor Telepon</label>
                                    <input type="number" class="form-control" name="inputEmployeeTelephone" id="inputEmployeeTelephone" required>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputEmployeeAddress">Alamat Pegawai</label>
                            <textarea class="form-control" id="inputEmployeeAddress" name="inputEmployeeAddress" required></textarea>
                        </div>
                        <div class="row">
                            <div class="col-4 ProvinceUpdate">
                                <div class="form-group Province">
                                    <label for="inputProvince">Provinsi</label>
                                    <select id="Province" name="inputProvince" class="form-control selectpicker provinceID" data-live-search="true" required>
                                        <option selected>Pilih Provinsi...</option>
                                        <?php foreach ($Province as $province) : ?>
                                            <option value="<?= $province['id']; ?>"><?= $province['province_name']; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-4" id="form_City">
                                <div class="form-group">
                                    <label for="inputCity">Kabupaten/Kota</label>
                                    <select id="city" name="inputCity" class="form-control " required>
                                        <option selected>Pilih Kabupaten/Kota...</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-4" id="form_Subdistrict">
                                <div class="form-group">
                                    <label for="inputSubdistrict">Kecamatan</label>
                                    <select id="subdistrict" name="inputSubdistrict" class="form-control" required>
                                        <option selected>Pilih Kecamatan...</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="inputUsername" class="col-form-label">Username:</label>
                                    <input type="text" class="form-control" name="inputUsername" id="inputUsername" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="inputPassword" class="col-form-label">Password:</label>
                                    <input type="password" class="form-control" name="inputPassword" id="inputPassword" required>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputEmployeeRole">Jabatan Pegawai</label>
                            <select name="inputEmployeeRole" id="inputEmployeeRole" class="form-control" required>
                                <option value="">-- Pilih Jabatan Pegawai --</option>
                                <?php foreach ($role as $userRole) : ?>
                                    <option value="<?= $userRole['id']; ?>"><?= $userRole['role_name']; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <hr>
                        <div class="float-right">
                            <a href="<?= base_url('users'); ?>" class="btn" data-dismiss="modal"><i class="flaticon-cancel-12"></i> Kembali</a>
                            <button type="submit" class="btn btn-primary">Simpan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        $('.Province').on('change', ".provinceID", function() {
            const provinsi = $("#Province").val();
            // console.log(provinsi);
            $.ajax({
                url: "<?= base_url('customers/getCity'); ?>",
                method: "POST",
                type: 'JSON',
                data: {
                    province: provinsi,
                },
                success: function(result) {
                    $("#city").html(result);
                }
            });
        });
        $('#form_City').on('change', "#city", function() {
            const kota = $("#city").val();
            // console.log(kota);
            $.ajax({
                url: "<?= base_url('customers/getSubdistrict'); ?>",
                method: "POST",
                type: 'JSON',
                data: {
                    city: kota,
                },
                success: function(result) {
                    $("#subdistrict").html(result);
                }
            });
        });
    });
</script>


<?= $this->endSection(); ?>