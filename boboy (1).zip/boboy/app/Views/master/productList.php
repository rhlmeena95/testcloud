<?= $this->extend('layouts/main'); ?>
<?= $this->section('content'); ?>
<div class="row">
	<div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
		<div class="widget-content widget-content-area ">
			<h2 class="mb-3 text-center"><b>Data Item Seluruh Cabang</b></h2>
			<div class="text-right">
				<a href="<?= base_url('product/formCreate'); ?>" class="btn btn-primary">
					<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-plus-square">
						<rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
						<line x1="12" y1="8" x2="12" y2="16"></line>
						<line x1="8" y1="12" x2="16" y2="12"></line>
					</svg> Tambah Item Baru</a>
			</div>
			<hr>
			<div class="table-responsive">
				<table class="table table-striped " id="DataBarang" style="width:100%">
					<thead>
						<th>SKU</th>
						<th>Kategori</th>
						<th>Nama Barang</th>
						<th>Harga Beli</th>
						<th>Harga Jual</th>
						<th>Total Stok</th>
						<th>Tanggal Pembuatan</th>
						<th>Terakhir Diubah</th>
						<th>Aksi</th>
					</thead>
					<tbody></tbody>
				</table>
			</div>
		</div>
	</div>
</div>

<!-- Print Modal -->
<div class="modal fade" id="PrintModal" tabindex="-1" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true">
	<div class="modal-dialog modal-sm" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title">Input Jumlah Print</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
				<form action="<?= base_url('product/printBarcode'); ?>" method="get">
					<input type="hidden" name="productID" id="ProductID">
					<label for="total">Jumlah Yang akan di print</label>
					<input type="number" class="form-control Print" min="0" placeholder="0" name="total" id="total" required>
			</div>
			<div class="modal-footer">
				<button type="submit" class="btn btn-primary">Simpan</button>
				</form>
			</div>
		</div>
	</div>
</div>

<script>
	$(document).ready(function() {

		$('#DataBarang').DataTable({
			processing: true,
			serverSide: true,
			ajax: '<?= base_url('product/productAjax'); ?>',
			columns: [{
					"data": "product_sku"
				},
				{
					"data": "product_subdep_name"
				},
				{
					"data": "product_name"
				},
				{
					"data": "product_purchase_price"
				},
				{
					"data": "product_selling_price"
				},
				{
					"data": "product_stock"
				},
				{
					"data": "product_created_at",
				},
				{
					"data": "product_updated_at",
				},
				{
					"data": "action"
				}
			],
		});
		$('.BtnPrint').click(function() {
			// $('Print').focus();
			const product_id = $(this).data('id');
			// console.log(product_id);
			$('#ProductID').val(product_id);
		})
		// $('.Print').change(function() {
		// 	const product_id = $('#idProducT').val();
		// 	// console.log(product_id);
		// 	$('#ProductID').val(product_id);
		// })
	});
</script>


<?= $this->endSection(); ?>