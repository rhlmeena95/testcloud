<?= $this->extend('layouts/main'); ?>
<?= $this->section('content'); ?>
<div class="row layout-top-spacing" id="cancel-row">
    <div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
        <div class="widget">
            <div class="widget-content">
                <div class="row">
                    <?php if (1 != session()->get('branch_id')) : ?>
                        <div class="col-sm-6">
                            <h4>Laporan Penjualan Cabang <?= session()->get('branch'); ?></h4>
                        </div>
                    <?php endif; ?>
                    <div class="col-sm-6">
                        <form action="<?= base_url('transactionSelling'); ?>" method="get">
                            <div class="input-group">
                                <?php if (1 == session()->get('branch_id')) : ?>
                                    <select class="custom-select" id="branch" name="branch" <?= (1 != session()->get('branch_id')) ? 'disabled' : ''; ?>>
                                        <option value="">-- Pilih Cabang -- </option>
                                        <?php foreach ($Branch as $branch) : ?>
                                            <option value="<?= $branch['branchID']; ?>" <?= ($inputBranch == $branch['branchID']) ? 'selected' : ''; ?>><?= $branch['branch_name']; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                <?php else : ?>
                                    <input type="hidden" name="branch" value="<?= session()->get('branch_id'); ?>">
                                <?php endif; ?>
                                <select class="custom-select" id="month" name="m" required>
                                    <option value="">-- Pilih Bulan --</option>
                                    <?php
                                    for ($i = 1; $i <= 12; $i++) : ?>
                                        <option value="<?= $i; ?>" <?= ($month) ? ($i == $month) ? 'selected' : '' : ''; ?>><?= bulan($i); ?> </option>
                                    <?php endfor; ?>
                                </select>
                                <select class="custom-select" id="years" name="y" required>
                                    <option value="">-- Pilih Tahun --</option>
                                    <?php
                                    $tg_awal = $yearsNow - 2;
                                    $tgl_akhir = $yearsNow + 2;
                                    for ($p = $tg_awal; $p <= $tgl_akhir; $p++) : ?>
                                        <option value="<?= $p; ?>" <?= ($years) ? ($p == $years) ? 'selected' : '' : ''; ?>><?= $p; ?> </option>
                                    <?php endfor; ?>
                                </select>
                                <div class="input-group-append">
                                    <button class="btn btn-primary" type="submit">Lihat Data</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <br>
            <div class="table-responsive">
                <table class="table dataTable">
                    <thead>
                        <th>#</th>
                        <th>Tanggal Transaksi</th>
                        <th>Invoice</th>
                        <th>Total Transaksi</th>
                        <th class="text-center">Metode Pembayaran</th>
                        <th class="text-center">Status Transaksi</th>
                        <th>Nama Member</th>
                        <th>Nama Kasir</th>
                        <th>Aksi</th>
                    </thead>
                    <tbody>
                        <?php
                        if ($SalesOrder) :
                            $i = 1;
                            foreach ($SalesOrder as $salesOrder) :
                        ?>
                                <tr>
                                    <td><?= $i++; ?></td>
                                    <td>
                                        <?php $prdate = new DateTime($salesOrder['sales_order_created_at']);
                                        echo date_indo($prdate->format('Y-m-d')) . ', ' . $prdate->format('H:i');  ?>
                                    </td>
                                    <td>
                                        <a href="<?= base_url('salesOrderHistory?id=' . $salesOrder['sales_order_invoices'] . '&p=' . $salesOrder['sales_order_transaction_id']); ?>" class="text-primary">
                                            <?= $salesOrder['sales_order_invoices']; ?>
                                        </a>
                                    </td>
                                    <td>Rp. <?= number_format($salesOrder['sales_order_total'] - $salesOrder['sales_order_discount']); ?></td>
                                    <td class="text-center"><?= ($salesOrder['payment_method_id'] == 0) ? '' : $salesOrder['payment_method_name']; ?></td>
                                    <td class="text-center">
                                        <?php if ($salesOrder['sales_order_status'] == 1) { ?>
                                            <span class="badge badge-success">BERHASIL </span>
                                        <?php } else if ($salesOrder['sales_order_status'] == 2) { ?>
                                            <span class="badge badge-danger"> DIBATALKAN </span>
                                        <?php } else if ($salesOrder['sales_order_status'] == 0) { ?>
                                            <span class="badge badge-warning"> DITUNDA </span>
                                        <?php } ?>
                                    </td>
                                    <td><?= ($salesOrder['customer_id'] == 1) ? 'umum' : $salesOrder['customer_fullname']; ?></td>
                                    <td><?= $salesOrder['employee_name']; ?></td>
                                    <td>
                                        <?php if ($salesOrder['sales_order_status'] != 2) : ?>
                                            <div class="n-chk">
                                                <label class="new-control new-checkbox checkbox-primary">
                                                    <input type="hidden" name="invoiceId" id="Invoice">
                                                    <input type="checkbox" class="new-control-input BtnUpdate" id="TaxType" data-type="<?= ($salesOrder['tax_type'] == 1) ? '0' : '1'; ?>" name="taxType" data-invoice="<?= $salesOrder['sales_order_invoices']; ?>" <?= ($salesOrder['tax_type'] == 1) ? 'checked' : ''; ?>>
                                                    <span class="new-control-indicator"></span>Pajak Perusahaan
                                                </label>
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <?php if ($TotalTransaction) : ?>
                <table style="border: 2px solid;">
                    <tr>
                        <td style='text-align:left; font-size:15pt; padding: 15px; color:black'> Grand Total Transaksi Bulan <?= bulan($month); ?>: <b>RP. <?= number_format($totalDiscount['sales_order_total'] - $totalDiscount['sales_order_discount']); ?></b></td>
                    </tr>
                    <tr>
                        <td style='text-align:left; font-size:15pt;  padding: 15px; color:black'>Jumlah Penjualan Produk Bulan <?= bulan($month); ?>: <b><?= $TotalTransaction['sales_order_quantity']; ?></b> pcs</td>
                    </tr>
                </table>
            <?php endif; ?>
        </div>
    </div>
</div>
</div>


<script>
    $('.BtnUpdate').click(function() {
        const invoiceId = $(this).data("invoice");
        const tax = $(this).data("type");
        $.ajax({
            url: "<?= base_url('transactionSelling/update'); ?>",
            type: 'POST',
            data: {
                invoice: invoiceId,
                taxType: tax
            },
            success: function() {
                function tempAlert(msg, duration) {
                    var el = document.createElement("div");
                    el.setAttribute("style", "position:absolute;top:20%;left:45%;background-color:white;border: 2px solid;");
                    el.setAttribute("class", "btn btn-outline-success")
                    el.innerHTML = msg;
                    setTimeout(function() {
                        el.parentNode.removeChild(el);
                    }, duration);
                    document.body.appendChild(el);
                }
                tempAlert("Pajak Telah Di Ubah !", 1000);
                // location.reload();
            }
        });
    });
</script>
<?= $this->endSection(); ?>