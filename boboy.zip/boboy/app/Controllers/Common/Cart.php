<?php

namespace App\Controllers\Common;

use App\Controllers\BaseController;
use App\Models\SalesModel;

class Cart extends BaseController
{
    function __construct()
    {
        $this->SalesModel = new SalesModel();
    }
    public function insertCart()
    {
        $this->cart->insert([
            'id'      => $this->request->getPost('id'),
            'name'    => $this->request->getPost('name'),
            'qty'     => $this->request->getPost('qty'),
            'price'   => $this->request->getPost('price'),
            'options' => []
        ]);
        echo $this->showCart();
    }

    public function showCart()
    {
        $inputDiscount = $this->request->getPost('discount');
        if (!$inputDiscount) {
            $discountTotal   = 0;
            $grandTotal    = 0;
        }
        $output = '';
        $no     = 0;
        $totalQty = 0;
        foreach ($this->cart->contents() as $items) {
            $per                = str_replace(" per ", "/", $items['name']);
            $perdua             = str_replace(" perdua ", "/", $per);
            $and                = str_replace(" dan ", "+", $perdua);
            $dandua             = str_replace(" dan2 ", "&", $and);
            $petikdua           = str_replace(" petikdua ", '"', $dandua);
            $petik              = str_replace(" petik ", "'", $petikdua);
            $titikdua           = str_replace(" titikdua ", ":", $petik);
            $garis              = str_replace(" garis ", "|", $titikdua);
            $petikbalik         = str_replace(" petikbalik ", "`", $garis);
            $bebas              = str_replace(" bebas ", "~", $petikbalik);
            $strip              = str_replace(" strip ", "-", $bebas);
            $open               = str_replace(" kurungbuka ", "(", $strip);
            $name               = str_replace(" kurungtutup ", ")", $open);
            $discountTotal      = ($inputDiscount / 100) * $this->cart->total();
            $grandTotal         = $this->cart->total() - $discountTotal;
            $no++;
            $totalQty += $items['qty'];
            $output .= '
                <tr>
                    <td>' . $no . '</td>
					<td>' . $name . '</td>
					<td>Rp. ' . number_format($items['price']) . '</td>
					<td>' . $items['qty'] . '</td>
					<td class="text-center">Rp. ' . number_format($items['subtotal']) . '</td>
					<td><button type="button" id="' . $items['rowid'] . '" class="removeCartId btn btn-danger btn-rounded btn-xs">Hapus</button></td>
				</tr>
			';
        }
        $output .= '
              <tr>
                <td colspan=4><h5><b>TOTAL : </b></h5></td>
                <td class="font-weight-bold"><h5> <b> ' . $totalQty . ' Pcs</b></h5></td>
              </tr>
		    ';
        return $output;
    }
    public function insertStockCart()
    {
        $this->cart->insert([
            'id'      => $this->request->getPost('id'),
            'name'    => $this->request->getPost('name'),
            'qty'     => $this->request->getPost('qty'),
            'price'   => $this->request->getPost('price'),
            'options' => []
        ]);
        echo $this->showStockCart();
    }
    public function showStockCart()
    {
        $output = '';
        $no     = 0;
        foreach ($this->cart->contents() as $items) {
            $per                = str_replace(" per ", "/", $items['name']);
            $perdua             = str_replace(" perdua ", "/", $per);
            $and                = str_replace(" dan ", "+", $perdua);
            $dandua             = str_replace(" dan2 ", "&", $and);
            $petikdua           = str_replace(" petikdua ", '"', $dandua);
            $petik              = str_replace(" petik ", "'", $petikdua);
            $titikdua           = str_replace(" titikdua ", ":", $petik);
            $garis              = str_replace(" garis ", "|", $titikdua);
            $petikbalik         = str_replace(" petikbalik ", "`", $garis);
            $bebas              = str_replace(" bebas ", "~", $petikbalik);
            $strip              = str_replace(" strip ", "-", $bebas);
            $open               = str_replace(" kurungbuka ", "(", $strip);
            $name               = str_replace(" kurungtutup ", ")", $open);
            $no++;
            $output .= '
                <tr>
                    <td>' . $no . '</td>
					<td>' . $name . '</td>
                    <td>Rp. ' . number_format($items['price']) . '</td>
					<td>' . $items['qty'] . '</td>
					<td><button type="button" id="' . $items['rowid'] . '" class="removeStockCartId btn btn-danger btn-rounded btn-xs">Hapus</button></td>
				</tr>
			';
        }
        return $output;
    }
    public function destroyCart()
    {
        $this->cart->destroy();
        echo $this->showCart();
    }
    public function removeCart()
    {
        $this->cart->remove($this->request->getPost('rowid'));
        echo $this->showCart();
    }
    public function destroyStockCart()
    {
        $this->cart->destroy();
        echo $this->showStockCart();
    }
    public function removeStockCart()
    {
        $this->cart->remove($this->request->getPost('rowid'));
        echo $this->showStockCart();
    }

    function loadCart()
    {
        echo $this->showCart();
    }
    function loadStockCart()
    {
        echo $this->showStockCart();
    }

    function salesReturnCart()
    {
        $this->cart->update([
            'qty' => $this->request->getVar('qtyReturn'),
            'returnReason' => $this->request->getVar('returnReason'),
            'rowid' => $this->request->getVar('row_id'),
            'option' => []
        ]);
        echo $this->showSalesReturnCart();
    }

    function loadSalesReturnCart()
    {
        echo $this->showSalesReturnCart();
    }
    function showSalesReturnCart()
    {
        $i = 0;
        $output = '';
        foreach ($this->cart->contents() as $items) {
            $per                = str_replace(" per ", "/", $items['name']);
            $perdua             = str_replace(" perdua ", "/", $per);
            $and                = str_replace(" dan ", "+", $perdua);
            $dandua             = str_replace(" dan2 ", "&", $and);
            $petikdua           = str_replace(" petikdua ", '"', $dandua);
            $petik              = str_replace(" petik ", "'", $petikdua);
            $titikdua           = str_replace(" titikdua ", ":", $petik);
            $garis              = str_replace(" garis ", "|", $titikdua);
            $petikbalik         = str_replace(" petikbalik ", "`", $garis);
            $bebas              = str_replace(" bebas ", "~", $petikbalik);
            $strip              = str_replace(" strip ", "-", $bebas);
            $open               = str_replace(" kurungbuka ", "(", $strip);
            $name               = str_replace(" kurungtutup ", ")", $open);
            $i++;
            $output .= '
            <tr class="text-center">
                <td>' . $i . '</td>
                <td>' . $name . '</td>
                <td>' . $items['qtyEarly'] . '</td>
                <td>Rp.' . number_format($items['price']) . '</td>
                <td>Rp.' . number_format($items['subtotal']) . '</td>
                <td>
                ';
            if ($items['qty'] > 0) {
                $output .= '<button class="btn btn-success" disabled>Returned</button>';
            } elseif ($items == null || $items['qty'] < 1) {
                $output .= '<button class="btn btn-warning" data-toggle="modal" data-target="#formProductAddModal' . $items['rowid'] . '">Retur</button>';
            }
            $output .= ' </td></tr> ';
        }
        $output .= '
                <tr>
                  <td colspan="5">Total Uang Kembali :</td>
                  <td>Rp. ' . number_format($this->cart->total()) . '</td>
                </tr>
		    ';

        return $output;
    }
    public function insertChasierCart()
    {
        $qty = $this->request->getPost('qty');
        $discountByQty = $this->SalesModel->getDiscountProductByQty();
        $inputDiscount = 0;
        $totalDiscount = 0;

        $discountByProduct = $this->SalesModel->getDiscountProductBySubdepartment($this->request->getPost('id'));
        $subtotal = $qty * $this->request->getPost('price');
        if ($discountByProduct == null) {
            foreach ($discountByQty as $discountQty) {
                if ($qty >= $discountQty['min_item'] && $qty < $discountQty['max_item'] || $qty == $discountQty['min_item']) {
                    $inputDiscount = $discountQty['precentage'];
                    $totalDiscount = $subtotal * ($discountQty['precentage'] / 100);
                }
            }
        } elseif ($discountByProduct) {
            $inputDiscount = $discountByProduct['precentage'];
            $totalDiscount = $subtotal * ($discountByProduct['precentage'] / 100);
        }
        if ($this->request->getPost('customer') == "") {
            $cust = 0;
        } else {
            $cust = $this->request->getPost('customer');
        }

        $this->cart->insert([
            'id'        => $this->request->getPost('id'),
            'name'      => $this->request->getPost('name'),
            'qty'       => $qty,
            'price'     => $this->request->getPost('price'),
            'sku'       => $this->request->getPost('sku'),
            'discount'  => $inputDiscount,
            'totaldisc' => $totalDiscount,
            'invoice'   => 0,
            'customer'  => $cust,
            'bonus'     => 0,
            'options'   => []
        ]);
        // dd($this->cart->contents());
        echo $this->showChasierCart();
    }

    public function updateCashierCart()
    {
        $qty = $this->request->getPost('qty');
        $discountByQty = $this->SalesModel->getDiscountProductByQty();
        $inputDiscount = 0;
        $totalDiscount = 0;

        foreach ($this->cart->contents() as $cart) {
            if ($this->request->getPost('id') == $cart['id']) {
                foreach ($discountByQty as $discountQty) {
                    if ($cart['qty'] >= $discountQty['min_item'] && $cart['qty'] < $discountQty['max_item'] || $qty == $discountQty['min_item']) {
                        $inputDiscount = $discountQty['precentage'];
                        $subtotal = $qty * $cart['price'];
                        $totalDiscount = $subtotal * ($discountQty['precentage'] / 100);
                    }
                }
            }
            $discountByProduct = $this->SalesModel->getDiscountProductBySubdepartment($cart['id']);
            $subtotal = $qty * $cart['price'];
            if ($discountByProduct == null) {
                foreach ($discountByQty as $discountQty) {
                    if ($qty >= $discountQty['min_item'] && $qty < $discountQty['max_item'] || $qty == $discountQty['min_item']) {
                        $inputDiscount = $discountQty['precentage'];
                        $totalDiscount = $subtotal * ($discountQty['precentage'] / 100);
                    }
                }
            } elseif ($discountByProduct) {
                $inputDiscount = $discountByProduct['precentage'];
                $totalDiscount = $subtotal * ($discountByProduct['precentage'] / 100);
            }
        }

        $this->cart->update([
            'rowid'     => $this->request->getPost('rowid'),
            'qty'       => $this->request->getPost('qty'),
            'discount'  => $inputDiscount,
            'totaldisc' => $totalDiscount,
        ]);
        echo $this->loadChasierCart();
    }

    public function updateCashierCartDiscount()
    {
        $qty            = $this->request->getPost('qty');
        $inputDiscount  = $this->request->getPost('discount');
        $subtotal       = $qty * $this->request->getPost('price');
        $totalDiscount  = $subtotal * ($inputDiscount / 100);
        $this->cart->update([
            'rowid'     => $this->request->getPost('rowid'),
            'qty'       => $this->request->getPost('qty'),
            'discount'  => $inputDiscount,
            'totaldisc' => $totalDiscount,
        ]);
        echo $this->loadChasierCart();
    }
    public function updateCashierCartDiscountMember()
    {
        $this->cart->update([
            'rowid'     => $this->request->getPost('rowid'),
            'customer'  => $this->request->getPost('customer'),
        ]);
        echo $this->loadChasierCart();
    }
    public function updateCashierCartDiscountBonus()
    {
        $this->cart->update([
            'rowid'     => $this->request->getPost('rowid'),
            'bonus'     => $this->request->getPost('member_code'),
        ]);
        echo $this->loadChasierCart();
    }
    function loadChasierCart()
    {
        echo $this->showChasierCart();
    }
    public function showChasierCart()
    {
        $inputTax = 10;
        $inputDiscount = $this->request->getPost('discountmanual');
        if (!$inputDiscount) {
            $inputDiscount =  0;
        }
        $TotalTax   = 0;
        $nominalDiscountMember = 0;
        $sumDiscount = 0;
        $subtotalDiscount = 0;
        $subtotal = 0;
        $output = '';
        $no     = 0;
        $discountMember = 0;
        $discountBirthday = 0;
        $discountBonus = 0;
        $allItem = $this->cart->contents();
        foreach ($allItem as $items) {
            $per                = str_replace(" per ", "/", $items['name']);
            $perdua             = str_replace(" perdua ", "/", $per);
            $and                = str_replace(" dan ", "+", $perdua);
            $dandua             = str_replace(" dan2 ", "&", $and);
            $petikdua           = str_replace(" petikdua ", '"', $dandua);
            $petik              = str_replace(" petik ", "'", $petikdua);
            $titikdua           = str_replace(" titikdua ", ":", $petik);
            $garis              = str_replace(" garis ", "|", $titikdua);
            $petikbalik         = str_replace(" petikbalik ", "`", $garis);
            $bebas              = str_replace(" bebas ", "~", $petikbalik);
            $strip              = str_replace(" strip ", "-", $bebas);
            $open               = str_replace(" kurungbuka ", "(", $strip);
            $name               = str_replace(" kurungtutup ", ")", $open);
            if ($items['invoice'] != null) {
                $invoice = $items['invoice'];
            } else {
                $invoice = null;
            }

            #subtotal 
            $subtotal = $items['subtotal'] - $items['totaldisc'];

            $no++;
            $output .= '
                <tr>
                    <td>' . $no . '</td>
					<td>' . $name . '</td>
					<td >Rp. ' . number_format($items['price']) . '</td>
					<td width="15%">
                        <input type="number" min="1" class="form-control inputQuantity" id="' . $items['rowid'] . '" value="' . $items['qty'] . '" data-price="' . $items['price'] . '" >
                    </td>
                    <td width="15%">
                    <input type="hidden" name="invoices" id="invoices" value="' . $invoice . '">
                    <input type="number" min="0" class="form-control inputDiscount" id="' . $items['rowid'] . '" value="' . $items['discount'] . '" data-qty="' . $items['qty'] . '" data-price="' . $items['price'] . '">
                    </td>
                    <td class="text-right">
                    <input type="hidden" name="discountItem" id="discountItem" value="' . $items['totaldisc'] . '">
                    <input type="hidden" name="" id="ProdctID" value="' . $items['rowid'] . '">
                    Rp.' . number_format($items['totaldisc']) . '
                    </td>
					<td class="text-right">Rp. ' . number_format($subtotal) . '</td>
                    <td><button type="button" id="' . $items['rowid'] . '" class="removeStockChasiertId btn btn-danger btn-rounded btn-xs">Hapus</button></td>
                </tr>
                    ';
            $subtotalDiscount += $items['totaldisc'];
            $sumDiscount += $subtotal;
            if ($items['customer'] != 0) {
                $discountMember = $this->SalesModel->getDiscountMember(1);
                $discountBirthday = $this->SalesModel->getDiscountProductByBirthdayDate($items['customer']);
            }
            if ($items['bonus'] != 0) {
                $discountBonus = $this->SalesModel->discountBonusClaimed($items['bonus']);
            }
        }
        $TotalTax = $sumDiscount * ($inputTax / 100);
        #jika ada member maka ada tambahan diskon
        if ($discountMember != 0 || $discountMember != null) {
            if ($discountBirthday == 0 || $discountBirthday == null) {
                $nominalDiscountMember = $sumDiscount  * ($discountMember['precentage'] / 100);
            } else {
                $nominalDiscountMember = $sumDiscount  * ($discountBirthday['precentage'] / 100);
            }
            $Discount = $subtotalDiscount + (($inputDiscount / 100) * $sumDiscount) + $nominalDiscountMember + $discountBonus;
            $total = $sumDiscount - (($inputDiscount / 100) * $sumDiscount) - $nominalDiscountMember - $discountBonus;
        } else {
            $Discount = $subtotalDiscount + (($inputDiscount / 100) * $sumDiscount) - $discountBonus;
            $total = $sumDiscount - (($inputDiscount / 100) * $sumDiscount) - $discountBonus;
        }

        $output .= '
        <tr>
        <td colspan=7><input type="hidden" name="discountTotal" id="discountTotal" value="' . $Discount . '"><input type="hidden" name="taxTotal" id="taxTotal" value="' .  $TotalTax . '"><h5><b>Total Diskon : </b></h5></td>
        <td class="font-weight-bold" id="Discount"><h5> <b>Rp. ' . number_format($Discount) . ' </b></h5></td>
        </tr>
        
        <tr>
          <td colspan=7><input type="hidden" name="grandTotal" id="grandTotal" value="' . $total . '"><h3><b>TOTAL : </b></h3></td>
          <td class="font-weight-bold" ><h3> <b>Rp. ' . number_format($total) . ' </b></h3></td>
          </tr>
          ';
        return $output;
    }
    public function destroyChasierCart()
    {
        $this->cart->destroy();
        echo $this->showChasierCart();
    }
    public function removeCartChasier()
    {
        $this->cart->remove($this->request->getPost('rowid'));
        echo $this->showChasierCart();
    }
    public function continueTransaction()
    {
        $this->cart->destroy();
        $dataSalesOrder = $this->request->getPost('sales');
        $SalesOrderProducts = $this->db->table('sales_order_product')->where(['sales_id' => $dataSalesOrder])->get()->getResultArray();
        $SalesOrder = $this->db->table('sales_order')->where(['id' => $dataSalesOrder])->get()->getRowArray();
        foreach ($SalesOrderProducts as $salesOrder) {
            $products = $this->db->table('products')->where(['id' => $salesOrder['product_id']])->get()->getRowArray();
            $per                = str_replace("/", " per ", $products['product_name']);
            $perdua             = str_replace("/", " perdua ", $per);
            $and                = str_replace("+", " dan ", $perdua);
            $and2               = str_replace("&", " dan2 ", $and);
            $quotes             = str_replace('"', " petikdua ", $and2);
            $quote              = str_replace("'", " petik ", $quotes);
            $colon              = str_replace(":", " titikdua ", $quote);
            $line               = str_replace("|", " garis ", $colon);
            $backtig            = str_replace("`", " petikbalik ", $line);
            $free               = str_replace("~", " bebas ", $backtig);
            $strip              = str_replace("-", " strip ", $free);
            $open               = str_replace("(", " kurungbuka ", $strip);
            $name               = str_replace(")", " kurungtutup ", $open);

            if ($SalesOrder['customer_id'] == 1) {
                $customer = 0;
            } else {
                $customer = $SalesOrder['customer_id'];
            }
            $this->cart->insert([
                'id'        => $salesOrder['product_id'],
                'name'      => $name,
                'qty'       => $salesOrder['sales_order_quantity'],
                'price'     => $salesOrder['sales_order_price'],
                'sku'       => $products['product_sku'],
                'customer'  => $customer,
                'discount'  => $salesOrder['sales_order_product_precentage_discount'],
                'totaldisc' => $salesOrder['sales_order_product_discount'],
                'invoice'   => $SalesOrder['sales_order_invoices'],
                'bonus'     => '0',
                'options'   => []
            ]);
        }
        echo $this->loadChasierCart();
    }
    public function searchProduct()
    {
        if ($this->request->getPost('customer') == "") {
            $cust = 0;
        } else {
            $cust = $this->request->getPost('customer');
        }
        $dataSku = $this->request->getPost('sku');
        $products = $this->db->table('products')->where(['product_sku' => $dataSku])->get()->getRowArray();
        if ($products) {
            $stockProduct = $this->db->table('stock_product')->where(['product_id' => $products['id'], 'branch_id' => session()->get('branch_id')])->get()->getRowArray();
            $inputDiscount = 0;
            $totalDiscount = 0;
            $getPresentage = $this->SalesModel->getDiscountProductByQty();
            if ($this->cart->contents())
                foreach ($this->cart->contents() as $cart) {
                    if ($stockProduct['product_id'] == $cart['id']) {
                        $discountByProduct = $this->SalesModel->getDiscountProductBySubdepartment($stockProduct['product_id']);
                        $subtotal = $cart['qty'] * $cart['price'];
                        if ($discountByProduct) {
                            $inputDiscount = $discountByProduct['precentage'];
                            $totalDiscount = $subtotal * ($discountByProduct['precentage'] / 100);
                        } else {
                            if ($stockProduct['product_id'] == $cart['id']) {
                                foreach ($getPresentage as $presentage) {
                                    if ($cart['qty'] >= $presentage['min_item'] && $cart['qty'] < $presentage['max_item']) {
                                        $inputDiscount = $presentage['precentage'];
                                        $subtotal = $cart['qty'] * $products['product_selling_price'];
                                        $totalDiscount = $subtotal * ($presentage['precentage'] / 100);
                                    }
                                }
                            }
                        }
                    }
                }
            else {
                $discountByProduct = $this->SalesModel->getDiscountProductBySubdepartment($stockProduct['product_id']);
                $subtotal = 1 * $products['product_selling_price'];
                if ($discountByProduct) {
                    $inputDiscount = $discountByProduct['precentage'];
                    $totalDiscount = $subtotal * ($discountByProduct['precentage'] / 100);
                } else {
                    foreach ($getPresentage as $presentage) {
                        if (1 >= $presentage['min_item'] && 1 < $presentage['max_item']) {
                            $inputDiscount = $presentage['precentage'];
                            $subtotal = 1 * $products['product_selling_price'];
                            $totalDiscount = $subtotal * ($presentage['precentage'] / 100);
                        }
                    }
                }
            }
            $per                = str_replace("/", " per ", $stockProduct['stock_product_name']);
            $perdua             = str_replace("/", " perdua ", $per);
            $and                = str_replace("+", " dan ", $perdua);
            $and2               = str_replace("&", " dan2 ", $and);
            $quotes             = str_replace('"', " petikdua ", $and2);
            $quote              = str_replace("'", " petik ", $quotes);
            $colon              = str_replace(":", " titikdua ", $quote);
            $line               = str_replace("|", " garis ", $colon);
            $backtig            = str_replace("`", " petikbalik ", $line);
            $free               = str_replace("~", " bebas ", $backtig);
            $strip              = str_replace("-", " strip ", $free);
            $open               = str_replace("(", " kurungbuka ", $strip);
            $name               = str_replace(")", " kurungtutup ", $open);


            $this->cart->insert([
                'id'        => $products['id'],
                'name'      => $name,
                'qty'       => 1,
                'price'     => $products['product_selling_price'],
                'sku'       => $products['product_sku'],
                'discount'  => $inputDiscount,
                'totaldisc' => $totalDiscount,
                'invoice'   => 0,
                'customer'  => $cust,
                'bonus'     => 0,
                'options'   => []
            ]);

            echo $this->showChasierCart();
        } else {
            return false;
        }
    }
}
