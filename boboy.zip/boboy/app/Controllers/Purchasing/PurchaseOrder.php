<?php

namespace App\Controllers\Purchasing;

use App\Models\MasterModel;
use App\Models\PurchasingModel;
use App\Controllers\BaseController;

class PurchaseOrder extends BaseController
{
	function __construct()
	{
		$this->PurchasingModel = new PurchasingModel();
		$this->MasterModel = new MasterModel();
	}
	public function index()
	{
		$branch = $this->request->getGet('branch');
		if ($branch != null) {
			$Purchasing = $this->PurchasingModel->getPurchaseOrderBranch($branch);
		} else {
			$Purchasing = $this->PurchasingModel->getPurchaseOrderBranch();
		}
		$data = array_merge($this->data, [
			'category'      	=> 'Transaksi',
			'title'         	=> 'Pembelian',
			'PurchaseOrders' 	=> $Purchasing,
			'Branch'    		=> $this->MasterModel->getBranch(),
			'inputBranch'		=> $branch
		]);
		return view('purchasing/purchaseOrderList', $data);
	}

	public function createPurchaseOrder()
	{
		$this->cart->destroy();
		$data = array_merge($this->data, [
			'category'      	=> 'Transaksi',
			'title'         	=> 'Pembelian',
			'Products'  		=> $this->MasterModel->getProducts(),
			'InvPurchaseOrder'  => $this->PurchasingModel->getMaxPurchaseOrder(),
			'Suppliers'    		=> $this->PurchasingModel->getSuppliers(),
		]);
		return view('purchasing/purchaseOrderForm', $data);
	}
	public function savePurchaseOrder()
	{
		$savePurchaseOrder = $this->PurchasingModel->savePurchaseOrder($this->request->getPost(null), $this->cart->contents(), $this->cart->total());
		if ($savePurchaseOrder) {
			session()->setFlashdata('notif_success', '<b>Data pembelian berhasil disimpan</b>');
			$this->cart->destroy();
			return redirect()->to(base_url('purchaseOrder'));
		} else {
			session()->setFlashdata('notif_error', '<b>Gagal menyimpan data pembelian</b>');
			return redirect()->to(base_url('createPurchaseOrder'));
		}
	}
	public function detailPurchaseOrder()
	{
		$data = array_merge($this->data, [
			'category'      	=> 'Transaksi',
			'title'         	=> 'Pembelian',
			'PurchaseOrders' 	=> $this->PurchasingModel->getPurchaseOrder($this->request->getGet('id')),
			'Branch'    		=> $this->MasterModel->getBranch(),
			'Products'  		=> $this->PurchasingModel->getPurchaseOrderProduct($this->request->getGet('id')),
		]);
		return view('purchasing/purchaseOrderDetail', $data);
	}
	public function saveStatusPurchaseOrder()
	{
		$updateStatusPurchaseOrder = $this->PurchasingModel->updateStatusPurchaseOrder($this->request->getPost(null));
		if ($updateStatusPurchaseOrder) {
			session()->setFlashdata('notif_success', '<b>Status pembelian berhasil diubah</b>');
			$this->cart->destroy();
			return redirect()->to(base_url('handoverStuff'));
		} else {
			session()->setFlashdata('notif_error', '<b>Gagal mengubah status pembelian</b>');
			return redirect()->to(base_url('handoverStuff'));
		}
	}
}
