<?php

namespace App\Models;

use CodeIgniter\Model;

helper('text');

class SalesModel extends Model
{
    public function getCustomers($CustomersCode = false)
    {
        if ($CustomersCode) {
            return $this->db->table('customers')
                ->select('*, customers.id AS customersID, province.id as provinceID, city.id AS cityID, subdistrict.id AS subdistrictID')
                ->join('province', 'customers.customer_province = province.id')
                ->join('city', 'customers.customer_city = city.id')
                ->join('subdistrict', 'customers.customer_subdistrict = subdistrict.id')
                ->where(['customers.customer_code' => $CustomersCode])
                ->get()->getRowArray();
        } else {
            return $this->db->table('customers')
                ->select('*, customers.id AS customersID, province.id as provinceID, city.id AS cityID, subdistrict.id AS subdistrictID')
                ->join('province', 'customers.customer_province = province.id')
                ->join('city', 'customers.customer_city = city.id')
                ->join('subdistrict', 'customers.customer_subdistrict = subdistrict.id')
                ->get()->getResultArray();
        }
    }
    public function getMemberByCode($code = false)
    {
        return $this->db->table('customers')
            ->where(['customer_code' => $code])
            ->get()->getRowArray();
    }
    public function discountBonusClaimed($code = false)
    {
        $member = $this->db->table('customers')->where(['customer_code' => $code])->get()->getRowArray();
        if ($member['customer_points'] >= 10000 || $member['customer_points'] == 10000) {
            return 10000;
        } else {
            return 0;
        }
    }
    public function getMember()
    {
        return $this->db->table('customers')->where(['customer_is_active' => 1])->get()->getResultArray();
    }
    public function createCustomers($dataCustomers)
    {
        $getMax    = $this->db->table('customers')->selectMax('customers.id')->get()->getRowArray();
        if ($getMax['id'] != NULL) {
            $maxNumber = $getMax['id'] + 1;
            $maxNumber = sprintf("%05s", $maxNumber);
        } else {
            $maxNumber = '00001';
        }
        $codeCustomers = date('ymdHi') . '0' . session()->get('branch_id') . $maxNumber;
        return $this->db->table('customers')->insert([
            'customer_code'             => $codeCustomers,
            'customer_fullname'         => $dataCustomers['inputCustomerFullname'],
            'customer_birthday'         => $dataCustomers['inputCustomerBirthday'],
            'customer_address'          => $dataCustomers['inputCustomerAddress'],
            'customer_subdistrict'      => $dataCustomers['inputCustomerSubdistrict'],
            'customer_city'             => $dataCustomers['inputCustomerCity'],
            'customer_province'         => $dataCustomers['inputCustomerProvince'],
            'customer_telephone'        => $dataCustomers['inputCustomerTelephone'],
            'customer_email'            => $dataCustomers['inputCustomerEmail'],
            'customer_points'           => 0,
            'customer_start_effective'  => 0,
            'customer_end_effective'    => 0,
            'customer_is_active'        => $dataCustomers['inputCustomerIsActive'],
            'customer_created_by'       => session()->get('user_id'),
            'customer_created_at'       => date('Y-m-d H:i:s'),
        ]);
    }
    public function updateCustomers($dataCustomers)
    {
        if ($dataCustomers['inputCustomerBirthday'] == 0) {
            return false;
        }
        return $this->db->table('customers')->update([
            'customer_code'             => $dataCustomers['inputCustomerCode'],
            'customer_fullname'         => $dataCustomers['inputCustomerFullname'],
            'customer_birthday'         => $dataCustomers['inputCustomerBirthday'],
            'customer_address'          => $dataCustomers['inputCustomerAddress'],
            'customer_subdistrict'      => $dataCustomers['inputCustomerSubdistrict'],
            'customer_city'             => $dataCustomers['inputCustomerCity'],
            'customer_province'         => $dataCustomers['inputCustomerProvince'],
            'customer_telephone'        => $dataCustomers['inputCustomerTelephone'],
            'customer_email'            => $dataCustomers['inputCustomerEmail'],
            // 'customer_start_effective'  => $dataCustomers['inputCustomerStartEffective'],
            // 'customer_end_effective'    => $dataCustomers['inputCustomerEndEffective'],
            'customer_is_active'        => $dataCustomers['inputCustomerIsActive'],
            'customer_updated_by'       => session()->get('user_id'),
            'customer_updated_at'       => date('Y-m-d H:i:s')
        ], ['id' => $dataCustomers['customersID']]);
    }
    public function deleteCustomers($CustomersID)
    {
        $checkSales = $this->db->table('sales_order')->where(['customer_id' => $CustomersID])->countAllResults();
        if ($checkSales > 1) {
            return "Tidak";
        } else {
            return $this->db->table('customers')->delete(['id' => $CustomersID]);
        }
    }
    public function getSalesOrder($SalesOrderID = false)
    {
        if ($SalesOrderID) {
            return $this->db->table('sales_order')
                ->select('*, sales_order.id AS salesOrderID, branch.id AS branchID, customers.id AS customerID, payment_method.id AS paymentMethodID, employee.id AS employeeID')
                ->join('branch', 'sales_order.branch_id = branch.id')
                ->join('customers', 'sales_order.customer_id = customers.id')
                ->join('employee', 'sales_order.sales_order_void_by = employee.id')
                ->join('payment_method', 'sales_order.payment_method_id = payment_method.id')
                ->where(['sales_order.id' => $SalesOrderID])
                ->get()->getRowArray();
        } else {
            return $this->db->table('sales_order')
                ->like(['sales_order_created_at' => date('Y-m-d')])
                ->where(['branch_id' => session()->get('branch_id')])
                ->get()->getResultArray();
        }
    }
    public function getSalesOrderByBranch($date = false)
    {
        if ($date) {
            return $this->db->table('sales_order')
                ->select('*,sales_order.id AS salesOrderID, customers.id AS customerID')
                ->join('customers', 'sales_order.customer_id = customers.id')
                ->orderBy('sales_order_created_at', 'DESC')
                ->where(['sales_order.sales_order_status' => 1, 'branch_id' => session()->get('branch_id'), 'DATE(sales_order_created_at)' => $date])
                ->get()->getResultArray();
        }
        return $this->db->table('sales_order')
            ->select('*,sales_order.id AS salesOrderID, customers.id AS customerID')
            ->join('customers', 'sales_order.customer_id = customers.id')
            ->orderBy('sales_order_created_at', 'DESC')
            ->where(['sales_order.sales_order_status' => 1, 'branch_id' => session()->get('branch_id'), 'DATE(sales_order_created_at)' => date('Y-m-d')])
            ->get()->getResultArray();
    }
    public function getTotalByDate($date)
    {
        return $this->db->table('sales_order')
            ->select('*')
            // ->join('sales_order_product', 'sales_order.id = sales_order_product.sales_id')
            ->orderBy('sales_order_created_at', 'DESC')
            ->where(['sales_order.sales_order_status' => 1, 'branch_id' => session()->get('branch_id'), 'DATE(sales_order_created_at)' => $date])
            ->selectSum('sales_order_total')
            ->selectSum('sales_order_discount')
            ->get()->getRowArray();
    }
    public function getTotalByQty($date)
    {
        return $this->db->table('sales_order')
            ->join('sales_order_product', 'sales_order.id = sales_order_product.sales_id')
            ->orderBy('sales_order_created_at', 'DESC')
            ->where(['sales_order.sales_order_status' => 1, 'branch_id' => session()->get('branch_id'), 'DATE(sales_order_created_at)' => $date])
            ->selectSum('sales_order_product.sales_order_quantity')
            ->get()->getRowArray();
    }
    public function getTotalByDay($TransactionID)
    {
        return $this->db->table('sales_order')
            ->orderBy('sales_order_created_at', 'DESC')
            ->where(['sales_order.sales_order_status' => 1, 'branch_id' => session()->get('branch_id'), 'sales_order_transaction_id' => $TransactionID])
            ->selectSum('sales_order_total')
            ->selectSum('sales_order_discount')
            ->get()->getRowArray();
    }
    public function getTotalQty($TransactionID)
    {
        return $this->db->table('sales_order')
            ->join('sales_order_product', 'sales_order.id = sales_order_product.sales_id')
            ->orderBy('sales_order_created_at', 'DESC')
            ->where(['sales_order.sales_order_status' => 1, 'branch_id' => session()->get('branch_id'), 'sales_order_transaction_id' => $TransactionID])
            ->selectSum('sales_order_product.sales_order_quantity')
            ->get()->getRowArray();
    }
    public function getTotalByCashPayment($TransactionID)
    {
        return $this->db->table('sales_order')
            ->orderBy('sales_order_created_at', 'DESC')
            ->where(['sales_order.sales_order_status' => 1, 'branch_id' => session()->get('branch_id'), 'sales_order_transaction_id' => $TransactionID])
            ->selectSum('sales_order_total')
            ->selectSum('sales_order_discount')
            ->get()->getRowArray();
    }
    public function getTotalByCardPayment($TransactionID)
    {
        return $this->db->table('sales_order')
            ->orderBy('sales_order_created_at', 'DESC')
            ->where(['sales_order.sales_order_status' => 1, 'branch_id' => session()->get('branch_id'), 'sales_order_transaction_id' => $TransactionID])
            ->where(['payment_method_id >' => '1'])
            ->selectSum('sales_order_total')
            ->selectSum('sales_order_discount')
            ->get()->getRowArray();
    }
    public function getTotalByVoid($TransactionID)
    {
        return $this->db->table('sales_order')
            ->orderBy('sales_order_created_at', 'DESC')
            ->where(['sales_order.sales_order_status' => 2, 'branch_id' => session()->get('branch_id'), 'sales_order_transaction_id' => $TransactionID])
            ->selectSum('sales_order_total')
            ->selectSum('sales_order_discount')
            ->get()->getRowArray();
    }
    public function getSalesOrderByBranchCancel()
    {
        return $this->db->table('sales_order')
            ->orderBy('sales_order_created_at', 'DESC')
            ->where(['branch_id' => session()->get('branch_id'), 'DATE(sales_order_created_at)' => date('Y-m-d'), 'sales_order.sales_order_status' => 0])
            ->get()->getResultArray();
    }
    public function getSalesOrderByVoid()
    {
        return $this->db->table('sales_order')
            ->orderBy('sales_order_void_at', 'DESC')
            ->where(['branch_id' => session()->get('branch_id'), 'DATE(sales_order_void_at)' => date('Y-m-d'), 'sales_order.sales_order_status' => 2])
            ->get()->getResultArray();
    }
    public function getSalesOrderByBranchandMonth($branchId, $month, $years)
    {
        return $this->db->table('sales_order')
            ->select('*,sales_order.id AS salesOrderID, customers.id AS customerID')
            ->join('customers', 'sales_order.customer_id = customers.id')
            ->join('payment_method', 'payment_method.id = sales_order.payment_method_id')
            ->join('employee', 'sales_order.sales_order_cashier = employee.id')
            ->orderBy('sales_order_created_at', 'DESC')
            ->where('sales_order.sales_order_status >', 0)
            ->where(['branch_id' => $branchId, 'MONTH(sales_order_created_at)' => short_bulan($month), 'YEAR(sales_order_created_at)' => $years])
            ->get()->getResultArray();
    }
    public function getSalesTotalByBranchandMonth($branchId, $month, $years)
    {
        return $this->db->table('sales_order')
            ->select('*,sales_order.id AS salesOrderID')
            ->join('payment_method', 'payment_method.id = sales_order.payment_method_id')
            ->join('sales_order_product', 'sales_order.id = sales_order_product.sales_id')
            ->orderBy('sales_order_created_at', 'DESC')
            ->where(['branch_id' => $branchId, 'MONTH(sales_order_created_at)' => short_bulan($month), 'sales_order.sales_order_status' => 1, 'YEAR(sales_order_created_at)' => $years])
            ->selectSum('sales_order_product.sales_order_quantity')
            ->get()->getRowArray();
    }
    public function getSumDiscount($branchId, $month, $years)
    {
        return $this->db->table('sales_order')
            ->select('*,sales_order.id AS salesOrderID')
            ->where(['branch_id' => $branchId, 'MONTH(sales_order_created_at)' => short_bulan($month), 'sales_order.sales_order_status' => 1, 'YEAR(sales_order_created_at)' => $years])
            ->selectSum('sales_order_discount')->selectSum('sales_order_total')->get()->getRowArray();
    }
    public function getSalesOrderProductByBranchandMonth($branchId, $month, $years)
    {
        return $this->db->table('sales_order')
            ->select('*,sales_order.id AS salesOrderID, employee.id AS employeeID, products.id AS productID')
            ->join('employee', 'employee.id = sales_order.sales_order_cashier')
            ->join('sales_order_product', 'sales_order.id = sales_order_product.sales_id')
            ->join('products', 'sales_order_product.product_id = products.id')
            ->join('product_subdepartment', 'products.product_subdepartment_id = product_subdepartment.product_subdep_code')
            ->orderBy('sales_order_created_at', 'DESC')
            ->where(['branch_id' => $branchId, 'MONTH(sales_order_created_at)' => short_bulan($month), 'sales_order_status' => 1, 'YEAR(sales_order_created_at)' => $years])
            ->get()->getResultArray();
    }
    public function getSalesOrderProductByMonth($month, $years)
    {
        return $this->db->table('sales_order')
            ->select('*,sales_order.id AS salesOrderID, employee.id AS employeeID')
            ->join('sales_order_product', 'sales_order.id = sales_order_product.sales_id')
            ->join('employee', 'employee.id = sales_order.sales_order_cashier')
            ->join('products', 'sales_order_product.product_id = products.id')
            ->join('product_subdepartment', 'products.product_subdepartment_id = product_subdepartment.product_subdep_code')
            ->orderBy('sales_order_created_at', 'DESC')
            ->where(['branch_id' => session()->get('branch_id'), 'MONTH(sales_order_created_at)' => short_bulan($month), 'sales_order_status' => 1, 'YEAR(sales_order_created_at)' => $years])
            ->get()->getResultArray();
    }
    public function getSalesOrderProductBySalesOrder($invoice, $TransactionID)
    {
        return $this->db->table('sales_order_product')
            ->where(['sales_invoice' => $invoice, 'transaction_id' => $TransactionID])
            ->get()->getResultArray();
    }
    public function getProductByStock()
    {
        return $this->db->table('stock_product')
            ->select('*, products.id AS productID')
            ->join('products', 'stock_product.product_id = products.id')
            ->join('product_subdepartment', 'products.product_subdepartment_id = product_subdepartment.product_subdep_code')
            ->orderBy('stock_product_selling_price', 'ASC')
            ->where('stock_product_qty_new >', 0)
            ->where(['branch_id' => session()->get('branch_id')])
            ->get()->getResultArray();
    }
    public function getProductStockCard()
    {
        return $this->db->table('stock_product')
            ->select('*, products.id AS productID')
            ->join('products', 'stock_product.product_id = products.id')
            ->join('product_subdepartment', 'products.product_subdepartment_id = product_subdepartment.product_subdep_code')
            ->orderBy('product_subdepartment_id', 'ASC')
            ->orderBy('product_name', 'ASC')
            ->where(['branch_id' => session()->get('branch_id')])
            ->get()->getResultArray();
    }
    public function getSalesOrderByInvoice($invoice, $TransactionID)
    {
        return $this->db->table('sales_order')
            ->select('*, sales_order.id AS salesOrderID, branch.id AS branchID, customers.id AS customerID, employee.id AS employeeID,payment_method.id AS paymentMethodID,')
            ->join('branch', 'sales_order.branch_id = branch.id')
            ->join('customers', 'sales_order.customer_id = customers.id')
            ->join('employee', 'sales_order.sales_order_cashier = employee.id')
            ->join('payment_method', 'sales_order.payment_method_id = payment_method.id')
            ->where(['sales_order.sales_order_invoices' => $invoice, 'sales_order_transaction_id' => $TransactionID])
            ->get()->getRowArray();
    }
    public function saveTempSalesOrder($datamember, $dataSalesOrder, $total, $tax)
    {
        $getMax    = $this->db->table('sales_order')->selectMax('sales_order.id')->get()->getRowArray();
        if ($getMax['id'] != NULL) {
            if ($getMax['id'] == 99999) {
                $maxNumber = 1;
                $maxNumber = sprintf("%05s", $maxNumber);
            } else {
                $maxNumber = $getMax['id'] + 1;
                $maxNumber = sprintf("%05s", $maxNumber);
            }
        } else {
            $maxNumber = '00001';
        }
        if ($datamember == null) {
            $member = 1;
        } else {
            $member = $datamember;
        }

        $Invoices = session()->get('branch_code') .  date('dmy') . $maxNumber;
        $totalDiscount = 0;

        $this->db->transBegin();
        if ($dataSalesOrder &&  $total != null) {

            foreach ($dataSalesOrder as $salesOrder) {
                $totalDiscount += $salesOrder['totaldisc'];
            }
            $id = $getMax['id'] + 1;

            $Transaction = $this->db->table('transaction')
                ->like(['opening_at' => date('Y-m-d')])
                ->getWhere(['branch' => session()->get('branch_id'), 'opening_by' => session()->get('user_id'), 'closing_cash' => 0])
                ->getRowArray();

            $this->db->table('sales_order')->insert([
                'id'                            => $id,
                'sales_order_invoices'          => $Invoices,
                'branch_id'                     => session()->get('branch_id'),
                'customer_id'                   => $member,
                'sales_order_points'            => 0,
                'sales_order_cashier'           => session()->get('user_id'),
                'sales_order_discount'          => $totalDiscount,
                'sales_order_tax'               => $tax,
                'sales_order_total'             => $total,
                'sales_order_status'            => 0,
                'sales_order_created_at'        => date('Y-m-d H:i:s'),
                'sales_order_transaction_id'    => $Transaction['id']
            ]);

            # Ambil ID terakhir tabel pembelian
            $salesOrderID =  $this->db->insertID();
            foreach ($dataSalesOrder as $salesOrder) {
                $per                = str_replace(" per ", "/", $salesOrder['name']);
                $perdua             = str_replace(" perdua ", "/", $per);
                $and                = str_replace(" dan ", "+", $perdua);
                $dandua             = str_replace(" dan2 ", "&", $and);
                $petikdua           = str_replace(" petikdua ", '"', $dandua);
                $petik              = str_replace(" petik ", "'", $petikdua);
                $titikdua           = str_replace(" titikdua ", ":", $petik);
                $garis              = str_replace(" garis ", "|", $titikdua);
                $petikbalik         = str_replace(" petikbalik ", "`", $garis);
                $bebas              = str_replace(" bebas ", "~", $petikbalik);
                $strip              = str_replace(" strip ", "-", $bebas);
                $open               = str_replace(" kurungbuka ", "(", $strip);
                $name               = str_replace(" kurungtutup ", ")", $open);
                $disount = ($salesOrder['qty'] * $salesOrder['price']) * ($salesOrder['discount'] / 100);
                $this->db->table('sales_order_product')->insert([
                    'sales_id'                                  => $id,
                    'product_id'                                => $salesOrder['id'],
                    'sales_invoice'                             => $Invoices,
                    'transaction_id'                            => $Transaction['id'],
                    'sales_order_product_name'                  => $name,
                    'sales_order_quantity'                      => $salesOrder['qty'],
                    'sales_order_product_precentage_discount'   => $salesOrder['discount'],
                    'sales_order_product_discount'              => $disount,
                    'sales_order_price'                         => $salesOrder['price'],
                ]);

                #update tabel Product
                $productsStock          = $this->db->table('stock_product')->getWhere(['branch_id' => session()->get('branch_id'), 'product_id' => $salesOrder['id']])->getRowArray();
                $newAllProductStock     = $productsStock['stock_product_qty_new'] - $salesOrder['qty'];
                $productsStockBranch1          = $this->db->table('stock_product')->select('stock_product_qty_new')->getWhere(['branch_id' => 1, 'product_id' => $salesOrder['id']])->getRowArray();
                $productsStockBranch2          = $this->db->table('stock_product')->select('stock_product_qty_new')->getWhere(['branch_id' => 2, 'product_id' => $salesOrder['id']])->getRowArray();
                $productsStockBranch3          = $this->db->table('stock_product')->select('stock_product_qty_new')->getWhere(['branch_id' => 3, 'product_id' => $salesOrder['id']])->getRowArray();
                if ($newAllProductStock <= 0) {
                    $newAllProductStock = 0;
                }
                if (session()->get('branch_id') == 1) {
                    $newAllStock          = $productsStockBranch2['stock_product_qty_new'] + $productsStockBranch3['stock_product_qty_new'] +  $newAllProductStock;
                } elseif (session()->get('branch_id') == 2) {
                    $newAllStock          = $productsStockBranch1['stock_product_qty_new'] + $productsStockBranch3['stock_product_qty_new'] +  $newAllProductStock;
                } else {
                    $newAllStock          = $productsStockBranch1['stock_product_qty_new'] + $productsStockBranch2['stock_product_qty_new'] +  $newAllProductStock;
                }
                if ($newAllStock <= 0) {
                    $newAllStock = 0;
                }
                $this->db->table('products')->update(['product_stock' => $newAllStock, 'product_updated_at' => date('Y-m-d H:i:s')], ['id' => $salesOrder['id']]);

                #Update Tabel stock_product
                if ($newAllProductStock <= 0) {
                    $newAllProductStock = 0;
                }
                $this->db->table('stock_product')->update(['stock_product_qty_new' => $newAllProductStock], ['branch_id' => session()->get('branch_id'), 'product_id' => $salesOrder['id']]);
                $this->db->table('stock_initial')->update(['stock_initial_quantity' => $newAllProductStock, 'stock_initial_updated_at' => date('Y-m-d H:i:s')], ['branch_id' => session()->get('branch_id'), 'product_id' => $salesOrder['id']]);
                #Insert Stock Card
                $stockCardID =  $this->db->table('stock_card')->where(['branch_id' => session()->get('branch_id'), 'product_id' => $salesOrder['id']])->selectMax('id')->get()->getRowArray();

                $this->db->table('stock_card')->insert([
                    'branch_id'                 => session()->get('branch_id'),
                    'product_id'                => $salesOrder['id'],
                    'sales_id'                  => $id,
                    'stock_card_outcome'        => $salesOrder['qty'],
                    'stock_card_outcome_nominal' => $salesOrder['price'],
                    'stock_card_created_at'     => date('Y-m-d H:i:s'),
                    'stock_card_total'          => $newAllProductStock
                ]);
            }
        } else {
            $this->db->transRollback();
            return false;
        }
        if ($this->db->transStatus() === false) {
            $this->db->transRollback();
            return false;
        } else {
            $this->db->transCommit();
            return true;
        }
    }
    public function saveSalesOrder($datamember, $dataSalesOrder, $inputdata, $paymentMethod, $total, $payment, $cashBack)
    {
        #Fungsi untuk membuat Invoice
        $getMax    = $this->db->table('sales_order')->selectMax('sales_order.id')->get()->getRowArray();
        if ($getMax['id'] != NULL) {
            if ($getMax['id'] == 99999) {
                $maxNumber = 1;
                $maxNumber = sprintf("%05s", $maxNumber);
            } else {
                $maxNumber = $getMax['id'] + 1;
                $maxNumber = sprintf("%05s", $maxNumber);
            }
        } else {
            $maxNumber = '00001';
        }
        $Invoices = session()->get('branch_code') .  date('dmy') . $maxNumber;

        $this->db->transBegin();
        #pengecekan apakah ada input member
        if ($datamember == null) {
            $member = 1;
        } else {
            $member = $datamember;
        }
        $points = $this->db->table('point')->where(['branch_id' => session()->get('branch_id')])->get()->getResultArray();
        $getPoint = 0;
        if ($datamember >= 1) {
            $getPoint = 0;
            foreach ($points as $poin) {
                if ($total >= $poin['nominal_min'] && $total <= $poin['nominal_max']) {
                    $getPoint = $poin['point'];
                }
            }
            $customers = $this->db->table('customers')->where(['id' => $datamember])->get()->getRowArray();
            $newPoint = $customers['customer_points'] + $getPoint;
            $this->db->table('customers')->update(['customer_points' => $newPoint, 'customer_updated_at' => date('Y-m-d H:i:s')], ['id' => $datamember]);
        }
        $Transaction = $this->db->table('transaction')
            ->like(['opening_at' => date('m-d')])
            ->getWhere(['branch' => session()->get('branch_id'), 'opening_by' => session()->get('user_id'), 'closing_cash' => 0])
            ->getRowArray();
        $claimed = 0;
        if ($inputdata['Claim'] == 1) {
            $customer = $this->db->table('customers')->where(['id' => $member])->get()->getRowArray();
            $newPointMember = $customer['customer_points'] - 10000;
            $this->db->table('customers')->update(['customer_points' => $newPointMember, 'customer_updated_at' => date('Y-m-d H:i:s')], ['id' => $member]);
            $claimed = 1;
        }
        if ($paymentMethod && $dataSalesOrder != null) {
            if ($inputdata['Invoices'] == null) {
                $this->db->table('sales_order')->insert([
                    'sales_order_invoices'          => $Invoices,
                    'branch_id'                     => session()->get('branch_id'),
                    'customer_id'                   => $member,
                    'sales_order_points'            => $getPoint,
                    'sales_order_cashier'           => session()->get('user_id'),
                    'sales_order_discount'          => $inputdata['inputDiscount'],
                    'sales_order_tax'               => $inputdata['TotalTax'],
                    'sales_order_total'             => $total,
                    'payment_method_id'             => $paymentMethod['paymentMethodID'],
                    'issuer_id'                     => $paymentMethod['need_issue'],
                    'sales_order_account_no'        => $inputdata['inputCardNumber'],
                    'sales_order_card_name'         => $inputdata['inputCardHolder'],
                    'sales_order_qris_type'         => $inputdata['typeQris'],
                    'sales_order_phone_number'      => $inputdata['phoneNumber'],
                    'sales_order_customer_payment'  => $payment,
                    'sales_order_customer_cash_back' => $cashBack,
                    'sales_order_status'            => 1,
                    'sales_order_created_at'        => date('Y-m-d H:i:s'),
                    'sales_order_transaction_id'    =>  $Transaction['id'],
                    'sales_order_claimed_bonus'     => $claimed
                ]);

                # Ambil ID terakhir tabel pembelian
                $salesOrderID =  $this->db->insertID();

                foreach ($dataSalesOrder as $salesOrder) {
                    $per                = str_replace(" per ", "/", $salesOrder['name']);
                    $perdua             = str_replace(" perdua ", "/", $per);
                    $and                = str_replace(" dan ", "+", $perdua);
                    $dandua             = str_replace(" dan2 ", "&", $and);
                    $petikdua           = str_replace(" petikdua ", '"', $dandua);
                    $petik              = str_replace(" petik ", "'", $petikdua);
                    $titikdua           = str_replace(" titikdua ", ":", $petik);
                    $garis              = str_replace(" garis ", "|", $titikdua);
                    $petikbalik         = str_replace(" petikbalik ", "`", $garis);
                    $bebas              = str_replace(" bebas ", "~", $petikbalik);
                    $strip              = str_replace(" strip ", "-", $bebas);
                    $open               = str_replace(" kurungbuka ", "(", $strip);
                    $name               = str_replace(" kurungtutup ", ")", $open);
                    $disount = ($salesOrder['qty'] * $salesOrder['price']) * ($salesOrder['discount'] / 100);
                    $this->db->table('sales_order_product')->insert([
                        'sales_id'                                  => $salesOrderID,
                        'product_id'                                => $salesOrder['id'],
                        'sales_invoice'                             => $Invoices,
                        'transaction_id'                            => $Transaction['id'],
                        'sales_order_product_name'                  => $name,
                        'sales_order_quantity'                      => $salesOrder['qty'],
                        'sales_order_product_precentage_discount'   => $salesOrder['discount'],
                        'sales_order_product_discount'              => $disount,
                        'sales_order_price'                         => $salesOrder['price'],
                    ]);

                    #update tabel Product
                    $productsStock          = $this->db->table('stock_product')->getWhere(['branch_id' => session()->get('branch_id'), 'product_id' => $salesOrder['id']])->getRowArray();
                    $newAllProductStock     = $productsStock['stock_product_qty_new'] - $salesOrder['qty'];
                    $productsStockBranch1          = $this->db->table('stock_product')->select('stock_product_qty_new')->getWhere(['branch_id' => 1, 'product_id' => $salesOrder['id']])->getRowArray();
                    $productsStockBranch2          = $this->db->table('stock_product')->select('stock_product_qty_new')->getWhere(['branch_id' => 2, 'product_id' => $salesOrder['id']])->getRowArray();
                    $productsStockBranch3          = $this->db->table('stock_product')->select('stock_product_qty_new')->getWhere(['branch_id' => 3, 'product_id' => $salesOrder['id']])->getRowArray();
                    if ($newAllProductStock <= 0) {
                        $newAllProductStock = 0;
                    }
                    if (session()->get('branch_id') == 1) {
                        $newAllStock          = $productsStockBranch2['stock_product_qty_new'] + $productsStockBranch3['stock_product_qty_new'] +  $newAllProductStock;
                    } elseif (session()->get('branch_id') == 2) {
                        $newAllStock          = $productsStockBranch1['stock_product_qty_new'] + $productsStockBranch3['stock_product_qty_new'] +  $newAllProductStock;
                    } elseif (session()->get('branch_id') == 3) {
                        $newAllStock          = $productsStockBranch1['stock_product_qty_new'] + $productsStockBranch2['stock_product_qty_new'] +  $newAllProductStock;
                    }
                    if ($newAllStock < 0) {
                        $newAllStock = 0;
                    }

                    $this->db->table('stock_product')->update(['stock_product_qty_new' => $newAllProductStock], ['product_id' => $salesOrder['id'], 'branch_id' => session()->get('branch_id')]);
                    $this->db->table('products')->update(['product_stock' => $newAllStock, 'product_updated_at' => date('Y-m-d H:i:s')], ['id' => $salesOrder['id']]);

                    #Update Tabel stock_product


                    $this->db->table('stock_initial')->update(['stock_initial_quantity' => $newAllProductStock, 'stock_initial_updated_at' => date('Y-m-d H:i:s')], ['branch_id' => session()->get('branch_id'), 'product_id' => $salesOrder['id']]);
                    #Insert Stock Card

                    $this->db->table('stock_card')->insert([
                        'branch_id'                 => session()->get('branch_id'),
                        'product_id'                => $salesOrder['id'],
                        'sales_id'                  => $Invoices,
                        'stock_card_outcome'        => $salesOrder['qty'],
                        'stock_card_outcome_nominal' => $salesOrder['price'],
                        'stock_card_created_at'     => date('Y-m-d H:i:s'),
                        'stock_card_total'          => $newAllProductStock
                    ]);
                }
            } else {
                $Invoices = $inputdata['Invoices'];
                $this->db->table('sales_order')->update([
                    'branch_id'                     => session()->get('branch_id'),
                    'customer_id'                   => $member,
                    'sales_order_points'            => $getPoint,
                    'sales_order_cashier'           => session()->get('user_id'),
                    'sales_order_discount'          => $inputdata['inputDiscount'],
                    'sales_order_tax'               => $inputdata['TotalTax'],
                    'sales_order_total'             => $total,
                    'payment_method_id'             => $paymentMethod['paymentMethodID'],
                    'issuer_id'                     => $paymentMethod['need_issue'],
                    'sales_order_account_no'        => $inputdata['inputCardNumber'],
                    'sales_order_card_name'         => $inputdata['inputCardHolder'],
                    'sales_order_qris_type'         => $inputdata['typeQris'],
                    'sales_order_phone_number'      => $inputdata['phoneNumber'],
                    'sales_order_status'            => 1,
                    'sales_order_customer_payment'  => $payment,
                    'sales_order_customer_cash_back' => $cashBack,
                    'sales_order_transaction_id'    =>  $Transaction['id'],
                    'sales_order_claimed_bonus'     => $claimed
                ], ['sales_order_invoices' => $Invoices]);

                foreach ($dataSalesOrder as $salesOrder) {
                    $this->db->table('sales_order_product')->update([
                        'sales_order_product_name'                  => $salesOrder['name'],
                        'sales_invoice'                             => $Invoices,
                        'transaction_id'                            => $Transaction['id'],
                        'sales_order_quantity'                      => $salesOrder['qty'],
                        'sales_order_product_precentage_discount'   => $salesOrder['discount'],
                        'sales_order_product_discount'              => $salesOrder['totaldisc'],
                        'sales_order_price'                         => $salesOrder['price'],
                    ], [
                        'sales_id'                                  => $inputdata['Invoices'],
                        'product_id'                                => $salesOrder['id']
                    ]);

                    #update tabel Product
                    $productsStock          = $this->db->table('stock_product')->getWhere(['branch_id' => session()->get('branch_id'), 'product_id' => $salesOrder['id']])->getRowArray();
                    $newAllProductStock     = $productsStock['stock_product_qty_new'] - $salesOrder['qty'];
                    $productsStockBranch1          = $this->db->table('stock_product')->select('stock_product_qty_new')->getWhere(['branch_id' => 1, 'product_id' => $salesOrder['id']])->getRowArray();
                    $productsStockBranch2          = $this->db->table('stock_product')->select('stock_product_qty_new')->getWhere(['branch_id' => 2, 'product_id' => $salesOrder['id']])->getRowArray();
                    $productsStockBranch3          = $this->db->table('stock_product')->select('stock_product_qty_new')->getWhere(['branch_id' => 3, 'product_id' => $salesOrder['id']])->getRowArray();
                    if ($newAllProductStock <= 0) {
                        $newAllProductStock = 0;
                    }
                    if (session()->get('branch_id') == 1) {
                        $newAllStock          = $productsStockBranch2['stock_product_qty_new'] + $productsStockBranch3['stock_product_qty_new'] +  $newAllProductStock;
                    } elseif (session()->get('branch_id') == 2) {
                        $newAllStock          = $productsStockBranch1['stock_product_qty_new'] + $productsStockBranch3['stock_product_qty_new'] +  $newAllProductStock;
                    } elseif (session()->get('branch_id') == 3) {
                        $newAllStock          = $productsStockBranch1['stock_product_qty_new'] + $productsStockBranch2['stock_product_qty_new'] +  $newAllProductStock;
                    }
                    if ($newAllStock <= 0) {
                        $newAllStock = 0;
                    }
                    $this->db->table('products')->update(['product_stock' => $newAllStock, 'product_updated_at' => date('Y-m-d H:i:s')], ['id' => $salesOrder['id']]);

                    #Update Tabel stock_product

                    $this->db->table('stock_product')->update(['stock_product_qty_new' => $newAllProductStock], ['branch_id' => session()->get('branch_id'), 'product_id' => $salesOrder['id']]);
                    $this->db->table('stock_initial')->update(['stock_initial_quantity' => $newAllProductStock, 'stock_initial_updated_at' => date('Y-m-d H:i:s')], ['branch_id' => session()->get('branch_id'), 'product_id' => $salesOrder['id']]);
                    #Insert Stock Card
                    $this->db->table('stock_card')->insert([
                        'branch_id'                 => session()->get('branch_id'),
                        'product_id'                => $salesOrder['id'],
                        'sales_id'                  => $Invoices,
                        'stock_card_outcome'        => $salesOrder['qty'],
                        'stock_card_outcome_nominal' => $salesOrder['price'],
                        'stock_card_created_at'     => date('Y-m-d H:i:s'),
                        'stock_card_total'          => $newAllProductStock
                    ]);
                }
            }
            if ($this->db->transStatus() === false) {
                $this->db->transRollback();
                return false;
            } else {
                $this->db->transCommit();
                return $Invoices;
            }
        } else {
            $this->db->transRollback();
            return false;
        }
    }
    public function getTransactionByInvoice($invoice)
    {
        return $this->db->table('sales_order')
            ->select('sales_order_transaction_id')
            ->where(['sales_order.sales_order_invoices' => $invoice])
            ->get()->getRowArray();
    }
    public function voidSalesOrder($dataInput)
    {
        $this->db->transBegin();
        $salesOrder = $this->db->table('sales_order')->getWhere(['id' => $dataInput['salesOrderId']])->getRowArray();
        $salesOrderProduct = $this->db->table('sales_order_product')->getWhere(['sales_id' => $dataInput['salesOrderId']])->getResultArray();
        $this->db->table('sales_order')->update([
            'sales_order_status'            => $dataInput['inputSalesOrderStatus'],
            'sales_order_void_by'           => session()->get('user_id'),
            'sales_order_void_at'           => date('Y-m-d H:i:s'),
            'sales_order_void_description'  => $dataInput['inputReasonVoid']
        ], ['id' => $dataInput['salesOrderId']]);
        if ($salesOrder['customer_id'] >= 1) {
            $points = $this->db->table('point')->where(['branch_id' => session()->get('branch_id')])->get()->getResultArray();
            $getPoint = 0;
            foreach ($points as $poin) {
                if ($salesOrder['sales_order_total'] >= $poin['nominal_min'] && $salesOrder['sales_order_total'] <= $poin['nominal_max']) {
                    $getPoint = $poin['point'];
                }
            }
            $customers = $this->db->table('customers')->where(['id' => $salesOrder['customer_id']])->get()->getRowArray();
            $newPoint = $customers['customer_points'] - $getPoint;
            $this->db->table('customers')->update(['customer_points' => $newPoint, 'customer_updated_at' => date('Y-m-d H:i:s')], ['id' => $salesOrder['customer_id']]);
            if ($salesOrder['sales_order_claimed_bonus'] != 0) {
                $newPointMember = $customers['customer_points'] + 10000;
                $this->db->table('customers')->update(['customer_points' => $newPointMember, 'customer_updated_at' => date('Y-m-d H:i:s')], ['id' => $salesOrder['customer_id']]);
            }
        }
        foreach ($salesOrderProduct as $salesProduct) {
            #update tabel Product
            $productsStock          = $this->db->table('stock_product')->getWhere(['branch_id' => session()->get('branch_id'), 'product_id' => $salesProduct['product_id']])->getRowArray();
            $newAllProductStock     = $productsStock['stock_product_qty_new'] + $salesProduct['sales_order_quantity'];
            $productsStockBranch1          = $this->db->table('stock_product')->select('stock_product_qty_new')->getWhere(['branch_id' => 1, 'product_id' => $salesProduct['product_id']])->getRowArray();
            $productsStockBranch2          = $this->db->table('stock_product')->select('stock_product_qty_new')->getWhere(['branch_id' => 2, 'product_id' => $salesProduct['product_id']])->getRowArray();
            $productsStockBranch3          = $this->db->table('stock_product')->select('stock_product_qty_new')->getWhere(['branch_id' => 3, 'product_id' => $salesProduct['product_id']])->getRowArray();
            if ($newAllProductStock <= 0) {
                $newAllProductStock = 0;
            }
            if (session()->get('branch_id') == 1) {
                $newAllStock          = $productsStockBranch2['stock_product_qty_new'] + $productsStockBranch3['stock_product_qty_new'] +  $newAllProductStock;
            } elseif (session()->get('branch_id') == 2) {
                $newAllStock          = $productsStockBranch1['stock_product_qty_new'] + $productsStockBranch3['stock_product_qty_new'] +  $newAllProductStock;
            } elseif (session()->get('branch_id') == 3) {
                $newAllStock          = $productsStockBranch1['stock_product_qty_new'] + $productsStockBranch2['stock_product_qty_new'] +  $newAllProductStock;
            }
            if ($newAllStock <= 0) {
                $newAllStock = 0;
            }
            $this->db->table('products')->update(['product_stock' => $newAllStock, 'product_updated_at' => date('Y-m-d H:i:s')], ['id' => $salesProduct['product_id']]);


            #Update Tabel stock_product
            $this->db->table('stock_product')->update(['stock_product_qty_new' => $newAllProductStock], ['branch_id' => session()->get('branch_id'), 'product_id' => $salesProduct['product_id']]);
            $this->db->table('stock_initial')->update(['stock_initial_quantity' => $newAllProductStock, 'stock_initial_updated_at' => date('Y-m-d H:i:s')], ['branch_id' => session()->get('branch_id'), 'product_id' => $salesProduct['product_id']]);

            #Insert Stock Card

            $this->db->table('stock_card')->insert([
                'branch_id'                 => session()->get('branch_id'),
                'product_id'                => $salesProduct['product_id'],
                'purchase_id'               => $salesOrder['sales_order_invoices'],
                'stock_card_income'         => $salesProduct['sales_order_quantity'],
                'stock_card_income_nominal' => $salesProduct['sales_order_price'],
                'stock_card_created_at'     => date('Y-m-d H:i:s'),
                'stock_card_total'          => $newAllProductStock
            ]);
        }

        if ($this->db->transStatus() === false) {
            $this->db->transRollback();
            return false;
        } else {
            $this->db->transCommit();
            return true;
        }
    }
    public function getTransactionByDate($dataClosingId = false)
    {
        if ($dataClosingId) {
            return $this->db->table('transaction')
                ->select('*, transaction.id as transactionID, employee.id as employeeId')
                ->join('employee', 'transaction.closing_by = employee.id')
                ->where(['transaction.id' => $dataClosingId, 'DATE(opening_at)' => date('Y-m-d'), 'opening_by' => session()->get('user_id')])->get()->getRowArray();
        } else {
            return $this->db->table('transaction')->where(['DATE(opening_at)' => date('Y-m-d'), 'opening_by' => session()->get('user_id'), 'closing_cash' => 0])->get()->getRowArray();
        }
    }
    public function checkTransaction()
    {
        return $this->db->table('transaction')
            ->getWhere(['branch' => session()->get('branch_id'), 'opening_by' => session()->get('user_id'), 'DATE(opening_at)' => date('Y-m-d'), 'closing_cash' => 0])->getRowArray();
    }
    public function checkTransactionVoid()
    {
        return $this->db->table('transaction')
            ->getWhere(['branch' => session()->get('branch_id'), 'DATE(opening_at)' => date('Y-m-d'), 'closing_cash' => 0])->getRowArray();
    }
    public function saveOpenCash($cash)
    {
        $this->db->transBegin();
        $this->db->table('transaction')->insert([
            'id'            => random_string('alnum', 5),
            'opening_cash'  => $cash,
            'branch'        => session()->get('branch_id'),
            'opening_by'    => session()->get('user_id'),
            'opening_at'    => date('Y-m-d H:i:s'),
        ]);

        if ($this->db->transStatus() === false) {
            $this->db->transRollback();
            return false;
        } else {
            $this->db->transCommit();
            return true;
        }
    }
    public function getDiscount()
    {
        return $this->db->table('discount')->get()->getResultArray();
    }
    public function getDiscountMembership()
    {
        return $this->db->table('discount')->getWhere(['discount_type' => 1, 'branch_id' => session()->get('branch_id'),])->getRowArray();
    }
    public function getDiscountByMinimumItem()
    {
        return $this->db->table('discount')->getWhere(['discount_type' => 2, 'branch_id' => session()->get('branch_id'),])->getResultArray();
    }
    public function getDiscountByCategoryProduct()
    {
        return $this->db->table('discount')
            ->select('*, discount.id AS discountID')
            ->join('product_subdepartment', 'discount.subdepartment_id = product_subdepartment.product_subdep_code')
            ->getWhere(['discount_type' => 3, 'branch_id' => session()->get('branch_id'),])->getResultArray();
    }
    public function getDiscountByBirthday()
    {
        return $this->db->table('discount')->getWhere(['discount_type' => 4, 'branch_id' => session()->get('branch_id'),])->getRowArray();
    }
    public function createDiscount($dataDiscount)
    {
        return $this->db->table('discount')->insert([
            'branch_id'         => session()->get('branch_id'),
            'discount_name'     => $dataDiscount['inputDiscountName'],
            'discount_type'     => $dataDiscount['categoryDiscount'],
            'subdepartment_id'  => $dataDiscount['productCategory'],
            'precentage'        => $dataDiscount['inputDiscountPercent'],
            'min_item'          => $dataDiscount['inputMinimalItem'],
            'max_item'          => $dataDiscount['inputMaxItem'],
        ]);
    }
    public function updateDiscount($dataDiscount)
    {
        return $this->db->table('discount')->update([
            'discount_name'     => $dataDiscount['inputDiscountName'],
            'discount_type'     => $dataDiscount['categoryDiscount'],
            'subdepartment_id'  => $dataDiscount['productCategory'],
            'precentage'        => $dataDiscount['inputDiscountPercent'],
            'min_item'          => $dataDiscount['inputMinimalItem'],
            'max_item'          => $dataDiscount['inputMaxItem'],
        ], ['id' => $dataDiscount['idDiscount'],  'branch_id' => session()->get('branch_id')]);
    }
    public function getDiscountMember($member)
    {
        return $this->db->table('discount')->where(['discount_type' => $member, 'is_active' => 1, 'branch_id' => session()->get('branch_id')])->get()->getRowArray();
    }
    public function getDiscountProductByQty()
    {
        return $this->db->table('discount')->where(['discount_type' => 2, 'branch_id' => session()->get('branch_id'), 'is_active' => 1])->get()->getResultArray();
    }
    public function getDiscountProductBySubdepartment($productID)
    {
        $product = $this->db->table('products')->getWhere(['id' => $productID])->getRowArray();
        return $this->db->table('discount')->where(['discount_type' => 3, 'subdepartment_id' => $product['product_subdepartment_id'],  'is_active' => 1, 'branch_id' => session()->get('branch_id')])->get()->getRowArray();
    }
    public function getDiscountProductByBirthdayDate($customerID)
    {
        $customers = $this->db->table('customers')->where(['customer_code' => $customerID])->like(['DATE(customer_birthday)' => date('m-d')])->get()->getRowArray();
        if ($customers) {
            return $this->db->table('discount')->where(['discount_type' => 4, 'is_active' => 1, 'branch_id' => session()->get('branch_id')])->get()->getRowArray();
        } else {
            return 0;
        }
    }
    public function getSalesOrderSucces()
    {
        return $this->db->table('sales_order')
            ->like(['sales_order_created_at' => date('Y-m-d')])
            ->getWhere(['sales_order_status' => 1])
            ->getResultArray();
    }
    public function saveClosingCash($dataSalesOrder, $dataTransaction, $dataInput)
    {
        $this->db->transBegin();
        $totalTransaction = 0;
        $totalDiscount = 0;
        $totalTaxTransaction = 0;
        foreach ($dataSalesOrder as $salesorder) {
            $totalTransaction += $salesorder['sales_order_total'];
            $totalDiscount += $salesorder['sales_order_discount'];
            $totalTaxTransaction += $salesorder['sales_order_tax'];
        }
        $this->db->table('transaction')->update([
            'closing_cash'                  => $dataInput['inputTotalCash'],
            'closing_total_transaction'     => $totalTransaction,
            'closing_discount_transaction'  => $totalDiscount,
            'closing_tax_transaction'       => $totalTaxTransaction,
            'closing_by'                    => session()->get('user_id'),
            'closing_at'                    => date('Y-m-d H:i:s')
        ], ['id' => $dataTransaction['id']]);

        if ($this->db->transStatus() === false) {
            $this->db->transRollback();
            return false;
        } else {
            $this->db->transCommit();
            return $dataTransaction['id'];
        }
    }
    public function getTaxByMonth($month)
    {
        return $this->db->table('sales_order')
            ->select('*, sales_order.branch_id, sales_order.sales_order_total, sales_order.sales_order_tax')
            ->join('branch', 'sales_order.branch_id = branch.id')
            ->where(['MONTH(sales_order_created_at)' => short_bulan($month), 'branch_id' => session()->get('branch_id'), 'sales_order_status' => 1, 'tax_type' => 1, 'YEAR(sales_order_created_at)' => date('Y')])
            ->groupBy('branch.branch_name')->selectSum('sales_order_total')->selectSum('sales_order_tax')->orderBy('branch.branch_name')->get()->getRowArray();
    }
    public function getTaxByMonthandBranch($month, $branch)
    {
        return $this->db->table('sales_order')
            ->select('*, sales_order.branch_id, sales_order.sales_order_total, sales_order.sales_order_tax')
            ->join('branch', 'sales_order.branch_id = branch.id')
            ->where(['MONTH(sales_order_created_at)' => short_bulan($month), 'branch_id' => $branch, 'sales_order_status' => 1, 'tax_type' => 1, 'YEAR(sales_order_created_at)' => date('Y')])
            ->groupBy('branch.branch_name')->selectSum('sales_order_total')->selectSum('sales_order_tax')->orderBy('branch.branch_name')->get()->getRowArray();
    }
    public function getVoidPeriod($branchID = false)
    {
        return $this->db->table('void_period')
            ->select('*, branch.id as branchID, void_period.id as voidPeriodID')
            ->join('branch', 'branch.id = void_period.void_period_branch_id')
            ->where(['void_period_branch_id' => $branchID])
            ->get()->getResultArray();
    }
    public function getVoidPeriodbyendTime()
    {
        return $this->db->table('void_period')->where(['void_period_branch_id' => session()->get('branch_id')])->get()->getRowArray();
    }
    public function getVoidPeriodbyStartTime()
    {
        $dataVoid = $this->db->table('sales_order')->where(['sales_order_status' => 0, 'branch_id' => session()->get('branch_id')])->get()->getRowArray();
        if ($dataVoid) {
            return $dataVoid;
        } else {
            return null;
        }
    }
    public function updateStatusVoid($dataVoid)
    {
        return $this->db->table('sales_order')->delete(['sales_order_invoice' => $dataVoid]);
    }
    public function cancelOrder($dataCancel)
    {
        $this->db->transBegin();
        $salesOrder = $this->db->table('sales_order')->getWhere(['id' => $dataCancel])->getRowArray();
        $salesOrderProduct = $this->db->table('sales_order_product')->getWhere(['sales_id' => $dataCancel])->getResultArray();
        foreach ($salesOrderProduct as $salesProduct) {
            #update tabel Product
            $productsStock          = $this->db->table('stock_product')->getWhere(['branch_id' => session()->get('branch_id'), 'product_id' => $salesProduct['product_id']])->getRowArray();
            $newAllProductStock     = $productsStock['stock_product_qty_new'] + $salesProduct['sales_order_quantity'];
            $productsStockBranch1          = $this->db->table('stock_product')->select('stock_product_qty_new')->getWhere(['branch_id' => 1, 'product_id' =>  $salesProduct['product_id']])->getRowArray();
            $productsStockBranch2          = $this->db->table('stock_product')->select('stock_product_qty_new')->getWhere(['branch_id' => 2, 'product_id' =>  $salesProduct['product_id']])->getRowArray();
            $productsStockBranch3          = $this->db->table('stock_product')->select('stock_product_qty_new')->getWhere(['branch_id' => 3, 'product_id' =>  $salesProduct['product_id']])->getRowArray();
            if ($newAllProductStock < 0) {
                $newAllProductStock = 0;
            }
            if (session()->get('branch_id') == 1) {
                $newAllStock          = $productsStockBranch2['stock_product_qty_new'] + $productsStockBranch3['stock_product_qty_new'] +  $newAllProductStock;
            } elseif (session()->get('branch_id') == 2) {
                $newAllStock          = $productsStockBranch1['stock_product_qty_new'] + $productsStockBranch3['stock_product_qty_new'] +  $newAllProductStock;
            } elseif (session()->get('branch_id') == 3) {
                $newAllStock          = $productsStockBranch1['stock_product_qty_new'] + $productsStockBranch2['stock_product_qty_new'] +  $newAllProductStock;
            }
            if ($newAllStock <= 0) {
                $newAllStock = 0;
            }
            $this->db->table('products')->update(['product_stock' => $newAllStock, 'product_updated_at' => date('Y-m-d H:i:s')], ['id' => $salesProduct['product_id']]);

            #Update Tabel stock_product

            $this->db->table('stock_product')->update(['stock_product_qty_new' => $newAllProductStock], ['branch_id' => session()->get('branch_id'), 'product_id' => $salesProduct['product_id']]);
            $this->db->table('stock_initial')->update(['stock_initial_quantity' => $newAllProductStock, 'stock_initial_updated_at' => date('Y-m-d H:i:s')], ['branch_id' => session()->get('branch_id'), 'product_id' => $salesProduct['product_id']]);

            #Insert Stock Card
            $this->db->table('stock_card')->insert([
                'branch_id'                 => session()->get('branch_id'),
                'product_id'                => $salesProduct['product_id'],
                'purchase_id'               => $salesOrder['sales_order_invoices'],
                'stock_card_income'         => $salesProduct['sales_order_quantity'],
                'stock_card_income_nominal' => $salesProduct['sales_order_price'],
                'stock_card_created_at'     => date('Y-m-d H:i:s'),
                'stock_card_total'          => $newAllProductStock
            ]);
        }
        if ($this->db->transStatus() === false) {
            $this->db->transRollback();
            return false;
        } else {
            $this->db->transCommit();
            $this->db->table('sales_order_product')->delete(['sales_id' => $dataCancel]);
            $this->db->table('sales_order')->delete(['id' => $dataCancel]);
            return true;
        }
    }
    public function updateVoidPeriod($dataVoidPeriod)
    {
        return $this->db->table('void_period')->update([
            'void_period_time'  => $dataVoidPeriod['inputVoidPeriod']
        ], ['id' => $dataVoidPeriod['voidPeriodID'], 'void_period_branch_id' => session()->get('branch_id')]);
    }
    public function updateTaxType($invoice, $taxType)
    {
        return $this->db->table('sales_order')->update([
            'tax_type'  => $taxType
        ], ['sales_order_invoices' => $invoice, 'branch_id' => session()->get('branch_id')]);
    }
    public function getDataPrint()
    {
        return $this->db->table('print')->getWhere(['branch_id' => session()->get('branch_id')])->getRowArray();
    }
    public function savePrint($dataPrint)
    {
        return $this->db->table('print')->insert([
            'branch_id' => session()->get('branch_id'),
            'line1'     => $dataPrint['line1'],
        ]);
    }
    public function updatePrintPreview($dataPrint)
    {
        return $this->db->table('print')->update([
            'line1'     => $dataPrint['line1'],
            'line2'     => $dataPrint['line2'],
            'line3'     => $dataPrint['line3']
        ], ['branch_id' => session()->get('branch_id')]);
    }
    public function updateStatusDiscount($dataID, $status)
    {
        return $this->db->table('discount')->update([
            'is_active' => $status
        ], ['id' => $dataID, 'branch_id' => session()->get('branch_id')]);
    }
    public function statusTransferMoneySales($status, $date)
    {
        $salesOrder = $this->db->table('sales_order')->getWhere(['DATE(sales_order_created_at)' => $date])->getResultArray();
        foreach ($salesOrder as $order) {
            $this->db->table('sales_order')->update([
                'sales_order_transfer_owner' => $status,
            ], ['id' => $order['id']]);
        }
        return true;
    }
}
