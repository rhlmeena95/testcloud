<?php

namespace App\Controllers\Master;

use App\Controllers\BaseController;
use App\Models\MasterModel;
use App\Models\SalesModel;

class Customers extends BaseController
{
	public function __construct()
	{
		$this->SalesModel = new SalesModel();
		$this->MasterModel = new MasterModel();
	}
	public function index()
	{
		$data = array_merge($this->data, [
			'category'		=> 'Master',
			'title'         => 'Daftar Pelanggan',
			'Customers'     => $this->SalesModel->getCustomers(),
			'Branch'    	=> $this->MasterModel->getBranch(),
			'Province'    	=> $this->MasterModel->getProvince(),
			'City'    		=> $this->MasterModel->getCity(),
			'Subdistrict'   => $this->MasterModel->getSubdistrict(),
		]);
		return view('master/customerList', $data);
	}
	public function createCustomers()
	{
		$data = array_merge($this->data, [
			'category'		=> 'Master',
			'title'         => 'Registrasi Pelanggan',
			'Customers'     => $this->SalesModel->getCustomers(),
			'Branch'    	=> $this->MasterModel->getBranch(),
			'Province'    	=> $this->MasterModel->getProvince(),
			'City'    		=> $this->MasterModel->getCity(),
			'Subdistrict'   => $this->MasterModel->getSubdistrict(),
		]);
		return view('master/customerFormCreate', $data);
	}
	public function saveCustomers()
	{
		$createCustomers = $this->SalesModel->createCustomers($this->request->getPost(null));
		if ($createCustomers) {
			if ($this->request->getPost('inputan') == 2) {
				session()->setFlashdata('notif_success', '<b>Berhasil menambah member Baru</b>');
				return redirect()->to(base_url('cashier'));
			} else {
				session()->setFlashdata('notif_success', '<b>Berhasil menambah member Baru</b>');
				return redirect()->to(base_url('customers'));
			}
		} else {
			if ($this->request->getPost('inputan') == 2) {
				session()->setFlashdata('notif_error', '<b>Gagal menambahkan member baru</b>');
				return redirect()->to(base_url('cashier'));
			} else {
				session()->setFlashdata('notif_error', '<b>Gagal menambahkan member baru</b>');
				return redirect()->to(base_url('customers'));
			}
		}
	}
	public function updateCustomers()
	{
		$data = array_merge($this->data, [
			'category'		=> 'Master',
			'title'         => 'Registrasi Pelanggan',
			'Customers'     => $this->SalesModel->getCustomers($this->request->getVar('id')),
			'Province'    	=> $this->MasterModel->getProvince(),
		]);

		return view('master/customerFormUpdate', $data);
	}
	public function saveupdateCustomers()
	{
		$updateCustomers = $this->SalesModel->updateCustomers($this->request->getPost(null));
		if ($updateCustomers) {
			session()->setFlashdata('notif_success', '<b>Berhasil merubah data Customer</b>');
			return redirect()->to(base_url('customers'));
		} else {
			session()->setFlashdata('notif_error', '<b>Gagal merubah data Customer</b>');
			return redirect()->to(base_url('customers'));
		}
	}
	public function deleteCustomers()
	{
		$deleteCustomers = $this->SalesModel->deleteCustomers($this->request->getPost('customersID'));
		if ($deleteCustomers === "Tidak") {
			session()->setFlashdata('notif_error', '<b>Gagal Menghapus Customer, Customer sudah melakukan pembelian</b>');
			return redirect()->to(base_url('customers'));
		} else if ($deleteCustomers === true) {
			session()->setFlashdata('notif_success', '<b>Berhasil menghapus Customer</b>');
			return redirect()->to(base_url('customers'));
		} else {
			session()->setFlashdata('notif_error', '<b>Gagal Menghapus Customer</b>');
			return redirect()->to(base_url('customers'));
		}
	}
	public function checkCustomersExpired()
	{
		return $cekExpiredMember = $this->MasterModel->checkExpiredMember();
	}
	function getCity()
	{
		$ProvinceID = $this->request->getPost('province');
		$getCity = $this->MasterModel->getCity($ProvinceID);
		$output = '';
		foreach ($getCity as $city) {
			$output .= '
			<option value="' . $city['id'] . '">' . $city['city_type'] . ' ' . $city['city_name'] . '</option>';
		}
		return $output;
	}
	function getSubdistrict()
	{
		$cityID = $this->request->getPost('city');
		$getSubdistrict = $this->MasterModel->getSubdistrict($cityID);
		$output = '';
		foreach ($getSubdistrict as $subdistrict) {
			$output .= '
			<option value="' . $subdistrict['id'] . '">' . $subdistrict['subdistrict_name'] . '</option>';
		}
		return $output;
	}
	public function point()
	{
		$branch = $this->request->getGet('branch');
		if ($branch != null) {
			$point = $this->MasterModel->point($branch);
		} else {
			$point = $this->MasterModel->point();
		}
		$data = array_merge($this->data, [
			'category'		=> 'Setting',
			'title'         => 'Point Royalti',
			'Point'			=> $point,
			'Branch'    	=> $this->MasterModel->getBranch(),
			'inputBranch'	=> $branch
		]);
		return view('settings/point', $data);
	}
	public function updatePoint()
	{
		$updatePoints = $this->MasterModel->updatePoint($this->request->getPost(null));
		if ($updatePoints) {
			session()->setFlashdata('notif_success', '<b>Berhasil Merubah Point</b>');
			return redirect()->to(base_url('point'));
		} else {
			session()->setFlashdata('notif_error', '<b>Gagal Merubah Point</b>');
			return redirect()->to(base_url('point'));
		}
	}
	public function createPoint()
	{
		$createPoint = $this->MasterModel->createPoint($this->request->getPost(null));
		if ($createPoint) {
			session()->setFlashdata('notif_success', '<b>Berhasil membuat data Point</b>');
			return redirect()->to(base_url('point'));
		} else {
			session()->setFlashdata('notif_error', '<b>Gagal membuat data Point</b>');
			return redirect()->to(base_url('point'));
		}
	}
	public function deletePoint()
	{
		$deletePoint = $this->MasterModel->deletePoint($this->request->getPost('pointID'));
		if ($deletePoint) {
			session()->setFlashdata('notif_success', '<b>Berhasil menghapus point</b>');
			return redirect()->to(base_url('point'));
		} else {
			session()->setFlashdata('notif_error', '<b>Gagal Menghapus point</b>');
			return redirect()->to(base_url('point'));
		}
	}
}
