<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Point of Sale Toko Mainan Boboy">
    <meta name="author" content="Codavlo Indonesia">
    <link rel="icon" type="image/x-icon" href="<?= base_url('assets/img/logotoko1.jpeg') ?>" />
    <title>Nota Kasir | Toko Mainan Boboy</title>
    <script src="<?= base_url('assets/js/libs/jquery-3.6.0.js') ?>"></script>
    <style>
        hr {
            display: block;
            margin-top: 0.2em;
            margin-bottom: 0.2em;
            margin-left: 0.5cm;
            margin-right: 0.2cm;
            border-style: inset;
            border-width: 1px;
        }

        @media print {
            body * {
                visibility: hidden;
            }

            #section-to-print,
            #section-to-print * {
                visibility: visible;
            }

            #section-to-print {
                position: absolute;
                left: 0;
                top: 0;
            }
        }

        .text-center {
            margin-left: 7.5%;
            margin-top: 1%;
        }
    </style>
</head>

<body onload="window.print()">
    <div style="width:7.5cm ;" id="section-to-print">
        <table cellspacing='0' cellpadding='0.5' style="font-size:11pt; margin-left: 0.5cm; margin-right: 0.5cm;">
            <tr>
                <td class="text-center"><b><?= session()->get('branch'); ?></b></td>
            </tr>
            <tr>
                <td style="font-size:9pt"><?= $Branch['branch_address']; ?></td>
            </tr>
        </table>
        <table cellspacing='0' cellpadding='0.5' style="font-size:9pt; margin-left: 0.5cm; margin-right: 0.5cm;text-align: left" width="90%">
            <tr>
                <?php $prdate = new DateTime($SalesOrder['sales_order_created_at']);  ?>
                <td width='95%'><?= $SalesOrder['sales_order_invoices']; ?>/<?= $SalesOrder['employee_name']; ?>/<?= date_indo($prdate->format('Y-m-d')); ?>/<?= $prdate->format('H:i'); ?>/
                    <?php if ($SalesOrder['payment_method_code'] == 1) : ?>
                        <span>Tunai</span>
                    <?php elseif ($SalesOrder['payment_method_code'] == 2) : ?>
                        <span>Debit</span>
                    <?php else : ?>
                        <span>Qris</span>
                    <?php endif ?> - <?= $SalesOrder['payment_method_name']; ?>
                    <?= ($SalesOrder['customer_fullname']) ? '/' . $SalesOrder['customer_fullname'] : ''; ?>
                </td>
            </tr>
        </table>
        <hr>
        <?php foreach ($SalesOrderProduct as $salesOrderProduct) : ?>
            <table cellspacing='0' cellpadding='0.5' style="font-size:9pt; margin-left: 0.5cm; margin-right: 0.5cm;text-align: left" width="90%">
                <tr>
                    <td style='vertical-align:top; text-align:left; '><?= $salesOrderProduct['sales_order_product_name']; ?></td>
                </tr>
            </table>
            <table cellspacing='0' cellpadding='0.5' style="font-size:9pt; margin-left: 0.5cm; margin-right: 0.5cm;" width="90%">
                <tr>
                    <td width='35%' style='vertical-align:top; text-align:left; '>@ Rp.<?= number_format($salesOrderProduct['sales_order_price']); ?></td>
                    <td width='40%' style='text-align:center;'> <?= $salesOrderProduct['sales_order_quantity']; ?> pcs</td>
                    <td width='35%' style='vertical-align:top; text-align:right; '>Rp. <?= number_format($salesOrderProduct['sales_order_price'] * $salesOrderProduct['sales_order_quantity']); ?> </td>
                </tr>
            </table>
        <?php endforeach; ?>
        <hr>
        <table cellspacing='0' cellpadding='0.5' style="font-size:9pt; margin-left: 0.5cm; margin-right: 0.5cm;" width="90%">
            <tr>
                <td width='30%' style='text-align:left; '>Total Diskon</td>
                <td width='60%' style='text-align:right; '>Rp. <?= number_format($SalesOrder['sales_order_discount']); ?></td>
            </tr>
            <tr>
                <td width='35%' style=' font-size:10pt;'>Total Belanja</td>
                <td width='60%' style='text-align:right;font-size:10pt; '>Rp.<?= number_format($SalesOrder['sales_order_total'] - $SalesOrder['sales_order_discount']); ?></td>
            </tr>
        </table>
        <hr>
        <table cellspacing='0' cellpadding='0.5' style="font-size:10pt; margin-left: 0.5cm; margin-right: 0.5cm; " width="90%">
            <tr>
                <td width="50%" style='text-align:left;'>Total Bayar</td>
                <td width="45%" style='text-align:right; '>Rp. <?= ($SalesOrder['sales_order_customer_payment']) ? number_format($SalesOrder['sales_order_customer_payment']) : number_format($SalesOrder['sales_order_total'] - $SalesOrder['sales_order_discount']); ?></td>
            </tr>
            <tr>
                <td style='text-align:left; font-size:9pt;'>Kembalian</td>
                <td style='text-align:right;font-size:10pt; '>Rp. <?= ($SalesOrder['sales_order_customer_cash_back']) ? number_format($SalesOrder['sales_order_customer_cash_back']) : '0'; ?></td>
            </tr>
        </table>
        <hr>
        <table cellspacing='0' cellpadding='0' style="font-size:10pt; margin-left: 0.5cm; margin-right: 0.5cm; " width="90%">
            <?php if ($Print) : ?>
                <td style='text-align:center; font-size:9pt;'>
                    <?= ($Print['line1']) ? $Print['line1'] : 'asdasdasd'; ?> <br><?= ($Print['line2']) ? $Print['line2'] : ''; ?> <br> <?= ($Print['line3']) ? $Print['line3'] : ''; ?>
                </td>
            <?php else : ?>
                <tr>
                    <td style='text-align:center; font-size:9pt;'><span>Terima Kasih</span></td>
                </tr>
            <?php endif; ?>
        </table>
    </div>
    <!-- <div class="text-center">
        <button id="printButton">Cetak Nota</button>
        <button onclick="window.location.href='<?= base_url('cashier'); ?>'">Kembali</button>
    </div>
    <script>
        $('#printButton').click(function() {
            window.print()
        });
    </script> -->
    <script>
        function pageRedirect() {
            window.location.replace("<?= base_url('cashier'); ?>");
        }
        setTimeout("pageRedirect()", 1000);
    </script>
</body>

</html>