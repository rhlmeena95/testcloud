<?= $this->extend('layouts/main'); ?>
<?= $this->section('content'); ?>
<div class="row layout-top-spacing" id="cancel-row">
    <div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
        <div class="row">
            <div class="col-xl-12">
                <div class="widget-content widget-content-area br-6">
                    <div class="col-sm-12 text-sm-center">
                        <h3 class="inv-list-number"><span class="inv-title">Serah Terima Barang </span></h3>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-sm-8 mt-3">
                            <h6 class="inv-created-date"><span class="inv-title">Tanggal Pembuatan : </span> <br><br>
                                <span class="inv-date"><b><?php $prdate = new DateTime($StockTransfer['request_at']);
                                                            echo date_indo($prdate->format('Y-m-d')) . ', ' . $prdate->format('H:i');  ?></b></span>
                            </h6>
                        </div>
                        <div class="col-sm-4 mt-3 d-inline">
                            <h6 class="inv-created-date"><span class="inv-title">Dibuat Oleh : </span> <br><br>
                                <span class="inv-date"><b><?= $StockTransfer['employee_name']; ?></b></span>
                            </h6>
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-xl-8 col-lg-7 col-md-6 col-sm-4 align-self-center">
                            <h6 class="inv-to"> <b> Nama Cabang :</b></h6>
                        </div>
                        <div class="col-xl-4 col-lg-5 col-md-6 col-sm-8 align-self-center order-sm-0 order-1 inv--payment-info">
                            <h6 class=" inv-title"> <b>Status Barang:</b> </h6>
                        </div>
                        <div class="col-xl-8 col-lg-7 col-md-6 col-sm-4">
                            <h2><?= $StockTransfer['branch_name']; ?></h2>
                        </div>
                        <div class="col-xl-4 col-lg-5 col-md-6 col-sm-8 col-12 order-sm-0 order-1">
                            <div class="inv--payment-info">
                                <h2 class="font-weight-bold ">
                                    <?php if ($StockTransfer['status'] == 1) { ?>
                                        <span class="text-warning"> DIKIRIM </span>
                                    <?php } else if ($StockTransfer['status'] == 2) { ?>
                                        <span class="text-success"> DITERIMA </span>
                                    <?php } else if ($StockTransfer['status'] == 0) { ?>
                                        <span class="text-warning"> MEMINTA </span>
                                    <?php } ?>
                                </h2>
                            </div>
                        </div>
                    </div>
                    <div class="table-responsive my-3">
                        <table class="table table-bordered">
                            <thead>
                                <tr class="text-center">
                                    <th>#</th>
                                    <th>Nama Produk</th>
                                    <th>Kuantitas</th>
                                    <?php if ($StockTransfer['status'] == 1) : ?>
                                        <th>Input Barang yang di terima</th>
                                        <th>Aksi</th>
                                    <?php endif; ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $i = 1;
                                foreach ($StockTransferProducts as $product) : ?>
                                    <tr class="text-center">
                                        <td><?= $i++; ?></td>
                                        <td><?= $product['stock_transfer_product_name']; ?></td>
                                        <td><?= $product['stock_transfer_product_quantity']; ?></td>
                                        <?php if ($StockTransfer['status'] == 1) : ?>
                                            <form action="<?= base_url('stockTransferHandoverStuff/updateStatusReq'); ?>" method="post">
                                                <td>
                                                    <input type="number" class="form-control" name="inputReceiveProduct" id="inputReceiveProduct" value="<?= $product["stock_transfer_product_receive"]; ?>" <?= ($product['stock_transfer_product_quantity'] == $product['stock_transfer_product_receive']) ? 'disabled' : ''; ?>>
                                                </td>
                                                <?php if ($product['stock_transfer_product_quantity'] != $product['stock_transfer_product_receive']) : ?>
                                                    <td>
                                                        <input type="hidden" name="idstockTransferProduct" value="<?= $product['id']; ?>">
                                                        <input type="hidden" name="stockTransferID" value="<?= $StockTransfer['stockTransferID']; ?>">
                                                        <button type="submit" class="btn btn-info  mt-3 mr-2">Simpan dan Pindah ke Kartu Stock</button>
                                                    </td>
                                            </form>
                                        <?php else : ?>
                                            <td>
                                                <button type="submit" class="btn btn-success  mt-3 mr-2" disabled>Dipindah Ke kartu stok</button>
                                            </td>
                                            </form>
                                        <?php endif; ?>
                                        </td>
                                    <?php endif; ?>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                        <div class="text-center">
                            <?php foreach ($StockTransferProducts as $product) :  ?>
                            <?php endforeach; ?>
                            <?php if ($product['stock_transfer_product_quantity'] == $product['stock_transfer_product_receive']) : ?>
                                <form action="<?= base_url('stockTransferHandoverStuff/updateStatus'); ?>" method="post">
                                    <input type="hidden" name="stockTransferID" value="<?= $StockTransfer['stockTransferID']; ?>">
                                    <button type="submit" class="btn btn-primary btn-lg mt-3" value="2" name="inputStockTransferStatus" onclick="return confirm('Apakah Semua Barang Sudah Di terima?')">Semua Barang Telah diterima</button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?= $this->endSection(); ?>