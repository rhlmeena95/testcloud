<?= $this->extend('layouts/main'); ?>
<?= $this->section('content'); ?>

<div class="row layout-top-spacing" id="cancel-row">
	<div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
		<div class="widget-content widget-content-area br-6">
			<h4 class="my-3 text-center">Pengaturan Diskon</h4>
			<div class="text-right mt-3">
				<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#discountForm">
					<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-plus-square">
						<rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
						<line x1="12" y1="8" x2="12" y2="16"></line>
						<line x1="8" y1="12" x2="16" y2="12"></line>
					</svg>
					Tambah Diskon
				</button>
			</div>
			<ul class="nav nav-tabs" id="myTab" role="tablist">
				<li class="nav-item">
					<a class="nav-link active" id="discountAll-tab" data-toggle="tab" href="#discountAll" role="tab" aria-controls="discountAll" aria-selected="true">Membership</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" id="minimumItem-tab" data-toggle="tab" href="#minimumItem" role="tab" aria-controls="minimumItem" aria-selected="false">Minimum Item</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false">Kategori Barang</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" id="birthday-tab" data-toggle="tab" href="#birthday" role="tab" aria-controls="birthday" aria-selected="false">Ulang Tahun</a>
				</li>
			</ul>
			<div class="tab-content" id="myTabContent">
				<div class="tab-pane fade show active" id="discountAll" role="tabpanel" aria-labelledby="discountAll-tab">
					<div class="table-responsive">
						<table class="table table-striped dataTable" style="width:100%">
							<thead>
								<tr class="text-center">
									<th>#</th>
									<th>Nama Diskon</th>
									<th>Diskon Berdasarkan</th>
									<th>Persentase (%)</th>
									<th>Status</th>
									<th>Aksi</th>
								</tr>
							</thead>
							<tbody id="table-discountMember">
								<tr class="text-center">
									<td class="text-center">1</td>
									<td><?= $discountMember['discount_name']; ?></td>
									<td><?= ($discountMember['discount_type'] == '1') ? 'Membership' : ''; ?></td>
									<td class="text-center"><?= $discountMember['precentage']; ?></td>
									<td>
										<div class="n-chk">
											<label class="new-control new-checkbox checkbox-primary">
												<input type="checkbox" class="new-control-input BtnUpdate" id="status" data-type="<?= ($discountMember['is_active'] == 1) ? '0' : '1'; ?>" name="inputStatus" data-id="<?= $discountMember['id']; ?>" <?= ($discountMember['is_active'] == 1) ? 'checked' : ''; ?>>
												<span class="new-control-indicator"></span>Status
											</label>
										</div>
									</td>
									<td>
										<button class="btn btn-primary btn-sm btnSupp" data-toggle="modal" data-target="#updateDiscountModal<?= $discountMember['id']; ?>">
											<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-edit">
												<path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
												<path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
											</svg> Ubah
										</button>
									</td>
								</tr>
								<!-- Discount Modal -->
								<div class="modal fade" id="updateDiscountModal<?= $discountMember['id']; ?>" tabindex="-1" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true">
									<div class="modal-dialog" role="document">
										<div class="modal-content">
											<div class="modal-header">
												<h5 class="modal-title"><?= ($discountMember['discount_type'] == '1') ? 'Membership' : ''; ?></h5>
												<button type="button" class="close" data-dismiss="modal" aria-label="Close">
													<span aria-hidden="true">&times;</span>
												</button>
											</div>
											<div class="modal-body">
												<form action="<?= base_url('discount/update'); ?>" method="post">
													<input type="hidden" name="idDiscount" id="idDiscount" value="<?= $discountMember['id']; ?>">
													<div class="form-group">
														<label for="inputDiscountName">Nama Diskon</label>
														<input type="text" class="form-control" name="inputDiscountName" id="discountName" required value="<?= $discountMember['discount_name']; ?>">
													</div>
													<div class="form-input-group">
														<label for="">Input Persentase</label>
														<div class="input-group mb-3">
															<input type="number" class="form-control " min="0" value="<?= $discountMember['precentage']; ?>" name="inputDiscountPercent" id="inputDiscountPercent">
															<div class="input-group-append">
																<span class="input-group-text" id="basic-addon6">%</span>
															</div>
														</div>
													</div>
													<input type="hidden" class="form-control " min="0" value="0" name="inputMinimalItem" id="inputMinimalItem">
													<input type="hidden" class="form-control " min="0" value="0" name="inputMaxItem" id="inputMaxItem">
													<input type="hidden" class="form-control " min="0" value="1" name="categoryDiscount" id="categoryDiscount">
													<input type="hidden" class="form-control " min="0" value="0" name="productCategory" id="productCategory">
											</div>
											<div class="modal-footer">
												<button type="submit" class="btn btn-primary ">Simpan</button>
											</div>
											</form>
										</div>
									</div>
								</div>
							</tbody>
						</table>
					</div>
				</div>
				<div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
					<div class="table-responsive">
						<table class="table table-striped dataTable" style="width:100%">
							<thead>
								<th>#</th>
								<th>Nama Kategori Barang</th>
								<th>Persentase (%)</th>
								<th>Status</th>
								<th>Aksi</th>
							</thead>
							<tbody>
								<?php $i = 1;
								foreach ($DiscountCategoryP as $categoryProduct) : ?>
									<tr>
										<td><?= $i++; ?></td>
										<td><?= $categoryProduct['product_subdep_name']; ?></td>
										<td><?= $categoryProduct['precentage']; ?></td>
										<td>
											<div class="n-chk">
												<label class="new-control new-checkbox checkbox-primary">
													<input type="checkbox" class="new-control-input BtnUpdate" id="status" data-type="<?= ($categoryProduct['is_active'] == 1) ? '0' : '1'; ?>" name="taxType" data-id="<?= $categoryProduct['discountID']; ?>" <?= ($categoryProduct['is_active'] == 1) ? 'checked' : ''; ?>>
													<span class="new-control-indicator"></span>Status
												</label>
											</div>
										</td>
										<td>
											<button class="btn btn-primary btn-sm btnUpdateCategory" data-toggle="modal" data-target="#updateDicountCategory" data-id="<?= $categoryProduct['discountID']; ?>" data-name="<?= $categoryProduct['product_subdep_name']; ?>" data-code="<?= $categoryProduct['product_subdep_code']; ?>" data-precentage="<?= $categoryProduct['precentage']; ?>">
												<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-edit">
													<path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
													<path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
												</svg> Ubah
											</button>
										</td>
									</tr>
								<?php endforeach; ?>
							</tbody>
						</table>
					</div>
				</div>
				<div class="tab-pane fade" id="minimumItem" role="tabpanel" aria-labelledby="minimumItem-tab">
					<div class="table-responsive">
						<table class="table table-striped dataTable" style="width:100%">
							<thead>
								<tr class="text-center">
									<th>#</th>
									<th>Nama Diskon</th>
									<th>Diskon Berdasarkan</th>
									<th>Persentase (%)</th>
									<th>Minimal Barang (pcs)</th>
									<th>Maksimal Barang (pcs)</th>
									<th>Status</th>
									<th>Aksi</th>
								</tr>
							</thead>
							<tbody>
								<?php $i = 1;
								foreach ($discountItem as $discount) : ?>
									<tr>
										<td class="text-center"><?= $i++; ?></td>
										<td><?= $discount['discount_name']; ?></td>
										<td><?= ($discount['discount_type'] == '2') ? 'Diskon Berdasarkan Jumlah Kuantitas' : ''; ?></td>
										<td class="text-center"><?= $discount['precentage']; ?></td>
										<td class="text-center"><?= $discount['min_item']; ?></td>
										<td class="text-center"><?= $discount['max_item']; ?></td>
										<td>
											<div class="n-chk">
												<label class="new-control new-checkbox checkbox-primary">
													<input type="checkbox" class="new-control-input BtnUpdate" id="status" data-type="<?= ($discount['is_active'] == 1) ? '0' : '1'; ?>" name="taxType" data-id="<?= $discount['id']; ?>" <?= ($discount['is_active'] == 1) ? 'checked' : ''; ?>>
													<span class="new-control-indicator"></span>Status
												</label>
											</div>
										</td>
										<td>
											<button class="btn btn-primary btn-sm btnSupp" data-toggle="modal" data-target="#updateDiscountModal<?= $discount['id']; ?>">
												<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-edit">
													<path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
													<path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
												</svg> Ubah
											</button>
										</td>
									</tr>
									<!-- Discount Modal -->
									<div class="modal fade" id="updateDiscountModal<?= $discount['id']; ?>" tabindex="-1" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true">
										<div class="modal-dialog" role="document">
											<div class="modal-content">
												<div class="modal-header">
													<h5 class="modal-title"><?= ($discount['discount_type'] == 'jumlah') ? 'Diskon Berdasarkan Jumlah Kuantitas' : 'Membership'; ?></h5>
													<button type="button" class="close" data-dismiss="modal" aria-label="Close">
														<span aria-hidden="true">&times;</span>
													</button>
												</div>
												<div class="modal-body">
													<form action="<?= base_url('discount/update'); ?>" method="post">
														<input type="hidden" name="idDiscount" id="idDiscount" value="<?= $discount['id']; ?>">
														<div class="form-group">
															<label for="inputDiscountName">Nama Diskon</label>
															<input type="text" class="form-control" name="inputDiscountName" id="inputDiscountName" required value="<?= $discount['discount_name']; ?>">
														</div>
														<div class="form-input-group">
															<label for="">Input Persentase</label>
															<div class="input-group mb-3">
																<input type="number" class="form-control " min="0" value="<?= $discount['precentage']; ?>" name="inputDiscountPercent" id="inputDiscountPercent">
																<div class="input-group-append">
																	<span class="input-group-text" id="basic-addon6">%</span>
																</div>
															</div>
														</div>
														<div class="form-input-group">
															<label for="inputMinimalItem">Input Minimal Barang</label>
															<div class="input-group mb-3">
																<input type="number" class="form-control " min="0" value="<?= $discount['min_item']; ?>" name="inputMinimalItem" id="inputMinimalItem">
															</div>
														</div>
														<div class="form-input-group">
															<label for="inputMaxItem">Input Maksimal Barang</label>
															<div class="input-group mb-3">
																<input type="number" class="form-control " min="0" value="<?= $discount['max_item']; ?>" name="inputMaxItem" id="inputMaxItem">
															</div>
														</div>
														<input type="hidden" class="form-control " min="0" value="3" name="categoryDiscount" id="categoryDiscount">
														<input type="hidden" class="form-control " min="0" value="0" name="productCategory" id="productCategory">
												</div>
												<div class="modal-footer">
													<button type="submit" class="btn btn-primary ">Simpan</button>
												</div>
												</form>
											</div>
										</div>
									</div>
								<?php endforeach; ?>
							</tbody>
						</table>
					</div>
				</div>
				<div class="tab-pane fade" id="birthday" role="tabpanel" aria-labelledby="birthday-tab">
					<div class="table-responsive">
						<table class="table table-striped dataTable" style="width:100%">
							<thead>
								<tr class="text-center">
									<th>#</th>
									<th>Nama Diskon</th>
									<th>Diskon Berdasarkan</th>
									<th>Persentase (%)</th>
									<th>Status</th>
									<th>Aksi</th>
								</tr>
							</thead>
							<tbody>
								<tr class="text-center">
									<td class="text-center">1</td>
									<td><?= $DiscountBirthday['discount_name']; ?></td>
									<td><?= ($DiscountBirthday['discount_type'] == '4') ? 'Hari Ulang Tahun' : ''; ?></td>
									<td class="text-center"><?= $DiscountBirthday['precentage']; ?></td>
									<td>
										<div class="n-chk">
											<label class="new-control new-checkbox checkbox-primary">
												<input type="checkbox" class="new-control-input BtnUpdate" id="status" data-type="<?= ($DiscountBirthday['is_active'] == 1) ? '0' : '1'; ?>" name="taxType" data-id="<?= $DiscountBirthday['id']; ?>" <?= ($DiscountBirthday['is_active'] == 1) ? 'checked' : ''; ?>>
												<span class="new-control-indicator"></span>Status
											</label>
										</div>
									</td>
									<td>
										<button class="btn btn-primary btn-sm btnSupp" data-toggle="modal" data-target="#updateBirthdayModal<?= $DiscountBirthday['id']; ?>">
											<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-edit">
												<path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
												<path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
											</svg> Ubah
										</button>
									</td>
								</tr>
								<!-- Discount Modal -->
								<div class="modal fade" id="updateBirthdayModal<?= $DiscountBirthday['id']; ?>" tabindex="-1" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true">
									<div class="modal-dialog" role="document">
										<div class="modal-content">
											<div class="modal-header">
												<h5 class="modal-title">Ulang Tahun Customer</h5>
												<button type="button" class="close" data-dismiss="modal" aria-label="Close">
													<span aria-hidden="true">&times;</span>
												</button>
											</div>
											<div class="modal-body">
												<form action="<?= base_url('discount/update'); ?>" method="post">
													<input type="hidden" name="idDiscount" id="idDiscount" value="<?= $DiscountBirthday['id']; ?>">
													<div class="form-group">
														<label for="inputDiscountName">Nama Diskon</label>
														<input type="text" class="form-control" name="inputDiscountName" id="inputDiscountName" required value="<?= $DiscountBirthday['discount_name']; ?>">
													</div>
													<div class="form-group">
														<label for="inputDiscountType">Diskon Berdasarkan</label>
														<input type="text" class="form-control" name="inputDiscountType" id="inputDiscountType" readonly value="<?= $DiscountBirthday['discount_name']; ?>" style="color:black">
													</div>
													<div class="form-input-group">
														<label for="">Input Persentase</label>
														<div class="input-group mb-3">
															<input type="number" class="form-control " min="0" value="<?= $DiscountBirthday['precentage']; ?>" name="inputDiscountPercent" id="inputDiscountPercent">
															<div class="input-group-append">
																<span class="input-group-text" id="basic-addon6">%</span>
															</div>
														</div>
													</div>
													<input type="hidden" class="form-control " min="0" value="0" name="inputMinimalItem" id="inputMinimalItem">
													<input type="hidden" class="form-control " min="0" value="0" name="inputMaxItem" id="inputMaxItem">
													<input type="hidden" class="form-control " min="0" value="4" name="categoryDiscount" id="categoryDiscount">
													<input type="hidden" class="form-control " min="0" value="0" name="productCategory" id="productCategory">
											</div>
											<div class="modal-footer">
												<button type="submit" class="btn btn-primary ">Simpan</button>
											</div>
											</form>
										</div>
									</div>
								</div>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>


<!-- Modal -->
<div class="modal fade" id="updateDicountCategory" tabindex="-1" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title">Kategori Barang</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
				<form action="<?= base_url('discount/update'); ?>" method="post">
					<input type="hidden" name="idDiscount" id="DiscountCategory">
					<div class="form-group">
						<label for="inputNameCategory">Nama Kategori Barang</label>
						<input type="text" class="form-control" name="inputNameCategory" id="CategoryName" readonly>
					</div>
					<div class="form-input-group">
						<label for="">Input Persentase</label>
						<div class="input-group mb-3">
							<input type="number" class="form-control " min="0" name="inputDiscountPercent" id="PrecentageDisc">
							<div class="input-group-append">
								<span class="input-group-text" id="basic-addon6">%</span>
							</div>
						</div>
					</div>
					<input type="hidden" class="form-control " min="0" value="0" name="inputMinimalItem" id="inputMinimalItem">
					<input type="hidden" class="form-control " min="0" value="0" name="inputMaxItem" id="inputMaxItem">
					<input type="hidden" class="form-control " min="0" value="2" name="categoryDiscount" id="categoryDiscount">
					<input type="hidden" class="form-control " min="0" value="2" name="productCategory" id="codeCategory">
					<input type="hidden" class="form-control " min="0" value="0" name="inputDiscountName" id="inputDiscountName">
			</div>
			<div class="modal-footer">
				<button type="submit" class="btn btn-primary ">Simpan</button>
			</div>
			</form>
		</div>
	</div>
</div>

<!-- Modal update Category -->
<div class="modal fade" id="discountForm" tabindex="-1" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<form action="<?= base_url('discount/create'); ?>" method="post">
				<div class="modal-header">
					<h5 class="modal-title">Buat Diskon Baru</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<div class="modal-body">
					<div class="form-group">
						<label for="categoryDiscount">Pilih Kategori Diskon</label>
						<select name="categoryDiscount" id="CategoryDisc" class="form-control" required>
							<option value="">--- Pilih Kategori ---</option>
							<option value="1">Membership</option>
							<option value="2">Minimum Item</option>
							<option value="3">Kategori Barang</option>
							<option value="4">Ulang Tahun</option>
						</select>
					</div>
					<div class="form-group" hidden id="DiscountName">
						<label for="inputDiscountName">Nama Discount</label>
						<input type="text" class="form-control" name="inputDiscountName" id="discountName">
					</div>
					<div class="form-group" hidden id="ProductCategory">
						<label for="productCategory">Pilih Kategori Barang</label>
						<select name="productCategory" id="CategoryProduct" class="form-control">
							<option value="">--- Pilih Kategori ---</option>
							<?php foreach ($Subdepartment as $SB) : ?>
								<option value="<?= $SB['product_subdep_code']; ?>"><?= $SB['product_subdep_name']; ?></option>
							<?php endforeach; ?>
						</select>
					</div>
					<div class="form-group" hidden id="Precentage">
						<label for="">Presentase</label>
						<div class="input-group mb-3">
							<input type="number" class="form-control " min="0" name="inputDiscountPercent" id="PrecentageDiscount">
							<div class="input-group-append">
								<span class="input-group-text" id="basic-addon6">%</span>
							</div>
						</div>
					</div>
					<div class="form-group" hidden id="ItemMinimum">
						<label for="">Minimum Pembelian</label>
						<input type="text" name="inputMinimalItem" id="Minimum" class="form-control" placeholder="" aria-describedby="helpId">
					</div>
					<div class="form-group" hidden id="ItemMaximum">
						<label for="">Maksimal Pembelian</label>
						<input type="text" name="inputMaxItem" id="Maximum" class="form-control" placeholder="" aria-describedby="helpId">
					</div>

				</div>
				<div class="modal-footer">
					<button type="submit" class="btn btn-primary">Simpan</button>
				</div>
			</form>
		</div>
	</div>
</div>

<script>
	$('document').ready(function() {
		$('#CategoryDisc').on('change', function() {
			let categoryDiscount = $(this).val();
			switch (categoryDiscount) {
				case '1':
					$('#Precentage').attr('hidden', false);
					$('#PrecentageDiscount').attr('required', true);
					$('#discountName').attr('required', true);
					$('#DiscountName').attr('hidden', false);
					$('#ItemMinimum').attr('hidden', true);
					$('#Minimum').attr('required', false);
					$('#ItemMaximum').attr('hidden', true);
					$('#Maximum').attr('required', false);
					$('#ProductCategory').attr('hidden', true)
					$('#CategoryProduct').attr('required', false)
					break;
				case '3':
					$('#discountName').attr('required', false);
					$('#DiscountName').attr('hidden', true);
					$('#ProductCategory').attr('hidden', false)
					$('#CategoryProduct').attr('required', true)
					$('#Precentage').attr('hidden', false);
					$('#PrecentageDiscount').attr('required', true);
					break;
				case '2':
					$('#discountName').attr('required', true);
					$('#DiscountName').attr('hidden', false);
					$('#ProductCategory').attr('hidden', true)
					$('#CategoryProduct').attr('required', false)
					$('#Precentage').attr('hidden', false);
					$('#PrecentageDiscount').attr('required', true);
					$('#ItemMinimum').attr('hidden', false);
					$('#Minimum').attr('required', true);
					$('#ItemMaximum').attr('hidden', false);
					$('#Maximum').attr('required', true);
					break;
				case '4':
					$('#discountName').attr('required', true);
					$('#DiscountName').attr('hidden', false);
					$('#ProductCategory').attr('hidden', true)
					$('#CategoryProduct').attr('required', false)
					$('#Precentage').attr('hidden', false);
					$('#PrecentageDiscount').attr('required', true);
					$('#ItemMinimum').attr('hidden', true);
					$('#Minimum').attr('required', false);
					$('#ItemMaximum').attr('hidden', true);
					$('#Maximum').attr('required', false);
					break;
				default:
					break;
			}
		});
		$('.btnUpdateCategory').click(function() {
			let id = $(this).data("id");
			let subdepartment = $(this).data("name");
			let code = $(this).data("code");
			let precentage = $(this).data("precentage");
			$('#DiscountCategory').val(id);
			$('#CategoryName').val(subdepartment);
			$('#PrecentageDisc').val(precentage);
			$('#codeCategory').val(code);
		});

		$('.BtnUpdate').click(function() {
			const id = $(this).data("id");
			const status = $(this).data("type");
			$.ajax({
				url: "<?= base_url('discount/updateStatus'); ?>",
				type: 'POST',
				data: {
					id: id,
					status: status
				},
				success: function(result) {}
			});
		});
	});
</script>
<?= $this->endSection(); ?>