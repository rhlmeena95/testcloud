<?php

namespace App\Controllers\Sales;

use App\Controllers\BaseController;
use App\Models\EmployeeModel;
use App\Models\MasterModel;
use App\Models\SalesModel;
use DateTime;

class SalesOrder extends BaseController
{
	function __construct()
	{
		$this->SalesModel = new SalesModel();
		$this->MasterModel = new MasterModel();
		$this->EmployeeModel = new EmployeeModel();
	}
	public function cashier()
	{

		$codeMember = $this->request->getGet('c');
		if ($codeMember) {
			$customerMember = $this->SalesModel->getMemberByCode($codeMember);
			if ($customerMember) {
				$customerMember['id'];
			} elseif ($customerMember == null) {
				session()->setFlashdata('notif_error', '<b>Member Belum Terdaftar</b>');
				return redirect()->to(base_url('cashier'));
			}
		} else {
			$customerMember = null;
		}
		$data = array_merge($this->data, [
			'category'      	=> 'Penjualan',
			'title'         	=> 'Kasir',
			'Member'			=> $customerMember,
			'PaymentMethod'		=> $this->MasterModel->getPaymentMethod(),
			'SalesOrderCancel'	=> $this->SalesModel->getSalesOrderByBranchCancel(),
			'Products'  		=> $this->SalesModel->getProductByStock(),
			'member'			=> $this->SalesModel->getMember(),
			'Province'			=> $this->MasterModel->getProvince(),
			'user'				=> $this->userModel->getUser(userID: session()->get('user_id')),
			'branch'    		=> $this->MasterModel->getBranch(session()->get('branch_id')),
		]);
		$checkTransaction = $this->SalesModel->checkTransaction();
		if ($checkTransaction) {
			return view('sales/chasier', $data);
		} else {
			// session()->setFlashdata('notif_success', '<b>Silahkan Input Modal Awal</b>');
			return redirect()->to(base_url('cashier/openingCashier'));
		}
	}
	public function saveTempSalesOrder()
	{
		$member = $this->request->getVar('memberCode');
		$tax = $this->request->getVar('TotalTax');
		$saveTempSalesOrder = $this->SalesModel->saveTempSalesOrder($member, $this->cart->contents(),  $this->cart->total(), $tax);
		if ($saveTempSalesOrder) {
			session()->setFlashdata('notif_success', '<b>Data penjualan berhasil ditunda</b>');
			$this->cart->destroy();
			return redirect()->to(base_url('cashier'));
		} else {
			session()->setFlashdata('notif_error', '<b>Gagal menunda penjualan</b>');
			return redirect()->to(base_url('cashier'));
		}
	}

	public function saveSalesOrder()
	{
		$member = $this->request->getVar('memberCode');
		$payment = $this->request->getVar('inputPaymentMethod');
		$totalPayment = $this->request->getPost('grandTotal');
		$totalCashBack = $this->request->getPost('Cash');
		$paymentMethod = $this->MasterModel->getPaymentMethod($payment);
		$saveSalesOrder = $this->SalesModel->saveSalesOrder($member, $this->cart->contents(), $this->request->getPost(null), $paymentMethod, $this->cart->total(), $totalPayment, $totalCashBack);
		if ($saveSalesOrder) {
			session()->setFlashdata('notif_success', '<b>Data penjualan berhasil disimpan</b>');
			$this->cart->destroy();
			$transactionID = $this->SalesModel->getTransactionByInvoice($saveSalesOrder);
			$SalesOrder	= $this->SalesModel->getSalesOrderByInvoice($saveSalesOrder, $transactionID['sales_order_transaction_id']);
			$data = array_merge($this->data, [
				'SalesOrder'			=> $SalesOrder,
				'SalesOrderProduct'		=> $this->SalesModel->getSalesOrderProductBySalesOrder($SalesOrder['sales_order_invoices'], $transactionID['sales_order_transaction_id']),
				'Print'					=> $this->SalesModel->getDataPrint(),
				'Branch'    			=> $this->MasterModel->getBranchbyBranch(),
			]);
			return view('settings/print', $data);
		} else {
			session()->setFlashdata('notif_error', '<b>Gagal menyimpan data penjualan</b>');
			return redirect()->to(base_url('cashier'));
		}
	}
	public function voidSalesOrder()
	{
		$voidSalesOrder = $this->SalesModel->voidSalesOrder($this->request->getPost(null));
		if ($voidSalesOrder) {
			session()->setFlashdata('notif_success', '<b>Berhasil membatalkan Transaksi</b>');
			$this->cart->destroy();
			return redirect()->to(base_url('salesOrderHistory'));
		} else {
			session()->setFlashdata('notif_error', '<b>Gagal membatalkan Transaksi</b>');
			return redirect()->to(base_url('salesOrderHistory'));
		}
	}

	public function openingCashier()
	{
		$data = array_merge($this->data, [
			'category'      	=> 'Penjualan',
			'title'         	=> 'Buka Modal',
		]);
		return view('sales/inputOpeningCash', $data);
	}
	public function saveOpeningCash()
	{
		$saveOpeningCash = $this->SalesModel->saveOpenCash($this->request->getPost(null));
		if ($saveOpeningCash) {
			session()->setFlashdata('notif_success', '<b>Berhasil input modal awal</b>');
			return redirect()->to(base_url('cashier'));
		} else {
			session()->setFlashdata('notif_error', '<b>Gagal input modal awal</b>');
			return redirect()->to(base_url('cashier/openingCashier'));
		}
	}
	public function saveCustomers()
	{
		$createCustomers = $this->SalesModel->createCustomers($this->request->getPost(null));
		if ($createCustomers) {
			if ($this->request->getPost('inputan') == 2) {
				session()->setFlashdata('notif_success', '<b>Berhasil menambah member Baru</b>');
				return redirect()->to(base_url('cashier'));
			} else {
				session()->setFlashdata('notif_success', '<b>Berhasil menambah member Baru</b>');
				return redirect()->to(base_url('customers'));
			}
		} else {
			if ($this->request->getPost('inputan') == 2) {
				session()->setFlashdata('notif_error', '<b>Gagal menambahkan member baru</b>');
				return redirect()->to(base_url('cashier'));
			} else {
				session()->setFlashdata('notif_error', '<b>Gagal menambahkan member baru</b>');
				return redirect()->to(base_url('customers'));
			}
		}
	}
	public function closingCash()
	{
		$salesOrder = $this->SalesModel->getSalesOrderSucces();
		$checkTransaction =  $this->SalesModel->checkTransaction();
		$saveClosingCash = $this->SalesModel->saveClosingCash($salesOrder, $checkTransaction, $this->request->getPost(null));
		if ($saveClosingCash) {
			session()->setFlashdata('notif_success', '<b>Berhasil Menutup Transaksi Kasir</b>');
			$transaction = $this->SalesModel->getTransactionByDate($saveClosingCash);
			$cardPayment = $this->SalesModel->getTotalByCardPayment($saveClosingCash);
			$cashPayment = $this->SalesModel->getTotalByCashPayment($saveClosingCash);
			if ($cardPayment) {
				$totalCardPayment = $cardPayment['sales_order_total'] - $cardPayment['sales_order_discount'];
			} else {
				$totalCardPayment = 0;
			}
			$totalCashPayment = $cashPayment['sales_order_total'] - $cashPayment['sales_order_discount'];
			$data = array_merge($this->data, [
				'Transaction'				=> $transaction,
				'TotalQty'					=> $this->SalesModel->getTotalQty($saveClosingCash),
				'TotalSalesOrder'			=> $this->SalesModel->getTotalByDay($saveClosingCash),
				'TotalCashPayment'			=> $totalCashPayment,
				'TotalCardPayment'			=> $totalCardPayment,
				'TotalVoid'					=> $this->SalesModel->getTotalByVoid($saveClosingCash),
				'Branch'    				=> $this->MasterModel->getBranchbyBranch(),
			]);
			return view('settings/printClosingCash', $data);
		} else {
			session()->setFlashdata('notif_error', '<b>Gagal Menutup Transaksi Kasir</b>');
			return redirect()->to(base_url('cashier'));
		}
	}
	public function checkSalesOrder()
	{
		#Check Void Period
		$periodEndTime = $this->SalesModel->getVoidPeriodbyendTime();
		$time = $this->SalesModel->getVoidPeriodbyStartTime();
		$voidPeriod = $periodEndTime['void_period_time'] * 60;
		if ($time) {
			$startTime = strtotime($time['sales_order_created_at']);
			$endTime = time() - $startTime;
			if ($endTime > $voidPeriod) {
				$this->SalesModel->cancelOrder($time['id']);
			}
		}
	}
	public function cancelOrder()
	{
		$cancelOrder = $this->request->getVar('dataCancelOrder');
		$saveCancelOrder = $this->SalesModel->cancelOrder($cancelOrder);
		if ($saveCancelOrder) {
			session()->setFlashdata('notif_success', '<b>Berhasil membatalkan Transaksi</b>');
			return redirect()->to(base_url('cashier'));
		} else {
			session()->setFlashdata('notif_error', '<b>Gagal membatalkan Transaksi</b>');
			return redirect()->to(base_url('cashier'));
		}
	}

	public function getDataProduct()
	{
		$Products = $this->SalesModel->getProductByStock();
		$output = '';
		$i     = 0;
		foreach ($Products as $products) {
			$i++;
			$output .= '
				<tr>
					<td>' . $i . '</td>
					<td>' . $products['product_subdep_name'] . '</td>
					<td>' . $products['product_sku'] . '</td>
					<td>' . $products['product_name'] . '</td>
					<td>Rp.' . number_format($products['product_selling_price']) . '</td>
					<td><input type="number" min="0" max="' . $products['stock_product_qty_new'] . '" name="quantity" id="quantity' . $products['productID'] . '" class="form-control" value="1">
					</td>
					<td>
					<button type="submit" class="btn btn-primary btn-sm AddBtn" data-id="' . $products['productID'] . '" data-name="' . $products['product_name'] . '" data-price="' . $products['product_selling_price'] . ' " data-sku="' . $products['product_sku'] . '">
						<svg xmlns="http://www.w3.org/2000/svg" width="6" height="6" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-plus-circle">
							<circle cx="12" cy="12" r="10"></circle>
							<line x1="12" y1="8" x2="12" y2="16"></line>
							<line x1="8" y1="12" x2="16" y2="12"></line>
						</svg> Tambah </button>
					</td>
				</tr>';
		}
		return $output;
	}

	public function history()
	{
		if ($this->request->getGet('id')) {
			$data = array_merge($this->data, [
				'category'     			=> 'Penjualan',
				'title'         		=> 'Detail Transaksi',
				'SalesOrder'			=> $this->SalesModel->getSalesOrderByInvoice($this->request->getGet('id'), $this->request->getGet('p')),
				'SalesOrderProduct'		=> $this->SalesModel->getSalesOrderProductBySalesOrder($this->request->getGet('id'), $this->request->getGet('p')),
			]);
			return view('sales/salesOrderDetail', $data);
		}
		$date = $this->request->getGet('d');
		if ($date) {
			$salesOrder = $this->SalesModel->getSalesOrderByBranch($date);
			$totalTransaction = $this->SalesModel->getTotalByDate($date);
			$totalqty = $this->SalesModel->getTotalByQty($date);
		} else {
			$salesOrder = $this->SalesModel->getSalesOrderByBranch();
			$totalTransaction = null;
			$totalqty = null;
		}
		$data = array_merge($this->data, [
			'category'     		=> 'Penjualan',
			'title'         	=> 'Riwayat Transaksi',
			'SalesOrder'		=> $salesOrder,
			'qty'				=> $totalqty,
			'CheckTransaction'	=> $this->SalesModel->checkTransactionVoid(),
			'Branch'    		=> $this->MasterModel->getBranch(),
			'TotalTransaction'	=> $totalTransaction,
			'Date'				=> $date
		]);
		// dd($data);
		return view('sales/salesOrderList', $data);
	}
	public function getVoidTable()
	{
		$SalesOrderVoid	= $this->SalesModel->getSalesOrderByVoid();
		$output = '';
		$i     = 0;
		foreach ($SalesOrderVoid as $salesOrder) {
			$i++;
			$prdate = new DateTime($salesOrder['sales_order_void_at']);
			$output .= ' 
			<tr>
				<td>  ' . $i . '  </td>
				<td>'  . $salesOrder['sales_order_invoices'] .  '</td>
				<td class="text-center">' . $prdate->format('d F Y, H:i') . '</td>
				<td class="text-center"><span class="badge badge-danger"> Dibatalkan </span></td>
				<td class="text-wrap">' . $salesOrder['sales_order_void_description'] . ' </td>
			</tr>';
		}
		return $output;
	}
	public function printPreview()
	{
		$data = array_merge($this->data, [
			'category'  			=> 'Pengaturan',
			'title'         		=> 'Tampilan Print',
			'Print'					=> $this->SalesModel->getDataPrint(),
			'Branch'    			=> $this->MasterModel->getBranchbyBranch(),
		]);

		return view('settings/printPreview', $data);
	}
	public function savePrint()
	{
		$savePrint = $this->SalesModel->savePrint($this->request->getPost(null));
		if ($savePrint) {
			session()->setFlashdata('notif_success', '<b>Berhasil membuat baris</b>');
			return redirect()->to(base_url('print'));
		} else {
			session()->setFlashdata('notif_error', '<b>Gagal membuat baris</b>');
			return redirect()->to(base_url('print'));
		}
	}
	public function updatePrintPreview()
	{
		$updatePrintPreview = $this->SalesModel->updatePrintPreview($this->request->getPost(null));
		if ($updatePrintPreview) {
			session()->setFlashdata('notif_success', '<b>Berhasil merubah baris</b>');
			return redirect()->to(base_url('print'));
		} else {
			session()->setFlashdata('notif_error', '<b>Gagal merubah baris</b>');
			return redirect()->to(base_url('print'));
		}
	}
	public function updateStatusTransferMoney()
	{
		$status = $this->request->getPost('status');
		$date = $this->request->getPost('date');
		$saveUpdateStatus = $this->SalesModel->statusTransferMoneySales($status, $date);
		return 'success';
	}
	function getCity()
	{
		$ProvinceID = $this->request->getPost('province');
		$getCity = $this->MasterModel->getCity($ProvinceID);
		$output = '';
		foreach ($getCity as $city) {
			$output .= '
			<option value="' . $city['id'] . '">' . $city['city_type'] . ' ' . $city['city_name'] . '</option>';
		}
		return $output;
	}
	function getSubdistrict()
	{
		$cityID = $this->request->getPost('city');
		$getSubdistrict = $this->MasterModel->getSubdistrict($cityID);
		$output = '';
		foreach ($getSubdistrict as $subdistrict) {
			$output .= '
			<option value="' . $subdistrict['id'] . '">' . $subdistrict['subdistrict_name'] . '</option>';
		}
		return $output;
	}
}
