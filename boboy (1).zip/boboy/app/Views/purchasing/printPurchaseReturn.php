<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Point of Sale Toko Mainan Boboy">
    <meta name="author" content="Codavlo Indonesia">
    <link rel="icon" type="image/x-icon" href="<?= base_url('assets/img/logotoko1.jpeg') ?>" />
    <title>Print Surat Jalan | Toko Mainan Boboy</title>
    <script src="<?= base_url('assets/js/libs/jquery-3.6.0.js') ?>"></script>
    <style>
        hr {
            display: block;
            margin-top: 0.2em;
            margin-bottom: 0.2em;
            margin-left: 0.25em;
            margin-right: 0.25em;
            border-style: inset;
            border-width: 1px;
        }

        @media print {
            body * {
                visibility: hidden;
            }

            #section-to-print,
            #section-to-print * {
                visibility: visible;
            }

            #section-to-print {
                position: absolute;
                left: 0;
                top: 0;
            }
        }

        .text-center {
            margin-left: 7.5%;
            margin-top: 0.5%;
        }
    </style>
    <link href="<?= base_url('bootstrap/css/bootstrap.css') ?>" rel="stylesheet" type="text/css">
</head>

<body onload="window.print()">
    <div style="width:100%;" id="section-to-print">
        <div class="card">
            <div class="card-body">
                <h4 class="text-center">Detail pengembalian barang</h4>
                <hr class=" mb-5">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-sm-8">
                            <table class="table table-bordered table-hover" style="color:black">
                                <tr class="font-weight-bold">
                                    <td>Nomor Invoice</td>
                                    <td><?= $PurchaseReturn['purchase_return_invoice'] ?></td>
                                </tr>
                                <tr>
                                    <td>Tanggal Pembuatan</td>
                                    <td>
                                        <?php $prdate = new DateTime($PurchaseReturn['purchase_return_returned_at']);
                                        echo date_indo($prdate->format('Y-m-d')) . ', ' . $prdate->format('H:i');  ?>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Supplier</td>
                                    <td><?= $PurchaseReturn['supplier_company'] ?></td>
                                </tr>
                            </table>
                        </div>
                        <div class="col-sm-4">
                            <h5 class="font-weight-bold">Alasan Pengembalian</h5>
                            <p><?= $PurchaseReturn['purchase_return_reason'] ?></p>
                            <br>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <table class="table table-bordered table-hover" style="color:black">
                                <thead>
                                    <th>#</th>
                                    <th>Nama Product</th>
                                    <th>Jumlah Pengembalian</th>
                                </thead>
                                <tbody>
                                    <?php $no = 1;
                                    foreach ($PurchaseReturnProduct as $product) : ?>
                                        <tr>
                                            <td><?= $no++; ?></td>
                                            <td><?= $product['purchase_return_product_name'] ?></td>
                                            <td><?= $product['purchase_return_qty'] ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-5 text-center">
                            <table class="table table-bordered " style="color:black">
                                <thead>
                                    <tr>
                                        <th class="text-center">Diterima Oleh</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr class="text-center">
                                        <td>
                                            <br>
                                            <br>
                                            <br>
                                            <br>
                                            .....................................
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <div class="col-5 text-center">
                            <table class="table table-bordered " style="color:black">
                                <thead>
                                    <tr>
                                        <th class="text-center">Dibuat Oleh</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr class="text-center">
                                        <td>
                                            <br>
                                            <br>
                                            <br>
                                            <br>
                                            <?= $PurchaseReturn['branch_name'] ?>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="text-center">
        <button onclick="window.location.href='<?= base_url('purchaseReturn'); ?>'">Kembali</button>
    </div>
    <script>
        function pageRedirect() {
            window.location.replace("<?= base_url('purchaseReturn'); ?>");
        }
        setTimeout("pageRedirect()", 2000);
    </script>
</body>

</html>