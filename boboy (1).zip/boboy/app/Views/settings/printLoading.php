<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <?php header("refresh:3; url=" . base_url('cashier/print?inv=') . $SalesOrder['sales_order_invoices'] . "") ?>
    <div id="msg" style="font-size:15pt; text-align:center">
        Loading, please wait...
        <div>

        </div>
    </div>
    <div id="body" style="display:none;">
        <!-- everything else -->
    </div>
    <script type="text/javascript">
        $(document).ready(function() {
            $('#body').show();
            $('#msg').hide();
        });
    </script>
</body>

</html>