<?= $this->extend('layouts/main'); ?>
<?= $this->section('content'); ?>

<form action="<?= base_url('stockTransfer/save'); ?>" method="post">
    <div class="card mt-3">
        <div class="card-body">
            <div class="form-group">
                <label for="inputCustomerIsActive">Pengiriman Ke Cabang</label>
                <select class="form-control" id="inputBranch" name="inputBranch">
                    <option value="">-- Pilih Cabang -- </option>
                    <?php foreach ($Branch as $branch) : ?>
                        <option value="<?= $branch['branchID']; ?>" <?= (session()->get('branch_id') == $branch['branchID']) ? 'disabled' : $branch['branchID']; ?>><?= $branch['branch_name']; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="table-responsive">
                <table class="table table-bordered item-table">
                    <thead>
                        <tr>
                            <th class="">#</th>
                            <th>Nama Barang</th>
                            <th class="">Harga</th>
                            <th>Kuantitas</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody id="detailStockCart">
                    </tbody>
                </table>
            </div>
            <div class="text-right">
                <button type="button" class="btn btn-danger btn-sm resetData">Reset</button>
                <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#productList">Tambah Barang</button>
            </div>
            <hr>
            <div class="row text-center">
                <div class="col-md-12">
                    <button type="submit" class="btn btn-primary btn-lg mt-5">Simpan & Print Surat Jalan</button>
                </div>
            </div>
        </div>
    </div>
</form>
<div class="modal fade" id="productList" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="productListLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="productListLabel">Data Barang</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="table-responsive">
                    <table class="table table-striped dataTable" style="width:100%">
                        <thead>
                            <th>#</th>
                            <th>Kategori Barang</th>
                            <th>SKU</th>
                            <th>Nama Barang</th>
                            <!-- <th>Harga Jual</th> -->
                            <th>Jumlah</th>
                            <th>Aksi</th>
                        </thead>
                        <tbody>
                            <?php
                            $i = 1;
                            foreach ($Products as $products) : ?>
                                <tr>
                                    <td><?= $i++; ?></td>
                                    <td><?= $products['product_subdep_name'] ?> </td>
                                    <td><?= $products['product_sku'] ?> </td>
                                    <td><?= $products['product_name'] ?> </td>
                                    <!-- <td>Rp. </?= number_format($products['product_selling_price']); ?></td> -->
                                    <td><input type="number" min="0" name="quantity" id="quantity<?= $products['productID'] ?>" class="form-control" value="1"></td>
                                    <td>
                                        <button type="submit" class="btn btn-primary btn-sm btnAdd" data-id="<?= $products['productID'] ?>" data-name="<?= $products['product_name'] ?>" data-price="<?= $products['product_selling_price'] ?>">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="6" height="6" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-plus-circle">
                                                <circle cx="12" cy="12" r="10"></circle>
                                                <line x1="12" y1="8" x2="12" y2="16"></line>
                                                <line x1="8" y1="12" x2="16" y2="12"></line>
                                            </svg> Tambah </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    $('document').ready(function() {
        $('.dataTable').on('click', '.btnAdd', function() {
            const product_id = $(this).data("id");
            const price = $(this).data("price");
            const quantity = $('#quantity' + product_id).val();
            let str = $(this).data("name");
            let slash = str.replace("/", " per ");
            let slashp = slash.replace("/", " perdua ");
            let and = slashp.replace(/\+/g, " dan ");
            let and2 = and.replace("&", " dan2 ");
            let quotes = and2.replace('"', " petikdua ");
            let quote = quotes.replace("'", " petik ");
            let colon = quote.replace(":", " titikdua ");
            let line = quotes.replace("|", " garis ");
            let backtig = line.replace("`", " petikbalik ");
            let free = backtig.replace("~", " bebas ");
            let strip = free.replace("-", " strip ");
            let tag = strip.replace("(", " kurungbuka ");
            let name = tag.replace(")", " kurungtutup ");

            $.ajax({
                url: "<?= base_url('cart/insertStockCart'); ?>",
                method: "POST",
                type: 'JSON',
                data: {
                    id: product_id,
                    name: name,
                    qty: quantity,
                    price: price
                },
                success: function(result) {
                    $('#detailStockCart').html(result);
                    $('#productList').modal('hide');
                }
            });

        });
        // Load shopping cart
        $('#detailStockCart').load("<?= base_url('cart/loadStockCart'); ?>");

        $(document).on('click', '.removeStockCartId', function() {
            const row_id = $(this).attr("id");

            $.ajax({
                url: "<?= base_url('cart/removeStockCart'); ?>",
                method: "POST",
                type: 'JSON',
                data: {
                    rowid: row_id,
                },
                success: function(result) {
                    $('#detailStockCart').html(result);
                }
            });
        });
        $(document).on('click', '.resetData', function() {
            const row_id = $(this).attr("id");

            $.ajax({
                url: "<?= base_url('cart/destroyStockCart'); ?>",
                method: "POST",
                type: 'JSON',
                data: {
                    rowid: row_id,
                },
                success: function(result) {
                    $('#detailStockCart').html(result);
                }
            });
        });
    });
</script>
<?= $this->endSection(); ?>