<?= $this->extend('layouts/main'); ?>
<?= $this->section('content'); ?>

<div class="row layout-top-spacing " id="cancel-row">
    <div class="col-xl-9 col-lg-9 col-sm-9  layout-spacing">
        <div class="widget-content widget-content-area br-6">
            <h1 class="h3 mb-3"><strong><?= $title; ?></strong></h1>
            <div class="table-responsive">
                <table class="multi-table table table-hover" style="width:100%">
                    <tbody class="text-center">
                        <tr>
                            <td>Baris 1</td>
                            <?php if ($Print != null && $Print['line1'] != null) : ?>
                                <form action="<?= base_url('print/update'); ?>" method="post">
                                    <td><textarea class="form-control" name="line1" id="line1" cols="70" rows="4"><?= ($Print != null) ? $Print['line1'] : ''; ?></textarea></td>
                                    <input type="hidden" name="line2" value="<?= ($Print != null) ? $Print['line2'] : ''; ?>">
                                    <input type="hidden" name="line3" value="<?= ($Print != null) ? $Print['line3'] : ''; ?>">
                                    <td><button class="btn btn-outline-info" type="submit">Ubah</button></td>
                                </form>
                            <?php else : ?>
                                <form action="<?= base_url('print/save'); ?>" method="post">
                                    <td><textarea class="form-control" name="line1" id="line1" cols="70" rows="4"></textarea></td>
                                    <td><button class="btn btn-outline-primary" type="submit">Simpan</button></td>
                                </form>
                            <?php endif; ?>
                        </tr>
                        <tr>
                            <td>Baris 2</td>
                            <?php if ($Print != null && $Print['line2'] != null) : ?>
                                <form action="<?= base_url('print/update'); ?>" method="post">
                                    <input type="hidden" name="line1" value="<?= ($Print != null) ? $Print['line1'] : ''; ?>">
                                    <input type="hidden" name="line3" value="<?= ($Print != null) ? $Print['line3'] : ''; ?>">
                                    <td><textarea class="form-control" name="line2" id="line2" cols="70" rows="4"><?= ($Print != null) ? $Print['line2'] : ''; ?></textarea></td>
                                    <td><button class="btn btn-outline-info" type="submit">Ubah</button></td>
                                </form>
                            <?php else : ?>
                                <form action="<?= base_url('print/update'); ?>" method="post">
                                    <input type="hidden" name="line1" value="<?= ($Print != null) ? $Print['line1'] : ''; ?>">
                                    <input type="hidden" name="line3" value="<?= ($Print != null) ? $Print['line3'] : ''; ?>">
                                    <td><textarea class="form-control" name="line2" id="line2" cols="70" rows="4"></textarea></td>
                                    <td><button class="btn btn-outline-primary" type="submit">Simpan</button></td>
                                </form>
                            <?php endif; ?>
                        </tr>
                        <tr>
                            <td>Baris 3</td>
                            <?php if ($Print != null && $Print['line3'] != null) : ?>
                                <form action="<?= base_url('print/update'); ?>" method="post">
                                    <input type="hidden" name="line1" value="<?= ($Print != null) ? $Print['line1'] : ''; ?>">
                                    <input type="hidden" name="line2" value="<?= ($Print != null) ? $Print['line2'] : ''; ?>">
                                    <td><textarea class="form-control" name="line3" id="line3" cols="70" rows="4"><?= ($Print != null) ? $Print['line3'] : ''; ?></textarea></td>
                                    <td><button class="btn btn-outline-info" type="submit">Ubah</button></td>
                                </form>
                            <?php else : ?>
                                <form action="<?= base_url('print/update'); ?>" method="post">
                                    <input type="hidden" name="line1" value="<?= ($Print != null) ? $Print['line1'] : ''; ?>">
                                    <input type="hidden" name="line2" value="<?= ($Print != null) ? $Print['line2'] : ''; ?>">
                                    <td><textarea class="form-control" name="line3" id="line3" cols="70" rows="4"></textarea></td>
                                    <td><button class="btn btn-outline-primary" type="submit">Simpan</button></td>
                                </form>
                            <?php endif; ?>
                        </tr>
                        </form>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="col-3" style="width:100%">
        <div class="widget-content widget-content-area br-6">
            <table cellspacing='0' cellpadding='' style="font-size:12pt; margin-left: 0.5cm; margin-right: 0.5cm;">
                <tr>
                    <td class=""><b><?= session()->get('branch'); ?></b></td>
                </tr>
                <tr>
                    <td style="font-size:9pt"><?= $Branch['branch_address']; ?></td>
                </tr>
            </table>
            <table cellspacing='0' cellpadding='0.5' style="font-size:8pt; margin-left: 0.5cm; margin-right: 0.5cm;text-align: left" width="95%">
                <tr>
                    <?php $prdate = new DateTime(date('Y-m-d H:i'));  ?>
                    <td width='95%'>C1xxxxxxxx/Rafael Valentina Agusta</td>
                </tr>
                <tr>
                    <td><?= date_indo($prdate->format('Y-m-d')); ?>/<?= $prdate->format('H:i'); ?>/TUNAI</td>
                </tr>
            </table>
            <hr>
            <table cellspacing='0' cellpadding='0.5' style="font-size:11pt; margin-left: 0.5cm; margin-right: 0.5cm;text-align: left" width="90%">
                <tr>
                    <td style='vertical-align:top; text-align:left; '>Piano Kantong CS2236</td>
                </tr>
            </table>
            <table cellspacing='0' cellpadding='0.5' style="font-size:10pt; margin-left: 0.5cm; margin-right: 0.5cm;" width="90%">
                <tr>
                    <td width='35%' style='vertical-align:top; text-align:left; '>@ Rp. 55.000</td>
                    <td width='40%' style='text-align:center;'>2pcs</td>
                    <td width='40%' style='vertical-align:top; text-align:right; '>Rp. 110.000</td>
                </tr>
            </table>
            <hr>
            <table cellspacing='0' cellpadding='0.5' style="font-size:10pt; margin-left: 0.5cm; margin-right: 0.5cm;" width="90%">
                <tr>
                    <td width='30%' style='text-align:left; '>Total Diskon</td>
                    <td width='70%' style='text-align:right; '>Rp. 0</td>
                </tr>
                <tr>
                    <td width='35%' style=' font-size:12pt;'>Total Belanja</td>
                    <td width='65%' style='text-align:right;font-size:12pt; '>Rp. 110.000</td>
                </tr>
            </table>
            <hr>
            <table cellspacing='0' cellpadding='0.5' style="font-size:11pt; margin-left: 0.5cm; margin-right: 0.5cm; " width="90%">
                <tr>
                    <td width="50%" style='text-align:left;'>Total Bayar</td>
                    <td width="50%" style='text-align:right; '>Rp. 120.000</td>
                </tr>
                <tr>
                    <td style='text-align:left; font-size:12pt;'>Kembalian</td>
                    <td style='text-align:right;font-size:13pt; '>Rp. 10.000</td>
                </tr>
            </table>
            <hr>
            <table cellspacing='0' cellpadding='0.5' style="font-size:12pt; margin-left: 0.5cm; margin-right: 0.5cm; " width="90%">
                <?php if ($Print != null) : ?>
                    <td>
                        <p class="text-center"><?= ($Print['line1'] != null) ? $Print['line1'] : '..........(Baris1)..........'; ?></p>
                        <p class="text-center"><?= ($Print['line2'] != null) ? $Print['line2'] : '..........(Baris2)..........'; ?></p>
                        <p class="text-center"><?= ($Print['line3'] != null) ? $Print['line3'] : '..........(Baris3)..........';; ?></p>
                    </td>
                <?php else :  ?>
                    <td class="text-center">
                        <p>................(Baris1)...........</p>
                        <p>................(Baris2)...........</p>
                        <p>................(Baris3)...........</p>
                    </td>
                <?php endif; ?>
            </table>
        </div>
    </div>
</div>

<?= $this->endSection(); ?>