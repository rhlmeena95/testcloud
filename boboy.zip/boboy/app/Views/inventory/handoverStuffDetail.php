<?= $this->extend('layouts/main'); ?>
<?= $this->section('content'); ?>

<div class="row layout-top-spacing" id="cancel-row">
    <div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
        <div class="widget-content widget-content-area br-6">
            <div class="row">
                <div class="col-sm-7 text-sm-left">
                    <h3>
                        Detail <strong><?= $title; ?> Cabang <?= session()->get('branch'); ?> </strong>
                    </h3>
                </div>
                <div class="col-sm-5 text-sm-right">
                    <?php $prdate = new DateTime($PurchaseOrders['purchase_order_invoice_date']);  ?>
                    <h5 class="inv-list-number"><span class="inv-title">Nomor Invoice : </span>
                        <span class="inv-number"><b><?= $PurchaseOrders['purchase_order_invoice']; ?></b></span>
                    </h5>
                </div>
            </div>
            <hr>
            <div class="row text-center">
                <div class="col-sm-6 mt-3">
                    <h6 class="inv-created-date"><span class="inv-title">Tanggal Transaksi : </span>
                        <h2 class="inv-date"><b><?= date_indo($prdate->format('Y-m-d')); ?></b></h2>
                    </h6>
                </div>
                <div class="col-sm-6 mt-3 d-inline">
                    <h6 class="inv-created-date"><span class="inv-title">Dibuat Oleh : </span>
                        <h2 class="inv-date"><b><?= $PurchaseOrders['employee_name']; ?></b></h2>
                    </h6>
                </div>
            </div>
            <hr>
            <div class="row text-center">
                <div class="col-xl-12 col-lg-7 col-md-6 col-sm-4 align-self-center">
                    <h6 class="inv-to "> <b> Nama Pemasok :</b></h6>
                </div>
                <div class="col-xl-12 col-lg-7 col-md-6 col-sm-4">
                    <h2 class="text-primary "><b><?= $PurchaseOrders['supplier_company']; ?></b></h2>
                </div>
            </div>
            <div class="table-responsive my-3">
                <table class="table table-bordered">
                    <thead>
                        <tr class="text-center">
                            <th>#</th>
                            <th>Nama Produk</th>
                            <th>Kuantitas</th>
                            <th>Barang Yang Sudah Diterima</th>
                            <th>Input Barang Yang Diterima</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 1;
                        $index = 0;
                        $index1 = 0;
                        $index2 = 0;
                        foreach ($Products as $product) :
                        ?>
                            <tr>
                                <td class="text-center"><?= $i++; ?></td>
                                <td class="text-center"><?= $product['purchase_order_product_name']; ?></td>
                                <td class="text-center"><?= $product['purchase_order_quantity']; ?></td>
                                <td class="text-center"><?= $product["purchase_order_received"]; ?></td>
                                <td>
                                    <form action="<?= base_url('handoverStuff/saveProductReceive'); ?>" method="post">
                                        <input type="hidden" name="index" value="<?= $index++; ?>">
                                        <input type="hidden" name="idPurchaseOrderProduct[<?= $index1++; ?>]" value="<?= $product['purchaseOrderProductID']; ?>">
                                        <div class="input-group mb-4">
                                            <input type="number" class="form-control" name="inputReceiveProduct[<?= $index2++; ?>]" id="inputReceiveProduct" value="<?= $product["purchase_order_received"]; ?>" <?= ($product['purchase_order_quantity'] == $product['purchase_order_received']) ? 'disabled' : ''; ?>>
                                        </div>
                                </td>
                                <td><?php if ($product['purchase_order_quantity'] != $product['purchase_order_received']) : ?>
                                        <input type="hidden" name="purchaseOrderID" value="<?= $product['purchase_order_invoice'] ?>">
                                        <input type="hidden" name="purchaseOrderInvoice" value="<?= $PurchaseOrders['purchase_order_invoice'] ?>">
                                        <input type="hidden" name="productID" value="<?= $product['product_id']; ?>">
                                        <button class="btn btn-primary float-right d-inline" type="submit">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevrons-right">
                                                <polyline points="13 17 18 12 13 7"></polyline>
                                                <polyline points="6 17 11 12 6 7"></polyline>
                                            </svg>
                                            Simpan dan Pindah ke Kartu Stock
                                        </button>
                                        </form>
                                    <?php else : ?>
                                        </form>
                                        <div class="d-inline">
                                            <button type="button" class="btn btn-success btn-sm" disabled> Dipindahkan </button>
                                            <button class="btn btn-primary btn-sm" data-toggle="modal" id="Print" data-target="#ModalPrint<?= $product['purchaseOrderProductID']; ?>">Cetak/Print Barcode</button>
                                        </div>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <!-- Modal Print -->
                            <div class="modal fade" id="ModalPrint<?= $product['purchaseOrderProductID']; ?>" tabindex="-1" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true">
                                <div class="modal-dialog modal-sm" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title">Input Jumlah Print</h5>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <div class="modal-body">
                                            <form action="<?= base_url('handoverStuff/print'); ?>" method="get">
                                                <input type="hidden" name="purchaseOrderProductID" id="purchaseOrderProductID" value="<?= $product['purchaseOrderProductID']; ?>">
                                                <input type="hidden" name="purchaseOrderID" id="purchaseOrderID" value="<?= $PurchaseOrders['purchaseOrderID']; ?>">
                                                <label for="total">Jumlah Yang akan di print</label>
                                                <input type="number" min="0" placeholder="0" class="form-control " name="total" id="total" required>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="submit" class="btn btn-primary">Simpan</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <div class="text-right">
                    <?php if ($PurchaseOrders['purchase_order_status'] != 1) : ?>
                        <form action="<?= base_url('purchaseOrder/updateStatusPurchaseOrder'); ?>" method="post" class="d-inline">
                            <input type="hidden" name="inputPurchaseOrderStatus" value="1">
                            <input type="hidden" name="idPurchaseOrder" value="<?= $PurchaseOrders['purchaseOrderID']; ?>">
                            <button type="submit" class="btn btn-primary btn-lg ">Simpan Data</button>
                        </form>
                    <?php endif; ?>
                    <a href="<?= base_url('handoverStuff'); ?>" class="btn btn-light btn-lg ml-2 ">Kembali</a>
                </div>
            </div>
        </div>
    </div>
</div>


<?= $this->endSection(); ?>