<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Point of Sale Toko Mainan Boboy">
    <meta name="author" content="Codavlo Indonesia">
    <link rel="icon" type="image/x-icon" href="<?= base_url('assets/img/logotoko1.jpeg') ?>" />
    <title>Nota Kasir | Toko Mainan Boboy</title>
    <script src="<?= base_url('assets/js/libs/jquery-3.6.0.js') ?>"></script>
    <style>
        hr {
            display: block;
            margin-top: 0.2em;
            margin-bottom: 0.2em;
            margin-left: 0.25em;
            margin-right: 0.25em;
            border-style: inset;
            border-width: 1px;
        }

        @media print {
            body * {
                visibility: hidden;
            }

            #section-to-print,
            #section-to-print * {
                visibility: visible;
            }

            #section-to-print {
                position: absolute;
                left: 0;
                top: 0;
            }
        }

        .text-center {
            margin-left: 7.5%;
            margin-top: 0.5%;
        }
    </style>
</head>

<body onload="window.print()">
    <div style="width:8cm ;" id="section-to-print">
        <table cellspacing='0' cellpadding='0.5' style="font-size:12pt; margin-left: 0.25cm; margin-right: 0.25cm;" width="95%">
            <tr>
                <td class="text-center"><b><?= session()->get('branch'); ?></b></td>
            </tr>
            <tr>
                <td style="font-size:8pt"><?= $Branch['branch_address']; ?></td>
            </tr>
        </table>
        <table cellspacing='0' cellpadding='0.5' style="font-size:8pt; margin-left: 0.25cm; margin-right: 0.25cm;text-align: left" width="95%">
            <tr>
                <td width='40%' style=' text-align:left; '><?= $Transaction['employee_name']; ?></td>
                <?php $prdate = new DateTime($Transaction['closing_at']);  ?>
                <td width='30%' style=' text-align:center; '>
                    <?= date_indo($prdate->format('Y-m-d')); ?></td>
                <td width='30%' style=' text-align:right; '><?= $prdate->format('H:i:s'); ?></td>
            </tr>
        </table>
        <hr>
        <table cellspacing='0' cellpadding='0.5' style="font-size:9pt; margin-left: 0.25cm; margin-right: 0.25cm;text-align: left" width="95%">
            <tr>
                <td style='vertical-align:top; text-align:left; '>Uang Tunai Pembukaan :</td>
            </tr>
        </table>
        <table cellspacing='0' cellpadding='0.5' style="font-size:8pt; margin-left: 0.25cm; margin-right: 0.25cm;" width="95%">
            <tr>
                <td style='vertical-align:top; text-align:right; '>Rp. <?= number_format($Transaction['opening_cash']); ?></td>
            </tr>
        </table>
        <hr>
        <table cellspacing='0' cellpadding='0.5' style="font-size:9pt; margin-left: 0.25cm; margin-right: 0.25cm;text-align: left" width="95%">
            <tr>
                <td style='vertical-align:top; text-align:left; '>Total Penjualan :</td>
            </tr>
        </table>
        <table cellspacing='0' cellpadding='0.5' style="font-size:8pt; margin-left: 0.25cm; margin-right: 0.25cm;" width="95%">
            <tr>
                <td style='vertical-align:top; text-align:right; '>Rp.<?= number_format($TotalSalesOrder['sales_order_total']); ?></td>
            </tr>
        </table>
        <table cellspacing='0' cellpadding='0.5' style="font-size:9pt; margin-left: 0.25cm; margin-right: 0.25cm;text-align: left" width="95%">
            <tr>
                <td style='vertical-align:top; text-align:left; '>Total Discount :</td>
            </tr>
        </table>
        <table cellspacing='0' cellpadding='0.5' style="font-size:8pt; margin-left: 0.25cm; margin-right: 0.25cm;" width="95%">
            <tr>
                <td style='vertical-align:top; text-align:right; '>Rp. <?= number_format($TotalSalesOrder['sales_order_discount']); ?></td>
            </tr>
        </table>
        <table cellspacing='0' cellpadding='0.5' style="font-size:9pt; margin-left: 0.25cm; margin-right: 0.25cm;text-align: left" width="95%">
            <tr>
                <td style='vertical-align:top; text-align:left; '>Grand Total Transaksi :</td>
            </tr>
        </table>
        <table cellspacing='0' cellpadding='0.5' style="font-size:8pt; margin-left: 0.25cm; margin-right: 0.25cm;" width="95%">
            <tr>
                <td style='vertical-align:top; text-align:right; '>Rp. <?= number_format($TotalSalesOrder['sales_order_total'] - $TotalSalesOrder['sales_order_discount']); ?></td>
            </tr>
        </table>
        <hr>
        <table cellspacing='0' cellpadding='0.5' style="font-size:9pt; margin-left: 0.25cm; margin-right: 0.25cm;text-align: left" width="95%">
            <tr>
                <td style='vertical-align:top; text-align:left; '>Pembayaran Kartu :</td>
            </tr>
        </table>
        <table cellspacing='0' cellpadding='0.5' style="font-size:8pt; margin-left: 0.25cm; margin-right: 0.25cm;" width="95%">
            <tr>
                <td style='vertical-align:top; text-align:right; '>Rp. <?= number_format($TotalCardPayment); ?></td>
            </tr>
        </table>
        <hr>
        <table cellspacing='0' cellpadding='0.5' style="font-size:9pt; margin-left: 0.25cm; margin-right: 0.25cm;text-align: left" width="95%">
            <tr>
                <td style='vertical-align:top; text-align:left; '>Pembayaran Tunai :</td>
            </tr>
        </table>
        <table cellspacing='0' cellpadding='0.5' style="font-size:8pt; margin-left: 0.25cm; margin-right: 0.25cm;" width="95%">
            <tr>
                <td style='vertical-align:top; text-align:right; '>Rp. <?= number_format($TotalCashPayment - $TotalCardPayment); ?></td>
            </tr>
        </table>
        <table cellspacing='0' cellpadding='0.5' style="font-size:9pt; margin-left: 0.25cm; margin-right: 0.25cm;text-align: left" width="95%">
            <tr>
                <td style='vertical-align:top; text-align:left; '>Pembatalan Transaksi :</td>
            </tr>
        </table>
        <table cellspacing='0' cellpadding='0.5' style="font-size:8pt; margin-left: 0.25cm; margin-right: 0.25cm;" width="95%">
            <tr>
                <td style='vertical-align:top; text-align:right; '>Rp. <?= number_format(($TotalVoid) ? ($TotalVoid['sales_order_total'] - $TotalVoid['sales_order_discount']) : '0'); ?></td>
            </tr>
        </table>
        <hr>
        <table cellspacing='0' cellpadding='0.5' style="font-size:9pt; margin-left: 0.25cm; margin-right: 0.25cm;text-align: left" width="95%">
            <tr>
                <td style='vertical-align:top; text-align:left; '>Uang Tunai Penutupan :</td>
            </tr>
        </table>
        <table cellspacing='0' cellpadding='0.5' style="font-size:8pt; margin-left: 0.25cm; margin-right: 0.25cm;" width="95%">
            <tr>
                <td style='vertical-align:top; text-align:right; '>Rp. <?= number_format($Transaction['closing_cash']) ?></td>
            </tr>
        </table>
        <table cellspacing='0' cellpadding='0.5' style="font-size:9pt; margin-left: 0.25cm; margin-right: 0.25cm;text-align: left" width="95%">
            <tr>
                <td style='vertical-align:top; text-align:left; '>Selisih :</td>
            </tr>
        </table>
        <table cellspacing='0' cellpadding='0.5' style="font-size:8pt; margin-left: 0.25cm; margin-right: 0.25cm;" width="95%">
            <tr>
                <td style='vertical-align:top; text-align:right; '>Rp. <?= number_format($Transaction['closing_cash']  - (($TotalCashPayment - $TotalCardPayment) + $Transaction['opening_cash'])) ?></td>
            </tr>
        </table>
        <table cellspacing='0' cellpadding='0.5' style="font-size:9pt; margin-left: 0.25cm; margin-right: 0.25cm;text-align: left" width="95%">
            <tr>
                <td style='vertical-align:top; text-align:left; '>Jumlah Barang Terjual :</td>
            </tr>
        </table>
        <table cellspacing='0' cellpadding='0.5' style="font-size:8pt; margin-left: 0.25cm; margin-right: 0.25cm;" width="95%">
            <tr>
                <td style='vertical-align:top; text-align:right; '><?= ($TotalQty['sales_order_quantity'] == 0) ? '0' : $TotalQty['sales_order_quantity'] ?> pcs</td>
            </tr>
        </table>

    </div>
    <div class="text-center">
        <button id="printButton">Cetak Nota</button>
        <button onclick="window.location.href='<?= base_url('cashier/openingCashier'); ?>'">Kembali</button>
    </div>
    <script>
        function pageRedirect() {
            window.location.replace("<?= base_url('cashier/openingCashier'); ?>");
        }
        setTimeout("pageRedirect()", 1000);
    </script>
</body>

</html>