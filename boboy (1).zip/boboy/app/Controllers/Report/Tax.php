<?php

namespace App\Controllers\Report;

use App\Controllers\BaseController;
use App\Models\MasterModel;
use App\Models\SalesModel;

class Tax extends BaseController
{
	function __construct()
	{
		$this->SalesModel = new SalesModel();
		$this->MasterModel = new MasterModel();
	}
	public function index()
	{
		$branch = $this->request->getGet('branch');
		$month = $this->request->getGet('m');
		if ($month && $branch) {
			$tax = $this->SalesModel->getTaxByMonthandBranch($month, $branch);
			$Sales = $this->SalesModel->getSalesOrderByBranchandMonth($branch, $month);
		} elseif ($month) {
			$tax = $this->SalesModel->getTaxByMonth($month);
			$Sales = $this->SalesModel->getSalesTotalByBranchandMonth($month);
		} else {
			$tax = null;
			$Sales = null;
		}
		$data = array_merge($this->data, [
			'category'		=> 'Laporan',
			'title'         => 'Pajak',
			'month'			=> $month,
			'Tax'			=> $tax,
			'Branch'    	=> $this->MasterModel->getBranch(),
			'SalesOrder'	=> $Sales,
			'inputBranch'	=> $branch,
		]);
		return view('report/tax', $data);
	}
}
