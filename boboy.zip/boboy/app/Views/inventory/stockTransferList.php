<?= $this->extend('layouts/main'); ?>
<?= $this->section('content'); ?>
<div class="row layout-top-spacing" id="cancel-row">
	<div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
		<div class="widget-content widget-content-area br-6">
			<?php if (1 == session()->get('branch_id')) : ?>
				<div class="row">
					<div class="col-sm-4"></div>
					<div class="col-sm-8">
						<form action="<?= base_url('stockTransfer'); ?>" method="get">
							<div class="input-group">
								<select class="custom-select" id="branch" name="branch" <?= (1 != session()->get('branch_id')) ? 'disabled' : ''; ?>>
									<option value="">-- Pilih Cabang -- </option>
									<?php foreach ($Branch as $branch) : ?>
										<option value="<?= $branch['branchID']; ?>" <?= ($inputBranch == $branch['branchID']) ? 'selected' : ''; ?>><?= $branch['branch_name']; ?></option>
									<?php endforeach; ?>
								</select>
								<div class="input-group-append">
									<button class="btn btn-primary" type="submit" <?= (1 ==  session()->get('branch_id')) ? 'disable' : ''; ?>>Lihat Data</button>
									<a href="<?= base_url('stockTransfer/create'); ?>" type="button" class="btn btn-outline-primary">
										<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-plus-square">
											<rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
											<line x1="12" y1="8" x2="12" y2="16"></line>
											<line x1="8" y1="12" x2="16" y2="12"></line>
										</svg>
										Buat Pengiriman Stok Baru
									</a>
								</div>
							</div>
						</form>
					</div>
				</div>
			<?php else : ?>
				<input type="hidden" name="branch" value="<?= session()->get('branch_id'); ?>">
				<div class="text-right">
					<a href="<?= base_url('stockTransfer/create'); ?>" type="button" class="btn btn-outline-primary">
						<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-plus-square">
							<rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
							<line x1="12" y1="8" x2="12" y2="16"></line>
							<line x1="8" y1="12" x2="16" y2="12"></line>
						</svg>
						Buat Pengiriman Stok Baru
					</a>
				</div>
			<?php endif; ?>
			<div class="table-responsive">
				<table class="table table-striped dataTable" style="width:100%">
					<thead>
						<tr class="text-center">
							<th>#</th>
							<th>Tanggal</th>
							<th>Cabang pengirim</th>
							<th>Tujuan Pengiriman</th>
							<th>Status</th>
							<th class="no-content">Aksi</th>
						</tr>
					</thead>
					<tbody>
						<?php $no = 1;
						foreach ($StockTransfer as $stockTransfer) :
						?>
							<tr class="text-center">
								<td><?= $no++ ?> </td>
								<td> <?php $prdate = new DateTime($stockTransfer['request_at']);
										echo date_indo($prdate->format('Y-m-d')) . ', ' . $prdate->format('H:i');  ?></td>
								<?php if ($inputBranch != null) : ?>
									<td><?php foreach ($Branch as $branch) : ?>
											<?= ($inputBranch == $branch['branchID']) ? $branch['branch_name'] : ''; ?>
										<?php endforeach; ?></td>
								<?php else : ?>
									<td><?= session()->get('branch'); ?></td>
								<?php endif; ?>
								<td><?= $stockTransfer['branch_name'] ?> </td>
								<td class="text-center">
									<?php if ($stockTransfer['status'] == 1) { ?>
										<span class="badge badge-warning"> DIKIRIM </span>
									<?php } else if ($stockTransfer['status'] == 2) { ?>
										<span class="badge badge-success"> DITERIMA </span>
									<?php } ?>
								</td>
								<td>
									<a class="btn btn-primary" href="<?= base_url('stockTransfer/detail?id=' . $stockTransfer['stockTransferID']); ?> ">
										<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-zoom-in">
											<circle cx="11" cy="11" r="8"></circle>
											<line x1="21" y1="21" x2="16.65" y2="16.65"></line>
											<line x1="11" y1="8" x2="11" y2="14"></line>
											<line x1="8" y1="11" x2="14" y2="11"></line>
										</svg>
										Detail
									</a>
									<a href="<?= base_url('stockTransfer/print?id=' . $stockTransfer['stockTransferID']); ?> " class="btn btn-outline-success text-dark ">
										<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-printer text-success">
											<polyline points="6 9 6 2 18 2 18 9"></polyline>
											<path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"></path>
											<rect x="6" y="14" width="12" height="8"></rect>
										</svg> Print Surat Jalan
									</a>
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
<?= $this->endSection(); ?>