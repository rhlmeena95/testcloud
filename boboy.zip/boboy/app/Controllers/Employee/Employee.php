<?php

namespace App\Controllers\Employee;

use App\Controllers\BaseController;
use App\Models\EmployeeModel;
use App\Models\MasterModel;
use App\Models\UserModel;

class Employee extends BaseController
{
	function __construct()
	{
		$this->EmployeeModel = new EmployeeModel();
		$this->MasterModel 	 = new MasterModel();
		$this->userModel	 = new UserModel();
	}
	public function index()
	{
		$branch = $this->request->getVar('branch');
		$month = $this->request->getGet('m');
		if ($branch != null) {
			$attandance = $this->EmployeeModel->getAttendance($branch, $month);
		} else {
			$attandance = $this->EmployeeModel->getAttandanceByMonth($month);
		}
		$data = array_merge($this->data, [
			'category'		=> 'Karyawan',
			'title'         => 'Data Karyawan',
			'Attendance'	=> $attandance,
			'inputBranch'	=> $branch,
			'Branch'    	=> $this->MasterModel->getBranch(),
			'month'			=> $month,
		]);
		return view('employee/attendanceList', $data);
	}
	public function employee()
	{
		$branch = $this->request->getVar('branch');
		if ($branch != null) {
			$request = $this->EmployeeModel->getEmployeeByBranch($branch);
		} else {
			$request = $this->EmployeeModel->getEmployeeByBranch();
		}
		$data = array_merge($this->data, [
			'category'		=> 'Karyawan',
			'title'         => 'Data Karyawan',
			'Employee'    	=> $request,
			'role'			=> $this->userModel->getUserRole(),
			'Branch'    	=> $this->MasterModel->getBranch(),
			'Province'    	=> $this->MasterModel->getProvince(),
			'inputBranch'	=> $branch,
		]);
		return view('employee/employeeList', $data);
	}
	public function createEmployee()
	{
		$nip = $this->request->getVar('nip');
		if ($nip) {
			$data = array_merge($this->data, [
				'category'		=> 'Karyawan',
				'title'         => 'Update Data Karyawan',
				'Employee'    	=> $this->EmployeeModel->getEmployee($nip),
				'Province'    	=> $this->MasterModel->getProvince(),
				'role'			=> $this->userModel->getUserRole(),
				'Branch'    	=> $this->MasterModel->getBranch(),
			]);
			return view('employee/employeeFormUpdate', $data);
		}
		$data = array_merge($this->data, [
			'category'		=> 'Karyawan',
			'title'         => 'Tambah Data Karyawan',
			'Employee'    	=> $this->EmployeeModel->getEmployee(),
			'Province'    	=> $this->MasterModel->getProvince(),
			'role'			=> $this->userModel->getUserRole(),
			'Branch'    	=> $this->MasterModel->getBranch(),
		]);
		return view('employee/employeeFormCreate', $data);
	}

	public function saveEmployee()
	{
		$createEmployee = $this->EmployeeModel->createEmployee($this->request->getPost(null));
		if ($createEmployee) {
			session()->setFlashdata('notif_success', '<b>Berhasil menambah data Pegawai, Segera lakukan pergantian Password</b>');
			return redirect()->to(base_url('users'));
		} else {
			session()->setFlashdata('notif_error', '<b>Failed to add new Employee</b>');
			return redirect()->to(base_url('users'));
		}
	}
	public function updateEmployee()
	{
		$updateEmployee = $this->EmployeeModel->updateEmployee($this->request->getPost(null));
		if ($updateEmployee) {
			session()->setFlashdata('notif_success', '<b>Berhasil Update Data Pegawai</b>');
			return redirect()->to(base_url('users'));
		} else {
			session()->setFlashdata('notif_error', '<b>Gagal Update Data Pegawai</b>');
			return redirect()->to(base_url('users'));
		}
	}
	public function deleteEmployee()
	{
		$deleteEmployee = $this->EmployeeModel->deleteEmployee($this->request->getPost('employeeID'));
		if ($deleteEmployee) {
			session()->setFlashdata('notif_success', '<b>Berhasil Menghapus Data Pegawai</b>');
			return redirect()->to(base_url('employee'));
		} else {
			session()->setFlashdata('notif_error', '<b>Gagal Menghapus Data Pegawai</b>');
			return redirect()->to(base_url('employee'));
		}
	}
	// public function attendanceManage()
	// {
	// 	$month = $this->request->getGet('m');
	// 	$years = $this->request->getGet('y');

	// 	$data = array_merge($this->data, [
	// 		'category'		=> 'Karyawan',
	// 		'title'         => 'Detail Absensi',
	// 		'Employee'    	=> $this->EmployeeModel->getEmployee($this->request->getGet('id')),
	// 		'Attandance'	=> $this->EmployeeModel->getAttandance($this->request->getGet('id')),
	// 		'month'			=> $month,
	// 		'years'			=> $years
	// 	]);
	// 	// dd($data);
	// 	return view('employee/attandanceManagement', $data);
	// }
	// public function shifting()
	// {
	// 	$month = $this->request->getGet('m');
	// 	$employee = $this->request->getGet('e');
	// 	$shiftEmployee = $this->EmployeeModel->getShiftEmployee($employee, $month);
	// 	if ($month && $employee) {
	// 		$shift = $shiftEmployee;
	// 	} else {
	// 		$shift = null;
	// 	}
	// 	// dd($month);
	// 	$data = array_merge($this->data, [
	// 		'category'				=> 'Karyawan',
	// 		'title'         		=> 'Shifting',
	// 		'EmployeeShifting'		=> $shift,
	// 		'Shifting'				=> $this->EmployeeModel->getShifting(),
	// 		'Employee'    			=> $this->EmployeeModel->getEmployeeByBranch(session()->get('branch_id')),
	// 		'month'					=> $month,
	// 		'emp'					=> $employee

	// 	]);
	// 	return view('employee/shifting', $data);
	// }
	// public function createShift()
	// {
	// 	$createShift = $this->EmployeeModel->createShift($this->request->getPost(null));
	// 	if ($createShift) {
	// 		session()->setFlashdata('notif_success', '<b>Berhasil Menambah Shift</b>');
	// 		return redirect()->to(base_url('shifting/createManagementShift'));
	// 	} else {
	// 		session()->setFlashdata('notif_error', '<b>Gagal Menambah Shift</b>');
	// 		return redirect()->to(base_url('shifting/createManagementShift'));
	// 	}
	// }
	// public function updateShift()
	// {
	// 	$updateShift = $this->EmployeeModel->updateShift($this->request->getPost(null));
	// 	if ($updateShift) {
	// 		session()->setFlashdata('notif_success', '<b>Berhasil Mengubah Shift</b>');
	// 		return redirect()->to(base_url('shifting/createManagementShift'));
	// 	} else {
	// 		session()->setFlashdata('notif_error', '<b>Gagal Mengubah Shift</b>');
	// 		return redirect()->to(base_url('shifting/createManagementShift'));
	// 	}
	// }
	// public function createManagementShift()
	// {
	// 	$data = array_merge($this->data, [
	// 		'category'		=> 'Karyawan',
	// 		'title'         => 'Shifting Manajemen',
	// 		'Shifting'		=> $this->EmployeeModel->getShifting(),
	// 		'Employee'    	=> $this->EmployeeModel->getEmployeeByBranch(session()->get('branch_id')),
	// 	]);
	// 	return view('employee/shiftingManagement', $data);
	// }
	// public function saveManagementShift()
	// {
	// 	// dd($this->request->getPost('inputEmployeeShift'));
	// 	$Shift        	= $this->request->getPost('inputEmployeeShift');
	// 	$Nip          	= $this->request->getPost('inputEmployee');
	// 	$Date        	= $this->request->getPost('inputDateShift');
	// 	$ShiftManage    = [];
	// 	$index = 0;
	// 	foreach ($Shift as $dataShift) {
	// 		array_push($ShiftManage, ([
	// 			'inputEmployeeShift'    => $Shift[$index],
	// 			'inputEmployee'         => $Nip[$index],
	// 			'inputDateShift'        => $Date[$index],
	// 		]));
	// 		$index++;
	// 	}
	// 	// dd($ShiftManage);
	// 	$createShiftManagement = $this->EmployeeModel->createShiftManagement($ShiftManage);
	// 	if ($createShiftManagement) {
	// 		session()->setFlashdata('notif_success', '<b>Berhasil Menambah Shift Karyawan</b>');
	// 		return redirect()->to(base_url('shifting'));
	// 	} else {
	// 		session()->setFlashdata('notif_error', '<b>Gagal Menambah Shift Karyawan</b>');
	// 		return redirect()->to(base_url('shifting'));
	// 	}
	// }
	// public function updateManagementShift()
	// {
	// 	$updateShiftManagement = $this->EmployeeModel->updateShiftManagement($this->request->getPost(null));
	// 	if ($updateShiftManagement) {
	// 		session()->setFlashdata('notif_success', '<b>Berhasil Mengubah Shift Karyawan</b>');
	// 		return redirect()->to(base_url('shifting'));
	// 	} else {
	// 		session()->setFlashdata('notif_error', '<b>Gagal Mengubah Shift Karyawan</b>');
	// 		return redirect()->to(base_url('shifting'));
	// 	}
	// }
	// public function deleteManagementShift()
	// {
	// 	$deleteShiftManagement = $this->EmployeeModel->deleteShiftManagement($this->request->getPost('shiftManagementID'));
	// 	if ($deleteShiftManagement) {
	// 		session()->setFlashdata('notif_success', '<b>Berhasil Mengubah Shift Karyawan</b>');
	// 		return redirect()->to(base_url('shifting'));
	// 	} else {
	// 		session()->setFlashdata('notif_error', '<b>Gagal Mengubah Shift Karyawan</b>');
	// 		return redirect()->to(base_url('shifting'));
	// 	}
	// }
}
