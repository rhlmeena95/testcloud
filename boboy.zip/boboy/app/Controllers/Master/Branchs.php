<?php

namespace App\Controllers\Master;

use App\Controllers\BaseController;
use App\Models\EmployeeModel;
use App\Models\MasterModel;

class Branchs extends BaseController
{
	function __construct()
	{
		$this->MasterModel = new MasterModel();
		$this->EmployeeModel = new EmployeeModel();
	}
	public function index()
	{
		$data = array_merge($this->data, [
			'category'		=> 'Master',
			'title'         => 'Halaman Data Cabang',
			'Employee'		=> $this->EmployeeModel->getEmployee(),
			'Branch'    	=> $this->MasterModel->getBranch(),
			'Province'    	=> $this->MasterModel->getProvince(),
			'City'    		=> $this->MasterModel->getCity(),
			'Subdistrict'   => $this->MasterModel->getSubdistrict(),
		]);
		return view('master/branchList', $data);
	}
	public function createBranch()
	{

		$createBranch = $this->MasterModel->createBranch($this->request->getPost(null));
		if ($createBranch) {
			session()->setFlashdata('notif_success', '<b>Berhasil membuat data Cabang baru</b>');
			return redirect()->to(base_url('branch'));
		} else {
			session()->setFlashdata('notif_error', '<b>Gagal membuat data cabang</b>');
			return redirect()->to(base_url('branch'));
		}
	}
	public function updateBranch()
	{
		$updateBranch = $this->MasterModel->updateBranch($this->request->getPost(null));
		if ($updateBranch) {
			if ($updateBranch == 'error') {
				session()->setFlashdata('notif_error', '<b>Gagal untuk update data cabang, data provinsi masih kosong</b>');
				return redirect()->to(base_url('branch'));
			}
			session()->setFlashdata('notif_success', '<b>Berhasil update Cabang</b>');
			return redirect()->to(base_url('branch'));
		} else {
			session()->setFlashdata('notif_error', '<b>Gagal untuk update data cabang</b>');
			return redirect()->to(base_url('branch'));
		}
	}
	public function deleteBranch()
	{
		$deleteBranch = $this->MasterModel->deleteBranch($this->request->getPost('branchID'));
		if ($deleteBranch) {
			session()->setFlashdata('notif_success', '<b>Berhasil Hapus data Cabang</b>');
			return redirect()->to(base_url('branch'));
		} else {
			session()->setFlashdata('notif_error', '<b>Gagal hapus data Cabang</b>');
			return redirect()->to(base_url('branch'));
		}
	}
}
