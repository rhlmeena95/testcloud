<?= $this->extend('layouts/main'); ?>
<?= $this->section('content'); ?>

<div class="row layout-top-spacing" id="cancel-row">
	<div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
		<div class="widget-content widget-content-area br-6">
			<h2 class=" my-3"><strong><?= $title; ?></strong> tahun <?= date('Y'); ?></h2>
			<hr>
			<div class="row">
				<div class="col-2">
					<h6> Nama Pegawai : </h6>
					<h6> Jabatan : </h6>
				</div>
				<div class="col-2"><b>
						<h6><b><?= $Employee['employee_name']; ?></b></h6>
						<h6><b><?= $Employee['role_name']; ?></b></h6>
				</div>
			</div>
			<br>
			<table class="table table-striped dataTable" style="width:100%">
				<thead>
					<th>#</th>
					<th>Tanggal</th>
					<th>Jam Masuk</th>
					<th>Jam Keluar</th>
					<th>Shift Kerja</th>
				</thead>
				<tbody>
					<?php
					$i = 1;
					foreach ($Attandance as $attandance) : ?>
						<tr>
							<td><?= $i++; ?></td>
							<td><?= longdate_indo($attandance['attandance_date']); ?></td>
							<td>
								<?php $prdate = new DateTime($attandance['attandance_open']);
								echo $prdate->format('H:i');  ?>
							</td>
							<td>
								<?php $prdate = new DateTime($attandance['attandance_close']);
								echo $prdate->format('H:i');  ?>
							</td>
							<td><?= $attandance['shift_name']; ?></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
	</div>
</div>
<?= $this->endSection(); ?>