<?= $this->extend('layouts/main'); ?>
<?= $this->section('content'); ?>
<div class="row">
    <div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
        <div class="widget-content widget-content-area br-6">
            <div class="card">
                <div class="text-center">
                    <h3 class="my-3">
                        <strong><?= $title; ?></strong>
                    </h3>
                </div>
                <hr>
                <div class="card-body">
                    <form action="<?= base_url('product/createProduct'); ?>" method="post">
                        <div class="form-group">
                            <label for="inputCategory">Kategori Barang</label>
                            <select name="inputCategory" id="inputCategory" class="form-control selectpicker" data-live-search="true" required>
                                <option selected="selected">Pilih Kategori Barang</option>
                                <?php foreach ($ProductSubdepartment as $subdepartment) : ?>
                                    <option value="<?= $subdepartment['product_subdep_code']; ?>"><?= $subdepartment['product_subdep_name']; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="inputName">Nama Barang</label>
                            <input type="text" class="form-control" name="inputName" id="inputName" required>
                        </div>
                        <div class="row">
                            <div class="col-4">
                                <div class="form-group">
                                    <label for="inputPurchasePrice">Harga Beli Barang</label>
                                    <div class="input-group mb-4">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text" id="basic-addon5">Rp</span>
                                        </div>
                                        <input type="number" class="form-control" name="inputPurchasePrice" id="purchaseprice" value="" required>
                                    </div>
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="form-group">
                                    <label for="inputMargin">Margin</label>
                                    <div class="input-group mb-4">
                                        <input type="number" class="form-control" name="inputMargin" id="margin" value="0" required>
                                        <div class="input-group-prepend">
                                            <span class="input-group-text" id="basic-addon5">%</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="form-group">
                                    <label for="inputSellingPrice">Harga Jual Barang</label>
                                    <div class="input-group mb-4">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text" id="basic-addon5">Rp</span>
                                        </div>
                                        <input type="number" class="form-control" name="inputSellingPrice" id="sellingprice" value="" required>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-6">
                                <div class="form-group">
                                    <label for="inputStock">Total Stok</label>
                                    <input type="number" class="form-control" name="inputStock" id="inputStock" required>
                                </div>
                            </div>
                            <!-- <div class="col-6">
                                <div class="form-group">
                                    <label for="inputExpiredAt">Tanggal Expired</label>
                                    <input type="text" class="form-control flatpickr flatpickr-input basicFlatpickr active" name="inputExpiredAt" id="inputExpiredAt" required>
                                </div>
                            </div> -->
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary">Simpan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    $('#margin').keyup(function() {
        let margin = $(this).val();
        let purchasePrice = $('#purchaseprice').val();
        let sellingPrice = parseInt(((margin / 100) * purchasePrice)) + parseInt(purchasePrice);

        $('#sellingprice').val(sellingPrice);
    });
</script>
<?= $this->endSection(); ?>