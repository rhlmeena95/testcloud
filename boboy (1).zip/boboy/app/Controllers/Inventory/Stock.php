<?php

namespace App\Controllers\Inventory;

use App\Models\InventoryModel;
use App\Controllers\BaseController;
use App\Models\MasterModel;
use App\Models\PurchasingModel;
use App\Models\SalesModel;
use DateTime;

class Stock extends BaseController
{
	function __construct()
	{
		$this->InventoryModel 		= new InventoryModel();
		$this->MasterModel 			= new MasterModel();
		$this->PurchasingModel 		= new PurchasingModel();
		$this->SalesModel			= new SalesModel();
	}
	public function initialStock()
	{
		$data = array_merge($this->data, [
			'category'  		=> 'Inventory',
			'title'     		=> 'Stok Awal',
			'InitialStock'    	=> $this->InventoryModel->getInitialStock(),
			'Branch'    		=> $this->MasterModel->getBranch(),
			'Products'  		=> $this->MasterModel->getProducts(),
		]);
		return view('inventory/initialStock', $data);
	}

	public function createInitialStock()
	{
		$initialStockCheck  = $this->InventoryModel->checkInitialStock($this->request->getPost('inputBranch'), $this->request->getPost('inputPeriod'), $this->request->getPost('inputProduct'));

		if ($initialStockCheck > 0) {
			session()->setFlashdata('notif_error', '<b>Gagal menambahkan stok awal, Data Sudah ada! </b>');
			return redirect()->to(base_url('initialStock'));
		}
		$createInitialStock = $this->InventoryModel->createInitialStock($this->request->getPost(null));
		if ($createInitialStock) {
			session()->setFlashdata('notif_success', '<b>Berhasil </b> menambahkan data stok awal');
			return redirect()->to(base_url('initialStock'));
		} else {
			session()->setFlashdata('notif_error', '<b>Gagal</b> Menambahkan data stok awal');
			return redirect()->to(base_url('initialStock'));
		}
	}
	public function deleteInitialStock()
	{
		$deleteInitialStock = $this->InventoryModel->deleteInitialStock($this->request->getPost(null));
		if ($deleteInitialStock) {
			session()->setFlashdata('notif_success', '<b>Berhasil</b> Menghapus data stok awal');
			return redirect()->to(base_url('initialStock'));
		} else {
			session()->setFlashdata('notif_error', '<b>Gagal</b> Menghapus data stok awal');
			return redirect()->to(base_url('initialStock'));
		}
	}

	public function stockCard()
	{
		$branch = $this->request->getVar('branch');
		$product = $this->request->getVar('product');
		$period = date('Y');
		if ($branch != null) {
			$StockCard 		= $this->InventoryModel->getStockCardByBranch($branch, $product);
			if ($product != null) {
				$quantity = $this->InventoryModel->getIntialStockByPeriodProduct($period, $product, $branch);
				if ($quantity == null) {
					$quantity['stock_initial_quantity'] = 0;
				}
				$quantity['stock_initial_quantity'];
				$qty = $quantity;
			} else {
				$quantity['stock_initial_quantity'] = 0;
				$qty = $quantity;
			}
		} else {
			$StockCard 		= $this->InventoryModel->getStockCard($product);
			if ($product != null) {
				$quantity = $this->InventoryModel->getIntialStockByPeriodProduct($period, $product, $branch);
				if ($quantity == null) {
					$quantity['stock_initial_quantity'] = 0;
				}
				$quantity['stock_initial_quantity'];
				$qty = $quantity;
			} else {
				$quantity['stock_initial_quantity'] = 0;
				$qty = $quantity;
			}
		}
		$data = array_merge($this->data, [
			'category'  	=> 'Inventory',
			'title'         => 'Kartu Stok',
			'StockCard'		=> $StockCard,
			// 'Stock'			=> $this->InventoryModel->getOutComeProduct($product, $branch),
			'Product'		=> $this->SalesModel->getProductStockCard(),
			'InitialStock'	=> $qty,
			'Branch'    	=> $this->MasterModel->getBranch(),
			'inputProduct'	=> $product,
			'inputBranch'	=> $branch
		]);
		return view('inventory/stockCard', $data);
	}

	public function stockTransfer()
	{
		$branch = $this->request->getGet('branch');
		if ($branch) {
			$sender = $this->InventoryModel->getStockTransferByBranchOrigin($branch);
			$destination = $this->InventoryModel->getStockTransferByBranchDestination($branch);
		} else {
			$sender = $this->InventoryModel->getStockTransferByBranchOrigin();
			$destination = $this->InventoryModel->getStockTransferByBranchDestination();
		}

		$data = array_merge($this->data, [
			'category'  				=> 'Inventory',
			'title'         			=> 'Stok Transfer',
			'StockTransfer' 			=> $sender,
			'StockTransferDestination'	=> $destination,
			'Branch'    				=> $this->MasterModel->getBranch(),
			'inputBranch'				=> $branch
		]);
		return view('inventory/stockTransferList', $data);
	}
	public function createStockTransfer()
	{
		$data = array_merge($this->data, [
			'category'  		=> 'Inventory',
			'title'         	=> 'Stok Transfer',
			'StockTransfer' 	=> $this->InventoryModel->getStockTransfer(),
			'Branch'    		=> $this->MasterModel->getBranch(),
			'Products'			=> $this->MasterModel->getProducts(),
		]);
		return view('inventory/stockTransferForm', $data);
	}
	public function saveStockTransfer()
	{
		$saveStockTransfer = $this->InventoryModel->createStockTransfer($this->request->getPost(null), $this->cart->contents());

		if ($saveStockTransfer) {
			session()->setFlashdata('notif_success', '<b>Data Transfer Barang berhasil disimpan</b>');
			$this->cart->destroy();
			$data = array_merge($this->data, [
				'StockTransfer'				=> $this->InventoryModel->getStockTransfer($saveStockTransfer),
				'StockTransferProducts'		=> $this->InventoryModel->getStockTransferProduct($saveStockTransfer),
				'Branch'    				=> $this->MasterModel->getBranchbyBranch(),
			]);
			return view('inventory/printHandoverStuff', $data);
		} else {
			session()->setFlashdata('notif_error', '<b>Gagal menyimpan data Transfer Barang</b>');
			return redirect()->to(base_url('stockTransfer/create'));
		}
	}
	public function detailStockTransfer()
	{
		$data = array_merge($this->data, [
			'category'  				=> 'Inventory',
			'title'         			=> 'Stok Transfer',
			'StockTransfer' 			=> $this->InventoryModel->getStockTransfer($this->request->getGet('id')),
			'Branch'    				=> $this->MasterModel->getBranch(),
			'StockTransferProducts'		=> $this->InventoryModel->getStockTransferProduct($this->request->getGet('id')),
		]);
		return view('inventory/stockTransferDetail', $data);
	}
	public function printStockTransferLetter()
	{
		$data = array_merge($this->data, [
			'StockTransfer'				=> $this->InventoryModel->getStockTransfer($this->request->getGet('id')),
			'StockTransferProducts'		=> $this->InventoryModel->getStockTransferProduct($this->request->getGet('id')),
			'Branch'    				=> $this->MasterModel->getBranchbyBranch(),
		]);
		return view('inventory/printHandoverStuff', $data);
	}
	public function requestStockTransfer()
	{
		$branch = $this->request->getVar('branch');
		if ($branch) {
			$request = $this->InventoryModel->getStockTransferByBranchDestination($branch);
		} else {
			$request = $this->InventoryModel->getStockTransferByBranchDestination();
		}
		$data = array_merge($this->data, [
			'category'  		=> 'Inventory',
			'title'         	=> 'Permintaan Barang Stock Transfer',
			'StockTransfer' 	=> $request,
			'Branch'    		=> $this->MasterModel->getBranch(),
			'inputBranch'		=> $branch
		]);
		return view('inventory/stockTranferConfimList', $data);
	}
	public function confirmStockTransfer()
	{
		$data = array_merge($this->data, [
			'category'  				=> 'Inventory',
			'title'         			=> 'Permintaan Barang Stock Transfer',
			'StockTransfer' 			=> $this->InventoryModel->getStockTransferRequest($this->request->getGet('id')),
			'Branch'    				=> $this->MasterModel->getBranch(),
			'StockTransferProducts'		=> $this->InventoryModel->getStockTransferProduct($this->request->getGet('id')),
		]);
		return view('inventory/stockTransferConfirmation', $data);
	}
	public function saveConfimation()
	{

		$updateStockTransferstatus = $this->InventoryModel->updateStatusStockTransferConfirm($this->request->getPost('inputStockTransferStatus'), $this->request->getPost('stockTransferID'));
		if ($updateStockTransferstatus) {
			session()->setFlashdata('notif_success', '<b>Berhasil Mengkonfirmasi Transfer Stok</b>');
			return redirect()->to(base_url('requestStuff'));
		} else {
			session()->setFlashdata('notif_error', '<b>Gagal Mengkonfirmasi Transfer Stok</b>');
			return redirect()->to(base_url('requestStuff/confirm?id=' . $this->request->getPost('stockTransferID')));
		}
	}
	public function receiveStockTransfer()
	{
		$branch = $this->request->getGet('branch');
		if ($branch != null) {
			$request = $this->InventoryModel->getStockTransferByBranchDestination($branch);
		} else {
			$request = $this->InventoryModel->getStockTransferByBranchDestination();
		}
		$data = array_merge($this->data, [
			'category'  				=> 'Inventory',
			'title'         			=> 'Serah Terima Stock Transfer',
			'StockTransfer' 			=> $request,
			'Branch'    				=> $this->MasterModel->getBranch(),
			'inputBranch'				=> $branch
		]);
		return view('inventory/stockTransferHandoverList', $data);
	}
	public function receiveProductStockTransfer()
	{
		$data = array_merge($this->data, [
			'category'  				=> 'Inventory',
			'title'         			=> 'Serah Terima Stock Transfer',
			'StockTransfer' 			=> $this->InventoryModel->getStockTransferRequest($this->request->getGet('id')),
			'StockTransferProducts'		=> $this->InventoryModel->getStockTransferProduct($this->request->getGet('id')),
			'Branch'    				=> $this->MasterModel->getBranch(),
		]);
		return view('inventory/stockTransferHandoverStuff', $data);
	}

	public function saveStockTransferHandoverStuff()
	{
		$StockTransfer           	= $this->request->getPost('stockTransferID');
		$StockTransferProduct       = $this->request->getPost('idstockTransferProduct');
		$ProductReceive				= $this->request->getPost('inputReceiveProduct');
		$dataStockTransferProduct 	= $this->InventoryModel->getStockTransferProductbyProduct($StockTransferProduct);
		$dataStockTransfer 			= $this->InventoryModel->getStockTransfer($StockTransfer);
		if ($ProductReceive != 0) {
			$updateStockTransfer = $this->InventoryModel->updateStatusStockTransferReq($dataStockTransferProduct, $dataStockTransfer, $ProductReceive);
			if ($updateStockTransfer === 'Kosong') {
				session()->setFlashdata('notif_error', '<b>Gagal menyimpan data Transfer Barang. Harus membuat surat jalan baru</b>');
				return redirect()->to(base_url('stockTransferHandoverStuff/confirm?id=' . $StockTransfer));
			} else if ($updateStockTransfer === true) {
				session()->setFlashdata('notif_success', '<b>Data Transfer Barang berhasil disimpan dan dikirmkan ke kartu stok</b>');
				return redirect()->to(base_url('stockTransferHandoverStuff/confirm?id=' . $StockTransfer));
			} else {
				session()->setFlashdata('notif_error', '<b>Gagal menyimpan data Transfer Barang dan dikirmkan ke kartu stok</b>');
				return redirect()->to(base_url('stockTransferHandoverStuff/confirm?id=' . $StockTransfer));
			}
		} else {
			session()->setFlashdata('notif_error', '<b>Mohon isikan data barang yang telah diterima</b>');
			return redirect()->to(base_url('stockTransferHandoverStuff/confirm?id=' . $StockTransfer));
		}
	}
	public function updateStatusStockTransfer()
	{
		$StockTransferID           	= $this->request->getPost('stockTransferID');
		$StockTransferStatus		= $this->request->getPost('inputStockTransferStatus');
		$updateStockTransfer 		= $this->InventoryModel->updateStatusStockTransfer($StockTransferID, $StockTransferStatus);
		if ($updateStockTransfer) {
			session()->setFlashdata('notif_success', '<b>Data Transfer Barang berhasil disetujui</b>');
			return redirect()->to(base_url('stockTransferHandoverStuff'));
		} else {
			session()->setFlashdata('notif_error', '<b>Gagal menyetujui Transfer Barang</b>');
			return redirect()->to(base_url('stockTransferHandoverStuff/confirm?id=' . $StockTransferID));
		}
	}
	public function stockOpname()
	{
		$branch = $this->request->getVar('branch');
		$subdepartment = $this->request->getVar('sd');
		if ($branch && $subdepartment) {
			$stockOpname = $this->InventoryModel->getStockProductByBranchandSubdepartment($branch, $subdepartment);
		} else {
			$stockOpname = $this->InventoryModel->getStockProductByBranchandSubdepartment();
		}
		$data = array_merge($this->data, [
			'category'  			=> 'Inventory',
			'title'         		=> 'Stock Opname',
			'Branch'				=> $this->MasterModel->getBranch(),
			'Subdepartment'			=> $this->MasterModel->getProductSubdepartment(),
			'inputSubdepartment'	=> $subdepartment,
			'StockProduct'			=> $stockOpname,
			'inputBranch'			=> $branch,
		]);
		return view('inventory/stockOpname', $data);
	}
	public function saveStockOpname()
	{
		$product = $this->InventoryModel->checkStockProductStock($this->request->getPost('productId'));
		$saveStockOpname = $this->InventoryModel->saveStockOpname($this->request->getPost(null), $product);
		if ($saveStockOpname) {
			session()->setFlashdata('notif_success', '<b>Data stock Opname berhasil disimpan</b>');
			return redirect()->to(base_url('stockOpname'));
		} else {
			session()->setFlashdata('notif_error', '<b>Gagal menyimpan Data stock Opname</b>');
			return redirect()->to(base_url('stockOpname'));
		}
	}
	public function historyStockOpname()
	{
		$data = array_merge($this->data, [
			'category'  		=> 'Inventory',
			'title'         	=> 'Stock Opname',
			'StockOpname'		=> $this->InventoryModel->getStockOpname(),
		]);
		return view('inventory/stockOpnameHistory', $data);
	}
	public function getTableStockOpname()
	{
		$stockOpname = $this->InventoryModel->getLastUpdateStockOpname($this->request->getVar('product_id'));
		$output = '';
		$i     = 0;
		foreach ($stockOpname as $SO) {
			$prdate = new DateTime($SO['stock_opname_updated_at']);
			$i++;
			$isChange = ($SO['stock_opname_is_change'] == 1) ? 'Ya' : 'Tidak';
			$output .= '
			<tr>
			<td>' . $i . '</td>
			<td>' . $SO['stock_opname_product_name'] . '</td>
			<td>' . $SO['stock_opname_qty_display'] . '</td>
			<td>' . $SO['stock_opname_qty_storage'] . '</td>
			<td>' . $SO['stock_opname_difference'] . '</td>
			<td>' . $isChange . ' </td>
			<td>' . $SO['stock_opname_description'] . '</td>
			<td>' . $prdate->format('d F Y') . '</td>
			<tr>';
		}
		return $output;
	}
}
