<?= $this->extend('layouts/main'); ?>
<?= $this->section('content'); ?>
<div class="row layout-top-spacing" id="cancel-row">
    <div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
        <div class="widget-content widget-content-area ">
            <div class="row">
                <div class="col-sm-6 mb-3">
                    <?php if (session()->get('branch_id') != 1) : ?>
                        <h5>Absensi Karyawan cabang <?= session()->get('branch'); ?></h5>
                    <?php endif; ?>
                </div>
                <div class="col-sm-6 mb-3">
                    <form action="<?= base_url('employee'); ?>" method="get">
                        <div class="input-group">
                            <?php if (session()->get('branch_id') == 1) : ?>
                                <select class="custom-select" id="branch" name="branch" <?= (1 != session()->get('branch_id')) ? 'disabled' : ''; ?>>
                                    <option value="">-- Pilih Cabang -- </option>
                                    <?php foreach ($Branch as $branch) : ?>
                                        <option value="<?= $branch['branchID']; ?>" <?= ($inputBranch == $branch['branchID']) ? 'selected' : ''; ?>><?= $branch['branch_name']; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            <?php endif; ?>
                            <select class="custom-select" id="month" name="m" aria-label="Example select with button addon" required>
                                <option value="">-- Pilih Bulan --</option>
                                <?php
                                for ($i = 1; $i <= 12; $i++) : ?>
                                    <option value="<?= $i; ?>" <?= ($month) ? ($i == $month) ? 'selected' : '' : ''; ?>><?= bulan($i); ?> </option>
                                <?php endfor; ?>
                            </select>
                            <div class="input-group-append">
                                <button class="btn btn-primary" type="submit">Lihat Data</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <div class="table-responsive">
                <table class="table table-striped dataTable" style="width:100%">
                    <thead>
                        <th>#</th>
                        <th>Nama </th>
                        <th>Waktu Buka</th>
                        <th>Waktu Tutup</th>
                    </thead>
                    <tbody>
                        <?php $i = 1;
                        foreach ($Attendance as $attendance) : ?>
                            <tr>
                                <td><?= $i++; ?> </td>
                                <td><?= $attendance['fullname'] ?> </td>
                                <?php $prdate = new DateTime($attendance['opening_at']);  ?>
                                <?php $prtime = new DateTime($attendance['closing_at']);  ?>
                                <td><?= date_indo($prdate->format('Y-m-d')); ?>, <?= $prdate->format('H:i'); ?> </td>
                                <td><?= ($prtime->format('Y-m-d') == '-0001-11-30') ? 'Transaksi belum di tutup' : date_indo($prtime->format('Y-m-d')); ?>, <?= $prtime->format('H:i'); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection(); ?>