<?= $this->extend('layouts/main'); ?>
<?= $this->section('content'); ?>
<div class="row layout-top-spacing" id="cancel-row">
    <div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
        <div class="widget">
            <div class="widget-content">
                <div class="row">
                    <?php if (1 != session()->get('branch_id')) : ?>
                        <div class="col-sm-6">
                            <h5>Laporan Penjualan Cabang <?= session()->get('branch'); ?></h5>
                        </div>
                    <?php endif; ?>
                    <div class="col-sm-6">
                        <form action="<?= base_url('transactionSellingProduct'); ?>" method="get">
                            <div class="input-group">
                                <?php if (1 == session()->get('branch_id')) : ?>
                                    <select class="custom-select" id="branch" name="branch" <?= (1 != session()->get('branch_id')) ? 'disabled' : ''; ?>>
                                        <option value="">-- Pilih Cabang -- </option>
                                        <?php foreach ($Branch as $branch) : ?>
                                            <option value="<?= $branch['branchID']; ?>" <?= ($inputBranch == $branch['branchID']) ? 'selected' : ''; ?>><?= $branch['branch_name']; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                <?php else : ?>
                                    <input type="hidden" name="branch" value="<?= session()->get('branch_id'); ?>">
                                <?php endif; ?>
                                <select class="custom-select" id="month" name="m" required>
                                    <option value="">-- Pilih Bulan --</option>
                                    <?php
                                    for ($i = 1; $i <= 12; $i++) : ?>
                                        <option value="<?= $i; ?>" <?= ($month) ? ($i == $month) ? 'selected' : '' : ''; ?>><?= bulan($i); ?> </option>
                                    <?php endfor; ?>
                                </select>
                                <select class="custom-select" id="years" name="y" required>
                                    <option value="">-- Pilih Tahun --</option>
                                    <?php
                                    $tg_awal = $yearsNow - 2;
                                    $tgl_akhir = $yearsNow + 2;
                                    for ($p = $tg_awal; $p <= $tgl_akhir; $p++) : ?>
                                        <option value="<?= $p; ?>" <?= ($years) ? ($p == $years) ? 'selected' : '' : ''; ?>><?= $p; ?> </option>
                                    <?php endfor; ?>
                                </select>
                                <div class="input-group-append">
                                    <button class="btn btn-primary" type="submit">Lihat Data</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="table-responsive">
                    <table class="table dataTable">
                        <thead>
                            <th>#</th>
                            <th>Tanggal Transaksi</th>
                            <th>Invoice</th>
                            <th class="text-center">SKU</th>
                            <th>Nama Produk</th>
                            <th>Kategori Produk</th>
                            <th class="text-center">Kuantitas</th>
                            <th>Diskon</th>
                            <th>Nama Kasir</th>
                            <th>Total Transaksi</th>
                        </thead>
                        <tbody>
                            <?php
                            if ($SalesOrder) :
                                $i = 1;
                                foreach ($SalesOrder as $salesOrder) :
                            ?>
                                    <tr>
                                        <td><?= $i++; ?></td>
                                        <td>
                                            <?php $prdate = new DateTime($salesOrder['sales_order_created_at']);
                                            echo date_indo($prdate->format('Y-m-d')) . ', ' . $prdate->format('H:i');  ?>
                                        </td>
                                        <td><?= $salesOrder['sales_order_invoices']; ?></td>
                                        <td><?= $salesOrder['product_sku']; ?></td>
                                        <td><?= $salesOrder['sales_order_product_name']; ?></td>
                                        <td><?= $salesOrder['product_subdep_name']; ?></td>
                                        <td class="text-center"><?= $salesOrder['sales_order_quantity']; ?></td>
                                        <td>Rp. <?= number_format($salesOrder['sales_order_product_discount']); ?></td>
                                        <td><?= $salesOrder['employee_name']; ?></td>
                                        <td>Rp. <?= number_format($salesOrder['sales_order_price'] * $salesOrder['sales_order_quantity']); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection(); ?>