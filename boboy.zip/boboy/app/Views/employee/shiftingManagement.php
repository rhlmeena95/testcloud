<?= $this->extend('layouts/main'); ?>
<?= $this->section('content'); ?>

<div class="row layout-top-spacing" id="cancel-row">
    <div class="col-xl-8 col-lg-8 col-sm-8  layout-spacing">
        <div class="widget-content widget-content-area br-6">
            <h1 class="h3 mb-3"><strong><?= $title; ?></strong></h1>
            <div class="card">
                <div class="card-body">
                    <form action="<?= base_url('shifting/saveManagementShift'); ?>" method="post">
                        <div class="table-responsive">
                            <table class="table mb-4" id="EmployeeShift">
                                <thead>
                                    <tr>
                                        <th class="text-center">Nama Pegawai</th>
                                        <th>Shift Karyawan</th>
                                        <th class="">Tanggal</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>
                                            <select class="custom-select" id="employee" name="inputEmployee[]">
                                                <option value="">-- Pilih Karyawan -- </option>
                                                <?php foreach ($Employee as $employee) : ?>
                                                    <option value="<?= $employee['employeeNIP']; ?>"><?= $employee['employee_name']; ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </td>
                                        <td>
                                            <select class="custom-select" id="Shift" name="inputEmployeeShift[]">
                                                <option value="">-- Pilih Shift -- </option>
                                                <?php foreach ($Shifting as $shift) : ?>
                                                    <option value="<?= $shift['id']; ?>"><?= $shift['shift_name']; ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </td>
                                        <td>
                                            <input type="date" class="form-control  active" name="inputDateShift[]" id="Date" required>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <button type="button" class="btn btn-primary float-right" id="btnCreate" onclick="addShiftEmployee()">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-plus-circle">
                                <circle cx="12" cy="12" r="10"></circle>
                                <line x1="12" y1="8" x2="12" y2="16"></line>
                                <line x1="8" y1="12" x2="16" y2="12"></line>
                            </svg>
                            Tambah
                        </button>
                </div>
            </div>
            <div class=" grid-margin">
                <div class="card">
                    <div class="card-body">
                        <div class="text-center">
                            <button type="submit" class="btn btn-primary btn-lg">Simpan</button>
                        </div>
                    </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-4 col-lg-4 col-sm-4  layout-spacing">
        <div class="widget-content widget-content-area br-6">
            <div class="row">
                <div class="col-12">
                    <button data-toggle="modal" data-target="#createShift" class="btn btn-primary float-right">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-plus-circle">
                            <circle cx="12" cy="12" r="10"></circle>
                            <line x1="12" y1="8" x2="12" y2="16"></line>
                            <line x1="8" y1="12" x2="16" y2="12"></line>
                        </svg>
                        Tambah Shift
                    </button>
                </div>
            </div>
            <table class="table table-striped dataTable" style="width:100%">
                <thead class="text-center">
                    <th>#</th>
                    <th>Shift</th>
                    <th>Jam Kerja</th>
                    <th>Aksi</th>
                </thead>
                <tbody>
                    <?php
                    $i = 1;
                    foreach ($Shifting as $shift) : ?>
                        <tr class="text-center">
                            <td><?= $i++; ?></td>
                            <td><?= $shift['shift_name']; ?></td>
                            <td><?= $shift['shift_started']; ?> - <?= $shift['shift_ended']; ?></td>
                            <td>
                                <button data-toggle="modal" data-target="#updateShift<?= $shift['id']; ?>" class="btn btn-primary">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-edit">
                                        <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                                        <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                                    </svg>
                                    Ubah
                                </button>
                            </td>
                        </tr>
                        <div class="modal fade" id="updateShift<?= $shift['id']; ?>" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="updateShiftLabel" aria-hidden="true">
                            <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="updateShiftLabel">Tambah Shift Baru</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                    </div>
                                    <div class="modal-body">
                                        <form action="<?= base_url('shifting/update'); ?>" method="post">

                                            <input type="hidden" name="idShift" id="idShift" value="<?= $shift['id']; ?>">
                                            <div class="form-group row  mb-4">
                                                <label for="shiftName" class="col-sm-2 col-form-label col-form-label-sm">Nama Shift</label>
                                                <div class="col-sm-10">
                                                    <input type="text" class="form-control form-control-sm" id="shiftName" name="shiftName" placeholder="Pagi/Siang/Sore" value="<?= $shift['shift_name']; ?>">
                                                </div>
                                            </div>
                                            <div class="form-group row  mb-4">
                                                <label for="started" class="col-sm-2 col-form-label col-form-label-sm">Jam Kerja</label>
                                                <div class="col-sm-4">
                                                    <input id="workingStarted" name="started" class="form-control flatpickr flatpickr-input" type="time" placeholder="Select Date.." value="<?= $shift['shift_started']; ?>">
                                                </div>
                                                <div class="col-sm-2">
                                                    <label for="ended" class="col-sm-2 col-form-label col-form-label-sm">Selesai Pukul</label>
                                                </div>
                                                <div class="col-sm-4">
                                                    <input id="workingEnded" name="ended" class="form-control flatpickr flatpickr-input " type="time" placeholder="Select Date.." value="<?= $shift['shift_ended']; ?>">
                                                </div>
                                            </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button class="btn btn-primary" type="submit"> Simpan</button>
                                    </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<div class="modal fade" id="createShift" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="createShiftLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="createShiftLabel">Tambah Shift Baru</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
            </div>
            <div class="modal-body">
                <form action="<?= base_url('shifting/create'); ?>" method="post">
                    <div class="form-group row  mb-4">
                        <label for="shiftName" class="col-sm-2 col-form-label col-form-label-sm">Nama Shift</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control form-control-sm" id="shiftName" name="shiftName" placeholder="Pagi/Siang/Sore">
                        </div>
                    </div>
                    <div class="form-group row  mb-4">
                        <label for="started" class="col-sm-2 col-form-label col-form-label-sm">Jam Kerja</label>
                        <div class="col-sm-4">
                            <input id="workingStarted" name="started" class="form-control flatpickr flatpickr-input" type="time" placeholder="Select Date..">
                        </div>
                        <div class="col-sm-2">
                            <label for="ended" class="col-sm-2 col-form-label col-form-label-sm">Selesai Pukul</label>
                        </div>
                        <div class="col-sm-4">
                            <input id="workingEnded" name="ended" class="form-control flatpickr flatpickr-input " type="time" placeholder="Select Date..">
                        </div>
                    </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-primary" type="submit"> Simpan</button>
            </div>
            </form>
        </div>
    </div>
</div>

<script>
    function addShiftEmployee() {
        html = '<tr>';
        html += `
            <td>
                <select class="custom-select" id="employee" name="inputEmployee[]">
                    <option value="">-- Pilih Karyawan -- </option>
                    <?php foreach ($Employee as $employee) : ?>
                    <option value="<?= $employee['employeeNIP']; ?>"><?= $employee['employee_name']; ?></option>
                    <?php endforeach; ?>
                </select>
            </td>
            <td>
                <select class="custom-select" id="Shift" name="inputEmployeeShift[]">
                    <option value="">-- Pilih Shift -- </option>
                    <?php foreach ($Shifting as $shift) : ?>
                    <option value="<?= $shift['id']; ?>"><?= $shift['shift_name']; ?></option>
                    <?php endforeach; ?>
                </select>
            </td>
            <td>
                <input type="date" class="form-control flatpickr flatpickr-input basicFlatpickr active" name="inputDateShift[]" id="Date" required>
            </td>
      `;
        html += ' </tr> ';
        $('#EmployeeShift tbody').append(html);
    }
</script>

<?= $this->endSection(); ?>