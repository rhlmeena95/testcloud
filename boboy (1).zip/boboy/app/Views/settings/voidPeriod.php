<?= $this->extend('layouts/main'); ?>
<?= $this->section('content'); ?>

<div class="row layout-top-spacing " id="cancel-row">
	<div class="col-2"></div>
	<div class="col-xl-8 col-lg-8 col-sm-8  layout-spacing">
		<div class="widget-content widget-content-area br-6">
			<h1 class="h3 mb-3"><strong><?= $title; ?>
					<?= (1 != session()->get('branch_id')) ? session()->get('branch') : ''; ?> </strong></h1>
			<?php if (1 == session()->get('branch_id')) : ?>
				<form action="<?= base_url('voidPeriod'); ?>" method="get">
					<div class="row">
						<div class="col-sm-6"></div>
						<div class="col-sm-6">
							<div class="input-group">
								<select class="custom-select" id="branch" name="branch" <?= (1 != session()->get('branch_id')) ? 'disabled' : ''; ?>>
									<option value="">-- Pilih Cabang -- </option>
									<?php foreach ($Branch as $branch) : ?>
										<option value="<?= $branch['branchID']; ?>" <?= ($inputBranch == $branch['branchID']) ? 'selected' : ''; ?>><?= $branch['branch_name']; ?></option>
									<?php endforeach; ?>
								</select>
								<div class="input-group-append">
									<button class="btn btn-primary" type="submit">Lihat Data</button>
								</div>
							</div>
						</div>
					</div>
				</form>
			<?php endif; ?>
			<br>
			<div class="table-responsive">
				<table class="multi-table table table-hover" style="width:100%">
					<thead>
						<tr class="text-center">
							<th>#</th>
							<th>Waktu Pembatalan</th>
							<th>Aksi</th>
						</tr>
					</thead>
					<tbody class="text-center">
						<?php if ($VoidPeriod != null) :
							$i = 1;
							foreach ($VoidPeriod as $void) : ?>
								<td><?= $i++; ?></td>
								<td><?= $void['void_period_time']; ?> Menit</td>
								<td><button class="btn btn-primary btn-sm btnCust" data-toggle="modal" data-target="#formUpdateVoidPeriod<?= $void['voidPeriodID']; ?>">
										<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-edit">
											<path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
											<path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
										</svg> Ubah
									</button>
								</td>
								<div class="modal fade" id="formUpdateVoidPeriod<?= $void['voidPeriodID']; ?>" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="formUpdateVoidPeriodLabel" aria-hidden="true">
									<div class="modal-dialog modal-sm" role="document">
										<div class="modal-content">
											<div class="modal-header">
												<h5 class="modal-title" id="formUpdateVoidPeriodLabel">Ubah Data Cabang</h5>

											</div>
											<div class="modal-body">
												<form action="<?= base_url('voidPeriod/update'); ?>" method="post">
													<input type="hidden" id="voidPeriodID" name="voidPeriodID" value="<?= $void['voidPeriodID']; ?>">
													<div class="form-group">
														<label for="inputVoidPeriod">Waktu Pembatalan</label>
														<div class="input-group mb-5">
															<input type="number" class="form-control" min="0" value="<?= $void['void_period_time']; ?>" name="inputVoidPeriod" id="inputVoidPeriod" required>
															<div class="input-group-append">
																<span class="input-group-text" id="basic-addon6">Menit</span>
															</div>
														</div>
													</div>
													<div class="modal-footer">
														<button class="btn" data-dismiss="modal"><i class="flaticon-cancel-12"></i> Kembali</button>
														<button type="submit" class="btn btn-primary">Simpan</button>
													</div>
												</form>
											</div>
										</div>
									</div>
								</div>
						<?php endforeach;
						endif; ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
	<div class="col-2"></div>
</div>

<?= $this->endSection(); ?>