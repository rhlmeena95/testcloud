<?= $this->extend('layouts/main'); ?>
<?= $this->section('content'); ?>

<div class="row layout-top-spacing" id="cancel-row">
	<div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
		<div class="widget-content widget-content-area ">
			<div class="text-right">
				<a href="<?= base_url('customers/createCustomers'); ?>" type="button" class="btn btn-primary">
					<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-plus-circle">
						<circle cx="12" cy="12" r="10"></circle>
						<line x1="12" y1="8" x2="12" y2="16"></line>
						<line x1="8" y1="12" x2="16" y2="12"></line>
					</svg>
					Registrasi Pelanggan
				</a>
			</div>
			<div class="table-responsive">
				<table class="table table-striped dataTable" style="width:100%">
					<thead>
						<th>#</th>
						<th>Nama Pelanggan</th>
						<th>Alamat</th>
						<th>Tanggal Lahir</th>
						<th>Nomor Telepon</th>
						<th>Poin</th>
						<th>Status</th>
						<th>Dibuat pada</th>
						<th>Aksi</th>
					</thead>
					<tbody>
						<?php $i = 1;
						foreach ($Customers as $customers) : ?>
							<?php if ($customers['customersID'] != 1) : ?>
								<tr>
									<td><?= $i++ ?> </td>
									<td><?= $customers['customer_fullname'] ?> </td>
									<td class="text-wrap"><?= $customers['customer_address']; ?>, <?= $customers['province_name']; ?>, <?= $customers['city_name']; ?>, <?= $customers['subdistrict_name']; ?></td>
									<?php $prdate = new DateTime($customers['customer_birthday']); ?>
									<td><?= date_indo($prdate->format('Y-m-d')) ?></td>
									<td><?= $customers['customer_telephone'] ?> </td>
									<td><?= $customers['customer_points'] ?> </td>
									<td><?= ($customers['customer_is_active'] == 1) ? 'Aktif' : 'Tidak Aktif'; ?> </td>
									<?php $timedate = new DateTime($customers['customer_created_at']); ?>
									<td><?= date_indo($timedate->format('Y-m-d'))  . ', ' . $timedate->format('H:i') ?></td>
									<td>
										<a href="<?= base_url('customers/updateCustomers?id=') . $customers['customer_code']; ?>" class="btn btn-primary btn-sm btnCust">
											<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-edit">
												<path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
												<path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
											</svg> Ubah
										</a>
										<form action="<?= base_url('customers/deleteCustomers'); ?>" method="post" class="d-inline">
											<input type="hidden" name="customersID" id="customersID" value="<?= $customers['customersID']; ?>">
											<input type="hidden" name="_method" value="DELETE">
											<button type="submit" class="btn btn-outline-dark btn-sm" onclick="return confirm('Apakah anda yakin mengapus Pelanggan?')">
												<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather text-danger feather-trash-2">
													<polyline points="3 6 5 6 21 6"></polyline>
													<path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
													<line x1="10" y1="11" x2="10" y2="17"></line>
													<line x1="14" y1="11" x2="14" y2="17"></line>
												</svg> Hapus
											</button>
										</form>
									</td>
								</tr>
							<?php endif; ?>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>


<?= $this->endSection(); ?>