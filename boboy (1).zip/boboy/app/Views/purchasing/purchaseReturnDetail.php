<?= $this->extend('layouts/main'); ?>
<?= $this->section('content'); ?>
<div class="card">
    <div class="card-body">
        <h4 class="text-center">Detail pengembalian barang</h4>
        <hr class=" mb-5">
        <div class="modal-body">
            <div class="row">
                <div class="col-sm-8">
                    <table class="table table-bordered table-hover">
                        <tr class="font-weight-bold">
                            <td>Nomor Invoice</td>
                            <td><?= $PurchaseReturn['purchase_return_invoice'] ?></td>
                        </tr>
                        <tr>
                            <td>Tanggal Pembuatan</td>
                            <td>
                                <?php $prdate = new DateTime($PurchaseReturn['purchase_return_date_order']);
                                echo date_indo($prdate->format('Y-m-d'));  ?>
                            </td>
                        </tr>
                        <tr>
                            <td>Supplier</td>
                            <td><?= $PurchaseReturn['supplier_company'] ?></td>
                        </tr>
                    </table>
                </div>
                <div class="col-sm-4">
                    <h5 class="font-weight-bold">Alasan Pengembalian</h5>
                    <p><?= $PurchaseReturn['purchase_return_reason'] ?></p>
                    <br>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <table class="table table-bordered table-hover">
                        <thead>
                            <th>#</th>
                            <th>Nama Product</th>
                            <th>Jumlah Pengembalian</th>
                        </thead>
                        <tbody>
                            <?php $no = 1;
                            foreach ($PurchaseReturnProduct as $product) : ?>
                                <tr>
                                    <td><?= $no++; ?></td>
                                    <td><?= $product['purchase_return_product_name'] ?></td>
                                    <td><?= $product['purchase_return_qty'] ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="row">
                <div class="col-6 text-center">
                    <table class="table table-bordered ">
                        <thead>
                            <tr>
                                <th class="text-center">Diterima Oleh</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr class="text-center">
                                <td>
                                    <br>
                                    <br>
                                    <br>
                                    <br>
                                    .....................................
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="col-6 text-center">
                    <table class="table table-bordered ">
                        <thead>
                            <tr>
                                <th class="text-center">Dibuat Oleh</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr class="text-center">
                                <td>
                                    <br>
                                    <br>
                                    <br>
                                    <br>
                                    <?= $PurchaseReturn['branch_name'] ?>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection(); ?>