<?php

namespace App\Controllers\Inventory;

use App\Controllers\BaseController;
use App\Models\InventoryModel;
use App\Models\MasterModel;
use App\Models\PurchasingModel;


class HandoverStuff extends BaseController
{
	function __construct()
	{
		$this->PurchasingModel 		= new PurchasingModel();
		$this->MasterModel 			= new MasterModel();
		$this->InventoryModel		= new InventoryModel();
	}
	public function index()
	{
		$branch = $this->request->getGet('branch');
		if ($branch != null) {
			$Purchasing = $this->PurchasingModel->getPurchaseOrderBranch($branch);
		} else {
			$Purchasing = $this->PurchasingModel->getPurchaseOrderBranch();
		}
		$data = array_merge($this->data, [
			'category'  		=> 'Inventori',
			'title'         	=> 'Serah Terima Barang',
			'PurchaseOrders' 	=> $Purchasing,
			'Branch'    		=> $this->MasterModel->getBranch(),
			'inputBranch'		=> $branch
		]);
		return view('inventory/handoverStuffListPurchaseOrder', $data);
	}
	public function detailHandoverStuff()
	{
		$data = array_merge($this->data, [
			'category'  		=> 'Inventori',
			'title'         	=> 'Serah Terima Barang',
			'PurchaseOrders' 	=> $this->PurchasingModel->getPurchaseOrder($this->request->getGet('id')),
			'Branch'    		=> $this->MasterModel->getBranch(),
			'Products'  		=> $this->PurchasingModel->getPurchaseOrderProduct($this->request->getGet('id')),

		]);

		return view('inventory/handoverStuffDetail', $data);
	}
	public function printBarcode()
	{
		$purchaseOrderProductID	= $this->request->getGet('purchaseOrderProductID');
		$purchaseOrderID	= $this->request->getGet('purchaseOrderID');
		$print	= $this->request->getGet('total');
		$barcode =  new \Picqer\Barcode\BarcodeGeneratorSVG();
		$data = array_merge($this->data, [
			'Product'					=> $this->PurchasingModel->getPurchaseOrderProductById($purchaseOrderProductID),
			'Print'						=> $print,
			'barcode'					=> $barcode,
			'purchaseOrderProductID'	=> $purchaseOrderID,
			'no'						=> 1
		]);
		return view('inventory/printBarcode', $data);
	}
	public function saveProductReceive()
	{
		$dataid           	= $this->request->getPost('idPurchaseOrderProduct');
		$ProductReceive 	= [];
		$index				= $this->request->getPost('index');
		$index1 			= $index++;
		$product            = $this->request->getPost('inputReceiveProduct');
		$purchaseOrderID 		= $this->request->getPost('purchaseOrderID');
		if ($product[$index1] == 0) {
			session()->setFlashdata('notif_error', '<b>Gagal menyimpan barang data belum selesai di isi</b>');
			return redirect()->to(base_url('handoverStuff/detail?id=' . $purchaseOrderID));
		}
		$productID		 		= $this->request->getPost('productID');
		$invoice				= $this->request->getPost('purchaseOrderInvoice');
		$period 			= date('Y');
		for ($i = 0; $i <= $index; $i++) {
			array_push($ProductReceive, [
				'id'                        => $dataid[$index1],
				'purchase_order_received'   => $product[$index1],
			]);
		}
		if ($ProductReceive != 0) {
			$saveProductReceive 	= $this->PurchasingModel->updateProductReceive($ProductReceive);
			if ($saveProductReceive) {
				$purchaseOrder 			= $this->PurchasingModel->getPurchaseOrderProductStock($purchaseOrderID, $productID);
				$this->PurchasingModel->receiveGood($purchaseOrder, $invoice, $period);
				session()->setFlashdata('notif_success', '<b>Berhasil menyimpan barang yang diterima dan memindahkan data barang ke kartu stok</b>');
				return redirect()->to(base_url('handoverStuff/detail?id=' . $purchaseOrderID));
			} else {
				session()->setFlashdata('notif_error', '<b>Gagal menyimpan barang yang diterima dan memindahkan data barang ke kartu stok</b>');
				return redirect()->to(base_url('handoverStuff/detail?id=' . $purchaseOrderID));
			}
		} else {
			session()->setFlashdata('notif_error', '<b>Mohon isikan data barang yang telah diterima</b>');
			return redirect()->to(base_url('handoverStuff/detail?id=' . $purchaseOrderID));
		}
	}
}
