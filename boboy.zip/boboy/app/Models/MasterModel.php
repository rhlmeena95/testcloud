<?php

namespace App\Models;

use CodeIgniter\Model;

class MasterModel extends Model
{
    public function getProductDivisi($ProductDivisiID = false)
    {
        if ($ProductDivisiID) {
            return $this->db->table('product_divisi')
                ->select('*, product_divisi.id AS divisiID')
                ->where(['product_divisi.id' => $ProductDivisiID])
                ->get()->getRowArray();
        } else {
            return $this->db->table('product_divisi')
                ->select('*, product_divisi.id AS divisiID')
                ->get()->getResultArray();
        }
    }
    public function getProductDepartment($ProductDepartmentID = false)
    {
        if ($ProductDepartmentID) {
            return $this->db->table('product_department')
                ->select('*, product_divisi.id AS divisiID,product_department.id AS departmentID')
                ->join('product_divisi', 'product_department.product_divisi_id = product_divisi.id')
                ->where(['product_department.id' => $ProductDepartmentID])
                ->get()->getRowArray();
        } else {
            return $this->db->table('product_department')
                ->select('*, product_divisi.id AS divisiID,product_department.id AS departmentID')
                ->join('product_divisi', 'product_department.product_divisi_id = product_divisi.id')
                ->get()->getResultArray();
        }
    }
    public function getProductSubdepartment($ProductSubdepartmentID = false)
    {
        if ($ProductSubdepartmentID) {
            return $this->db->table('product_subdepartment')
                ->select('*, product_subdepartment.id AS subdepartmentID, product_department.id AS departmentID')
                ->join('product_department', 'product_subdepartment.product_department_id = product_department.id')
                ->where(['product_subdepartment.id' => $ProductSubdepartmentID])
                ->orderBy('product_subdep_name', 'ASC')->get()->getRowArray();
        } else {
            return $this->db->table('product_subdepartment')
                ->select('*, product_subdepartment.id AS subdepartmentID, product_department.id AS departmentID, product_divisi.id AS divisiID')
                ->join('product_department', 'product_subdepartment.product_department_id = product_department.product_department_code')
                ->join('product_divisi', 'product_subdepartment.product_divisi_id = product_divisi.id')
                ->orderBy('product_subdep_name', 'ASC')->get()->getResultArray();
        }
    }
    public function getProducts($ProductsID = false)
    {
        if ($ProductsID) {
            return $this->db->table('products')
                ->select('*, products.id AS productID')
                ->join('product_subdepartment', 'products.product_subdepartment_id = product_subdepartment.product_subdep_code')
                ->where(['products.id' => $ProductsID])
                ->get()->getRowArray();
        } else {
            return $this->db->table('products')
                ->select('*, products.id AS productID')
                ->join('product_subdepartment', 'products.product_subdepartment_id = product_subdepartment.product_subdep_code')
                ->orderBy('product_subdep_name')
                ->get()->getResultArray();
        }
    }
    public function getProduct()
    {
        return $this->db->table('products')
            ->select('product_sku, product_name,product_subdep_name, product_created_at, product_updated_at, product_stock,product_subdepartment_id, product_purchase_price,product_selling_price, product_subdepartment.id AS subdepartmentID, products.id AS productID')
            ->join('product_subdepartment', 'products.product_subdepartment_id = product_subdepartment.product_subdep_code')
            ->orderBy('product_selling_price', 'ASC');
    }
    public function getMaxCodeDepartment()
    {
        $getMax = $this->db->table('product_department')->selectMax('product_department.product_department_code')->get()->getRowArray();
        if ($getMax['product_department_code'] != NULL) {
            $maxNumber = $getMax['product_department_code'] + 1;
        } else {
            $maxNumber = $getMax;
        }
        return $maxNumber;
    }
    public function createProductDivisi($dataProductDivisi)
    {
        $getMaxid    = $this->db->table('product_divisi')->selectMax('product_divisi.id')->get()->getRowArray();
        $idDivisi = $getMaxid['id'] + 1;
        return $this->db->table('product_divisi')->insert([
            'product_divisi_code'         => $idDivisi,
            'product_divisi_name'         => $dataProductDivisi['inputProductDivisiName'],
        ]);
    }
    public function createProductdepartment($dataProductDepartment)
    {
        return $this->db->table('product_department')->insert([
            'product_department_code'         => $dataProductDepartment['inputProductDepartmentCode'],
            'product_department_name'         => $dataProductDepartment['inputProductDepartmentName'],
            'product_divisi_id'                => $dataProductDepartment['inputProductDivisiId'],
        ]);
    }
    public function createProductSubdepartment($dataProductSubdepartment)
    {
        $dataCodedivisi = $dataProductSubdepartment['inputProductdivisiId'];
        $dataCodedepartment = $dataProductSubdepartment['inputProductdepartmentId'];
        $id = $this->db->table('product_subdepartment')->selectMax('id')->get()->getRowArray();
        if ($id['id'] != NULL) {
            $maxNumber = $id['id'] + 1;
            $maxNumber = sprintf("%02s", $maxNumber);
        } else {
            $maxNumber = '01';
        }
        $codeSubdepartment = $dataCodedepartment . '0' . $dataCodedivisi . $maxNumber;
        return $this->db->table('product_subdepartment')->insert([
            'product_subdep_code'         => $codeSubdepartment,
            'product_subdep_name'         => $dataProductSubdepartment['inputProductSubdepName'],
            'product_department_id'       => $dataCodedepartment,
            'product_divisi_id'           => $dataCodedivisi
        ]);
    }
    public function createProducts($dataProducts)
    {
        $this->db->transBegin();
        if ($dataProducts['inputCategory'] === 'Pilih Kategori Barang') {
            $this->db->transRollback();
            return false;
        } else {
            $subdepartmentCode = $dataProducts['inputCategory'];
            $getMax    = $this->db->table('products')->selectMax('products.id')->get()->getRowArray();
            if ($getMax['id'] != NULL) {
                $maxNumber = $getMax['id'] + 1;
                $maxNumber = sprintf("%05s", $maxNumber);
            } else {
                $maxNumber = '00001';
            }
            $sku = $subdepartmentCode . $maxNumber;
            $this->db->table('products')->insert([
                'product_subdepartment_id'  => $dataProducts['inputCategory'],
                'product_sku'               => $sku,
                'product_name'              => $dataProducts['inputName'],
                'product_purchase_price'    => $dataProducts['inputPurchasePrice'],
                'product_selling_price'     => $dataProducts['inputSellingPrice'],
                'product_stock'             => $dataProducts['inputStock'],
                'product_points'            => 0,
                // 'product_expired_at'        => $dataProducts['inputExpiredAt'],
                'product_created_at'        => date('Y-m-d H:i;s'),
                'product_updated_at'        => date('Y-m-d H:i:s')
            ]);
            $productID =  $this->db->insertID();
            if (session()->get('branch_id') == 1) {
                $this->db->table('stock_product')->insert([
                    'branch_id'                     => 1,
                    'product_id'                    => $productID,
                    'stock_product_subdep_id'       => $dataProducts['inputCategory'],
                    'stock_product_name'            => $dataProducts['inputName'],
                    'stock_product_qty_new'         => $dataProducts['inputStock'],
                    'stock_product_price'           => $dataProducts['inputPurchasePrice'],
                    'stock_product_selling_price'   => $dataProducts['inputSellingPrice']
                ]);
                $this->db->table('stock_product')->insert([
                    'branch_id'                     => 2,
                    'product_id'                    => $productID,
                    'stock_product_subdep_id'       => $dataProducts['inputCategory'],
                    'stock_product_name'            => $dataProducts['inputName'],
                    'stock_product_qty_new'         => 0,
                    'stock_product_price'           => $dataProducts['inputPurchasePrice'],
                    'stock_product_selling_price'   => $dataProducts['inputSellingPrice']
                ]);
                $this->db->table('stock_product')->insert([
                    'branch_id'                     => 3,
                    'product_id'                    => $productID,
                    'stock_product_subdep_id'       => $dataProducts['inputCategory'],
                    'stock_product_name'            => $dataProducts['inputName'],
                    'stock_product_qty_new'         => 0,
                    'stock_product_price'           => $dataProducts['inputPurchasePrice'],
                    'stock_product_selling_price'   => $dataProducts['inputSellingPrice']
                ]);
                $this->db->table('stock_initial')->insert([
                    'branch_id'                     => 1,
                    'product_id'                    => $productID,
                    'stock_initial_period'          => date('Y'),
                    'stock_initial_quantity'        => $dataProducts['inputStock'],
                    'stock_initial_nominal'         => $dataProducts['inputSellingPrice'],
                    'stock_initial_created_by'      => session()->get('user_id'),
                    'stock_initial_created_at'      => date('Y-m-d H:i:s')
                ]);
                $this->db->table('stock_initial')->insert([
                    'branch_id'                     => 2,
                    'product_id'                    => $productID,
                    'stock_initial_period'          => date('Y'),
                    'stock_initial_quantity'        => 0,
                    'stock_initial_nominal'         => $dataProducts['inputSellingPrice'],
                    'stock_initial_created_by'      => session()->get('user_id'),
                    'stock_initial_created_at'      => date('Y-m-d H:i:s')
                ]);
                $this->db->table('stock_initial')->insert([
                    'branch_id'                     => 3,
                    'product_id'                    => $productID,
                    'stock_initial_period'          => date('Y'),
                    'stock_initial_quantity'        => 0,
                    'stock_initial_nominal'         => $dataProducts['inputSellingPrice'],
                    'stock_initial_created_by'      => session()->get('user_id'),
                    'stock_initial_created_at'      => date('Y-m-d H:i:s')
                ]);
            } elseif (session()->get('branch_id') == 2) {
                $this->db->table('stock_product')->insert([
                    'branch_id'                     => 1,
                    'product_id'                    => $productID,
                    'stock_product_subdep_id'       => $dataProducts['inputCategory'],
                    'stock_product_name'            => $dataProducts['inputName'],
                    'stock_product_qty_new'         => 0,
                    'stock_product_price'           => $dataProducts['inputPurchasePrice'],
                    'stock_product_selling_price'   => $dataProducts['inputSellingPrice']
                ]);
                $this->db->table('stock_product')->insert([
                    'branch_id'                     => 2,
                    'product_id'                    => $productID,
                    'stock_product_subdep_id'       => $dataProducts['inputCategory'],
                    'stock_product_name'            => $dataProducts['inputName'],
                    'stock_product_qty_new'         => $dataProducts['inputStock'],
                    'stock_product_price'           => $dataProducts['inputPurchasePrice'],
                    'stock_product_selling_price'   => $dataProducts['inputSellingPrice']
                ]);
                $this->db->table('stock_product')->insert([
                    'branch_id'                     => 3,
                    'product_id'                    => $productID,
                    'stock_product_subdep_id'       => $dataProducts['inputCategory'],
                    'stock_product_name'            => $dataProducts['inputName'],
                    'stock_product_qty_new'         => 0,
                    'stock_product_price'           => $dataProducts['inputPurchasePrice'],
                    'stock_product_selling_price'   => $dataProducts['inputSellingPrice']
                ]);
                $this->db->table('stock_initial')->insert([
                    'branch_id'                     => 1,
                    'product_id'                    => $productID,
                    'stock_initial_period'          => date('Y'),
                    'stock_initial_quantity'        => 0,
                    'stock_initial_nominal'         => $dataProducts['inputSellingPrice'],
                    'stock_initial_created_by'      => session()->get('user_id'),
                    'stock_initial_created_at'      => date('Y-m-d H:i:s')
                ]);
                $this->db->table('stock_initial')->insert([
                    'branch_id'                     => 2,
                    'product_id'                    => $productID,
                    'stock_initial_period'          => date('Y'),
                    'stock_initial_quantity'        => $dataProducts['inputStock'],
                    'stock_initial_nominal'         => $dataProducts['inputSellingPrice'],
                    'stock_initial_created_by'      => session()->get('user_id'),
                    'stock_initial_created_at'      => date('Y-m-d H:i:s')
                ]);
                $this->db->table('stock_initial')->insert([
                    'branch_id'                     => 3,
                    'product_id'                    => $productID,
                    'stock_initial_period'          => date('Y'),
                    'stock_initial_quantity'        => 0,
                    'stock_initial_nominal'         => $dataProducts['inputSellingPrice'],
                    'stock_initial_created_by'      => session()->get('user_id'),
                    'stock_initial_created_at'      => date('Y-m-d H:i:s')
                ]);
            } elseif (session()->get('branch_id') == 3) {
                $this->db->table('stock_product')->insert([
                    'branch_id'                     => 1,
                    'product_id'                    => $productID,
                    'stock_product_subdep_id'       => $dataProducts['inputCategory'],
                    'stock_product_name'            => $dataProducts['inputName'],
                    'stock_product_qty_new'         => 0,
                    'stock_product_price'           => $dataProducts['inputPurchasePrice'],
                    'stock_product_selling_price'   => $dataProducts['inputSellingPrice']
                ]);
                $this->db->table('stock_product')->insert([
                    'branch_id'                     => 2,
                    'product_id'                    => $productID,
                    'stock_product_subdep_id'       => $dataProducts['inputCategory'],
                    'stock_product_name'            => $dataProducts['inputName'],
                    'stock_product_qty_new'         => 0,
                    'stock_product_price'           => $dataProducts['inputPurchasePrice'],
                    'stock_product_selling_price'   => $dataProducts['inputSellingPrice']
                ]);
                $this->db->table('stock_product')->insert([
                    'branch_id'                     => 3,
                    'product_id'                    => $productID,
                    'stock_product_subdep_id'       => $dataProducts['inputCategory'],
                    'stock_product_name'            => $dataProducts['inputName'],
                    'stock_product_qty_new'         => $dataProducts['inputStock'],
                    'stock_product_price'           => $dataProducts['inputPurchasePrice'],
                    'stock_product_selling_price'   => $dataProducts['inputSellingPrice']
                ]);
                $this->db->table('stock_initial')->insert([
                    'branch_id'                     => 1,
                    'product_id'                    => $productID,
                    'stock_initial_period'          => date('Y'),
                    'stock_initial_quantity'        => 0,
                    'stock_initial_nominal'         => $dataProducts['inputSellingPrice'],
                    'stock_initial_created_by'      => session()->get('user_id'),
                    'stock_initial_created_at'      => date('Y-m-d H:i:s')
                ]);
                $this->db->table('stock_initial')->insert([
                    'branch_id'                     => 2,
                    'product_id'                    => $productID,
                    'stock_initial_period'          => date('Y'),
                    'stock_initial_quantity'        => 0,
                    'stock_initial_nominal'         => $dataProducts['inputSellingPrice'],
                    'stock_initial_created_by'      => session()->get('user_id'),
                    'stock_initial_created_at'      => date('Y-m-d H:i:s')
                ]);
                $this->db->table('stock_initial')->insert([
                    'branch_id'                     => 3,
                    'product_id'                    => $productID,
                    'stock_initial_period'          => date('Y'),
                    'stock_initial_quantity'        => $dataProducts['inputStock'],
                    'stock_initial_nominal'         => $dataProducts['inputSellingPrice'],
                    'stock_initial_created_by'      => session()->get('user_id'),
                    'stock_initial_created_at'      => date('Y-m-d H:i:s')
                ]);
            }

            if ($this->db->transStatus() === false) {
                $this->db->transRollback();
                return false;
            } else {
                $this->db->transCommit();
                return true;
            }
        }
    }

    public function updateProductdivisi($dataProductDivisi)
    {
        return $this->db->table('product_divisi')->update([
            'product_divisi_name'         => $dataProductDivisi['inputProductDivisiName'],
        ], ['id' => $dataProductDivisi['iddivisi']]);
    }
    public function updateProductdepartment($dataProductDepartment)
    {
        return $this->db->table('product_department')->update([
            'product_department_code'         => $dataProductDepartment['inputProductDepartmentCode'],
            'product_department_name'         => $dataProductDepartment['inputProductDepartmentName'],
            'product_divisi_id'               => $dataProductDepartment['inputProductDivisiId'],
        ], ['id' => $dataProductDepartment['inputProductDepartmentID']]);
    }
    public function updateProductSubdepartment($dataProductSubdepartment)
    {
        $this->db->transBegin();
        $dataCodedivisi = $dataProductSubdepartment['inputProductDivisiId'];
        $dataCodedepartment = $dataProductSubdepartment['inputProductDepartmentId'];
        $codeSubdepartment = $dataCodedepartment . '0' . $dataCodedivisi . $dataProductSubdepartment['inputProductSubdepartmentID'];
        $dataproduct = $this->db->table('products')->getWhere(['product_subdepartment_id' => $dataProductSubdepartment['inputProductSubdepCode']])->getResultArray();
        foreach ($dataproduct as $product) {
            $this->db->table('products')->update([
                'product_subdepartment_id' => $codeSubdepartment
            ], ['id' => $product['id']]);
        }
        $dataStockProduct =  $this->db->table('stock_product')->getWhere(['stock_product_subdep_id' => $dataProductSubdepartment['inputProductSubdepCode']])->getResultArray();
        foreach ($dataStockProduct as $Stockproduct) {
            $this->db->table('stock_product')->update([
                'stock_product_subdep_id' => $codeSubdepartment
            ], ['product_id' => $Stockproduct['product_id']]);
        }
        $this->db->table('product_subdepartment')->update([
            'product_subdep_code'         => $codeSubdepartment,
            'product_subdep_name'         => $dataProductSubdepartment['inputProductSubdepName'],
            'product_department_id'       => $dataCodedepartment,
            'product_divisi_id'           => $dataCodedivisi
        ], ['id' => $dataProductSubdepartment['inputProductSubdepartmentID']]);

        if ($this->db->transStatus() === false) {
            $this->db->transRollback();
            return false;
        } else {
            $this->db->transCommit();
            return true;
        }
    }
    public function updateProducts($dataProducts)
    {
        $this->db->transBegin();
        if ($dataProducts['inputCategory'] == 'Pilih Kategori Barang') {
            return false;
        } else {
            // $stock_product = $this->db->table('stock_product')->getWhere(['product_id' => $dataProducts['productID']])->getRowArray();
            // $product = $this->db->table('products')->getWhere(['id' => $dataProducts['productID']])->getRowArray();
            // $stock = ($product['product_stock'] - $stock_product['stock_product_qty_new']) + $dataProducts['inputStock'];
            $this->db->table('products')->update([
                'product_subdepartment_id'  => $dataProducts['inputCategory'],
                'product_sku'               => $dataProducts['inputSKU'],
                'product_name'              => $dataProducts['inputName'],
                'product_purchase_price'    => $dataProducts['inputPurchasePrice'],
                'product_selling_price'     => $dataProducts['inputSellingPrice'],
                // 'product_stock'             => $stock,
                'product_points'            => 0,
                'product_updated_at'         => date('Y-m-d H:i:s')
            ], ['id' => $dataProducts['productID']]);

            $this->db->table('stock_product')->update([
                'stock_product_subdep_id'       => $dataProducts['inputCategory'],
                'stock_product_name'            => $dataProducts['inputName'],
                // 'stock_product_qty_new'         => $dataProducts['inputStock'],
                'stock_product_price'           => $dataProducts['inputPurchasePrice'],
                'stock_product_selling_price'   => $dataProducts['inputSellingPrice']
            ], [
                'product_id'                    => $dataProducts['productID'],
            ]);

            $this->db->table('stock_initial')->update([
                'stock_initial_period'          => date('Y'),
                // 'stock_initial_quantity'        => $dataProducts['inputStock'],
                'stock_initial_nominal'         => $dataProducts['inputSellingPrice'],
                'stock_initial_created_by'      => session()->get('user_id'),
                'stock_initial_created_at'      => date('Y-m-d H:i:s')
            ], [
                'product_id'                    => $dataProducts['productID'],
                'branch_id'                     => 1
            ]);
            $this->db->table('stock_initial')->update([
                'stock_initial_period'          => date('Y'),
                // 'stock_initial_quantity'        => $dataProducts['inputStock'],
                'stock_initial_nominal'         => $dataProducts['inputSellingPrice'],
                'stock_initial_created_by'      => session()->get('user_id'),
                'stock_initial_created_at'      => date('Y-m-d H:i:s')
            ], [
                'product_id'                    => $dataProducts['productID'],
                'branch_id'                     => 2
            ]);
            $this->db->table('stock_initial')->update([
                'stock_initial_period'          => date('Y'),
                // 'stock_initial_quantity'        => $dataProducts['inputStock'],
                'stock_initial_nominal'         => $dataProducts['inputSellingPrice'],
                'stock_initial_created_by'      => session()->get('user_id'),
                'stock_initial_created_at'      => date('Y-m-d H:i:s')
            ], [
                'product_id'                    => $dataProducts['productID'],
                'branch_id'                     => 3
            ]);

            if ($this->db->transStatus() === false) {
                $this->db->transRollback();
                return false;
            } else {
                $this->db->transCommit();
                return true;
            }
        }
    }
    public function deleteProductdivisi($ProductDivisiID)
    {
        $productDepartment = $this->db->table('product_department')->where(['product_divisi_id' => $ProductDivisiID])->countAllResults();
        if ($productDepartment == 0) {
            $productSubdep = $this->db->table('product_subdepartment')->where(['product_divisi_id' => $ProductDivisiID])->countAllResults();
            if ($productSubdep == 0) {
                return $this->db->table('product_divisi')->delete(['id' => $ProductDivisiID]);
            } else {
                return false;
            }
        } else {
            return false;
        }
    }
    public function deleteProductdepartment($ProductDepartmentID)
    {
        $productSubdep = $this->db->table('product_subdepartment')->where(['product_divisi_id' => $ProductDepartmentID])->countAllResults();
        if ($productSubdep == 0) {
            return $this->db->table('product_department')->delete(['id' => $ProductDepartmentID]);
        } else {
            return false;
        }
    }
    public function deleteProductSubdepartment($ProductSubdepartmentID)
    {
        #check subdepartment
        $subdepartment = $this->db->table('product_subdepartment')->getWhere(['id' => $ProductSubdepartmentID])->getRowArray();
        $product = $this->db->table('products')->getWhere(['product_subdepartment_id' => $subdepartment['product_subdep_code']])->getRowArray();
        if (!$product) {
            return $this->db->table('product_subdepartment')->delete(['id' => $ProductSubdepartmentID]);
        } else {
            return false;
        }
    }
    public function deleteProducts($ProductsID)
    {
        $this->db->transBegin();
        $salesOrderProduct = $this->db->table('sales_order_product')->getWhere(['product_id' => $ProductsID])->getRowArray();
        if ($salesOrderProduct) {
            return false;
        } else {
            $this->db->table('products')->delete(['id' => $ProductsID]);
            $this->db->table('stock_product')->delete(['product_id' => $ProductsID]);
            $this->db->table('stock_initial')->delete(['product_id' => $ProductsID]);

            if ($this->db->transStatus() === false) {
                $this->db->transRollback();
                return false;
            } else {
                $this->db->transCommit();
                return true;
            }
        }
    }
    public function getPaymentMethod($PaymentMethodID = false)
    {
        if ($PaymentMethodID) {
            return $this->db->table('payment_method')
                ->select('*, payment_method.id AS paymentMethodID')
                ->where(['payment_method.id' => $PaymentMethodID])
                ->get()->getRowArray();
        } else {
            return $this->db->table('payment_method')
                ->select('*, payment_method.id AS paymentMethodID')
                ->get()->getResultArray();
        }
    }
    public function createPaymentMethod($dataPaymentMethod)
    {
        return $this->db->table('payment_method')->insert([
            'payment_method_code'    => $dataPaymentMethod['inputPaymentMethodCode'],
            'payment_method_name'    => $dataPaymentMethod['inputPaymentMethodName'],
            'need_issue'             => $dataPaymentMethod['inputNeedIssue']
        ]);
    }
    public function updatePaymentMethod($dataPaymentMethod)
    {
        return $this->db->table('payment_method')->update([
            'payment_method_code'    => $dataPaymentMethod['inputPaymentMethodCode'],
            'payment_method_name'    => $dataPaymentMethod['inputPaymentMethodName'],
            'need_issue'             => $dataPaymentMethod['inputNeedIssue']
        ], ['id' => $dataPaymentMethod['paymentMethodID']]);
    }
    public function deletePaymentMethod($PaymentMethodID)
    {
        return $this->db->table('payment_method')->delete(['id' => $PaymentMethodID]);
    }
    public function getBranch($BranchID = false)
    {
        if ($BranchID) {
            return $this->db->table('branch')
                ->select('*, branch.id AS branchID,city.id AS cityID,employee.id AS employeeID,province.id AS provinceID,subdistrict.id AS subdistrictID')
                ->join('city', 'branch.branch_city = city.id')
                ->join('province', 'branch.branch_province = province.id')
                ->join('subdistrict', 'branch.branch_subdistrict = subdistrict.id')
                ->join('employee', 'branch.branch_manager = employee.id')
                ->where(['branch.id' => $BranchID])
                ->get()->getRowArray();
        } else {
            return $this->db->table('branch')
                ->select('*, branch.id AS branchID,city.id AS cityID,employee.id AS employeeID,province.id AS provinceID,subdistrict.id AS subdistrictID')
                ->join('city', 'branch.branch_city = city.id')
                ->join('province', 'branch.branch_province = province.id')
                ->join('subdistrict', 'branch.branch_subdistrict = subdistrict.id')
                ->join('employee', 'branch.branch_manager = employee.id')
                ->get()->getResultArray();
        }
    }
    public function getBranchbyBranch()
    {
        return $this->db->table('branch')
            ->select('*, branch.id AS branchID,city.id AS cityID,employee.id AS employeeID,province.id AS provinceID,subdistrict.id AS subdistrictID')
            ->join('city', 'branch.branch_city = city.id')
            ->join('province', 'branch.branch_province = province.id')
            ->join('subdistrict', 'branch.branch_subdistrict = subdistrict.id')
            ->join('employee', 'branch.branch_manager = employee.id')
            ->where(['branch.id' => session()->get('branch_id')])
            ->get()->getRowArray();
    }
    public function createBranch($dataBranch)
    {
        return $this->db->table('branch')->insert([
            'branch_code'              => $dataBranch['inputCode'],
            'branch_name'              => $dataBranch['inputBranchName'],
            'branch_manager'           => $dataBranch['inputBranchManager'],
            'branch_address'           => $dataBranch['inputBranchAddress'],
            'branch_province'          => $dataBranch['inputProvince'],
            'branch_city'              => $dataBranch['inputCity'],
            'branch_subdistrict'       => $dataBranch['inputSubdistrict'],
            // 'branch_postal_code'       => $dataBranch['inputPostalCode'],
            'branch_telephone'         => $dataBranch['inputBranchTelephone'],
        ]);
    }
    public function updateBranch($dataBranch)
    {
        if ($dataBranch['inputProvince'] === "Pilih Provinsi...") {
            return "error";
        } else {
            return $this->db->table('branch')->update([
                'branch_code'              => $dataBranch['inputCode'],
                'branch_name'              => $dataBranch['inputBranchName'],
                'branch_manager'           => $dataBranch['inputBranchManager'],
                'branch_address'           => $dataBranch['inputBranchAddress'],
                'branch_province'          => $dataBranch['inputProvince'],
                'branch_city'              => $dataBranch['inputCity'],
                'branch_subdistrict'       => $dataBranch['inputSubdistrict'],
                // 'branch_postal_code'       => $dataBranch['inputPostalCode'],
                'branch_telephone'         => $dataBranch['inputBranchTelephone'],
            ], ['id' => $dataBranch['branchID']]);
        }
    }
    public function deleteBranch($BranchID)
    {
        return $this->db->table('branch')->delete(['id' => $BranchID]);
    }
    public function getProvince($ProvinceID = false)
    {
        if ($ProvinceID) {
            return $this->db->table('province')
                ->where(['province.id' => $ProvinceID])
                ->get()->getRowArray();
        } else {
            return $this->db->table('province')
                ->get()->getResultArray();
        }
    }
    public function getCity($ProvinceID = false)
    {
        if ($ProvinceID) {
            return $this->db->table('city')
                ->where(['city.province_id' => $ProvinceID])
                ->get()->getResultArray();
        } else {
            return $this->db->table('city')
                ->get()->getResultArray();
        }
    }
    public function getSubdistrict($CityID = false)
    {
        if ($CityID) {
            return $this->db->table('subdistrict')
                ->where(['subdistrict.city_id' => $CityID])
                ->get()->getResultArray();
        } else {
            return $this->db->table('subdistrict')
                ->get()->getResultArray();
        }
    }
    public function point($branch = false)
    {
        if ($branch) {
            return $this->db->table('point')
                ->where(['branch_id' => $branch])
                ->get()->getResultArray();
        } else {
            return $this->db->table('point')
                ->where(['branch_id' => session()->get('branch_id')])
                ->get()->getResultArray();
        }
    }
    public function createPoint($dataPoint)
    {
        $getPoint = $this->db->table('point')->where(['branch_id' => session()->get('branch_id')])->get()->getResultArray();
        $this->db->transBegin();
        foreach ($getPoint as $point) {
            if ($point['nominal_min'] <= $dataPoint['inputNominalMin'] && $dataPoint['inputNominalMin'] <= $point['nominal_max']) {
                $this->db->table('point')->update([
                    'nominal_max'   => $dataPoint['inputNominalMin']
                ], ['id' => $point['id'], 'branch_id' => session()->get('branch_id')]);
            }
        }
        $maxPoint = $this->db->table('point')->selectMax('nominal_min')->where(['branch_id' => session()->get('branch_id')])->get()->getRowArray();
        if ($maxPoint <= $dataPoint['inputNominalMin']) {
            $pointMax = $maxPoint;
        } else {
            $pointMax = '9999999999';
        }
        $this->db->table('point')->insert([
            'branch_id'     => session()->get('branch_id'),
            'point'         => $dataPoint['inputPoint'],
            'nominal_min'   => $dataPoint['inputNominalMin'],
            'nominal_max'   => $pointMax
        ]);
        if ($this->db->transStatus() === false) {
            $this->db->transRollback();
            return false;
        } else {
            $this->db->transCommit();
            return true;
        }
    }
    public function updatePoint($dataPoint)
    {
        $maxPoint = $this->db->table('point')->selectMax('nominal_min')->where(['branch_id' => session()->get('branch_id')])->get()->getRowArray();
        if ($maxPoint <= $dataPoint['inputNominalMin']) {
            $pointMax = $maxPoint;
        } else {
            $pointMax = '9999999999';
        }
        return $this->db->table('point')->update([
            'branch_id'     => session()->get('branch_id'),
            'point'         => $dataPoint['inputPoint'],
            'nominal_min'   => $dataPoint['inputNominalMin'],
            'nominal_max'   => $pointMax
        ], ['id' => $dataPoint['pointID']]);
    }
    public function deletePoint($dataIDPoint)
    {
        return $this->db->table('point')->delete(['id' => $dataIDPoint]);
    }
    public function checkExpiredMember()
    {
        $getDataMember = $this->db->table('customers')->getWhere(['customer_is_active' => 1])->getResultArray();
        foreach ($getDataMember as $dataMember) {
            if (date('Y-m-d') >= $dataMember['customer_end_effective']) {
                return $this->db->table('customers')->update([
                    'customer_is_active'    => 0
                ], ['id' => $dataMember['id']]);
            }
        }
    }
}
