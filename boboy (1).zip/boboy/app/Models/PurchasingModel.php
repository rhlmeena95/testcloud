<?php

namespace App\Models;

use App\Controllers\Purchasing\Suppliers;
use CodeIgniter\Model;

class PurchasingModel extends Model
{

    public function getSuppliers($SuppliersID = false)
    {
        if ($SuppliersID) {
            return $this->db->table('suppliers')
                ->select('*, suppliers.id AS supplierID,city.id AS cityID,province.id AS provinceID,subdistrict.id AS subdistrictID, suppliers.province_id AS province, suppliers.city_id AS city')
                ->join('city', 'suppliers.city_id = city.id')
                ->join('province', 'suppliers.province_id = province.id')
                ->join('subdistrict', 'suppliers.subdistrict_id = subdistrict.id')
                ->where(['suppliers.id' => $SuppliersID])
                ->get()->getRowArray();
        } else {
            return $this->db->table('suppliers')
                ->select('*, suppliers.id AS supplierID,city.id AS cityID,province.id AS provinceID,subdistrict.id AS subdistrictID,suppliers.province_id AS province, suppliers.city_id AS city')
                ->join('city', 'suppliers.city_id = city.id')
                ->join('province', 'suppliers.province_id = province.id')
                ->join('subdistrict', 'suppliers.subdistrict_id = subdistrict.id')
                ->get()->getResultArray();
        }
    }
    public function createSuppliers($dataSuppliers)
    {
        return $this->db->table('suppliers')->insert([
            'supplier_company'      => $dataSuppliers['inputSupplierCompany'],
            'supplier_contact'      => $dataSuppliers['inputSupplierContact'],
            'supplier_telephone'    => $dataSuppliers['inputSupplierTelephone'],
            'supplier_address'      => $dataSuppliers['inputSupplierAddress'],
            'province_id'           => $dataSuppliers['inputSupplierProvince'],
            'city_id'               => $dataSuppliers['inputSupplierCity'],
            'subdistrict_id'        => $dataSuppliers['inputSupplierSubdistrict'],
        ]);
    }
    public function updateSuppliers($dataSuppliers)
    {
        return $this->db->table('suppliers')->update([
            'supplier_company'      => $dataSuppliers['inputSupplierCompany'],
            'supplier_contact'      => $dataSuppliers['inputSupplierContact'],
            'supplier_telephone'    => $dataSuppliers['inputSupplierTelephone'],
            'supplier_address'      => $dataSuppliers['inputSupplierAddress'],
            'province_id'           => $dataSuppliers['inputSupplierProvince'],
            'city_id'               => $dataSuppliers['inputSupplierCity'],
            'subdistrict_id'        => $dataSuppliers['inputSupplierSubdistrict'],
        ], ['id' => $dataSuppliers['supplierID']]);
    }

    public function getMaxPurchaseOrder()
    {
        $getMax    = $this->db->query("SELECT MAX(RIGHT(id,4)) AS purchase_order_id FROM purchase_order WHERE DATE(purchase_order_created_at)=CURDATE()")->getRowArray();
        if ($getMax['purchase_order_id'] != NULL) {
            $maxNumber = $getMax['purchase_order_id'] + 1;
            $maxNumber = sprintf("%04s", $maxNumber);
        } else {
            $maxNumber = '0001';
        }
        $branchCode = session()->get('branch_code');
        return date('dmy') . '01' . $branchCode . $maxNumber;
    }

    public function getPurchaseOrder($purchaseOrderID = false)
    {
        if ($purchaseOrderID) {
            return $this->db->table('purchase_order')
                ->select('*, purchase_order.id AS purchaseOrderID')
                ->join('suppliers', 'suppliers.id = purchase_order.supplier_id')
                ->join('employee', 'employee.id = purchase_order.purchase_order_created_by')
                ->getWhere(['purchase_order.purchase_order_invoice' => $purchaseOrderID])->getRowArray();
        } else {
            return $this->db->table('purchase_order')
                ->select('*, purchase_order.id AS purchaseOrderID')
                ->join('suppliers', 'suppliers.id = purchase_order.supplier_id')
                ->join('employee', 'employee.id = purchase_order.purchase_order_created_by')
                ->getWhere(['purchase_order.branch_id' => session()->get('branch_id')])->getResultArray();
        }
    }
    public function getPurchaseOrderBranch($branch = false)
    {
        if ($branch) {
            return $this->db->table('purchase_order')
                ->select('*, purchase_order.id AS purchaseOrderID')
                ->join('suppliers', 'suppliers.id = purchase_order.supplier_id')
                ->join('employee', 'employee.id = purchase_order.purchase_order_created_by')
                ->orderBy('purchase_order_created_at', 'DESC')
                ->getWhere([
                    'branch_id' => $branch
                ])
                ->getResultArray();
        }
        return $this->db->table('purchase_order')
            ->select('*, purchase_order.id AS purchaseOrderID')
            ->join('suppliers', 'suppliers.id = purchase_order.supplier_id')
            ->join('employee', 'employee.id = purchase_order.purchase_order_created_by')
            ->orderBy('purchase_order_created_at', 'DESC')
            ->getWhere([
                'branch_id' => session()->get('branch_id')
            ])->getResultArray();
    }
    public function getPurchaseOrderBranchandMonth($branch = false, $month = false, $years = false)
    {
        if ($branch && $month &&  $years) {
            return $this->db->table('purchase_order')
                ->select('*, purchase_order.id AS purchaseOrderID')
                ->join('suppliers', 'suppliers.id = purchase_order.supplier_id')
                ->join('employee', 'employee.id = purchase_order_created_by')
                ->orderBy('purchase_order_created_at', 'DESC')
                ->getWhere([
                    'branch_id' => $branch,
                    'MONTH(purchase_order_invoice_date)' => short_bulan($month),
                    'YEAR(purchase_order_invoice_date)' =>  $years
                ])->getResultArray();
        } elseif ($month && $years) {
            return $this->db->table('purchase_order')
                ->select('*, purchase_order.id AS purchaseOrderID')
                ->join('suppliers', 'suppliers.id = purchase_order.supplier_id')
                ->join('employee', 'employee.id = purchase_order_created_by')
                ->orderBy('purchase_order_created_at', 'DESC')
                ->getWhere([
                    'MONTH(purchase_order_invoice_date)' => short_bulan($month),
                    'YEAR(purchase_order_invoice_date)' => $years
                ])->getResultArray();
        }
    }
    public function getPurchaseOrderByMonth($month,  $years)
    {
        return $this->db->table('purchase_order')
            ->select('*, purchase_order.id AS purchaseOrderID')
            ->join('suppliers', 'suppliers.id = purchase_order.supplier_id')
            ->join('employee', 'employee.id = purchase_order_created_by')
            ->getWhere([
                'branch_id' => session()->get('branch_id'),
                'MONTH(purchase_order_invoice_date)' => short_bulan($month),
                'YEAR(purchase_order_invoice_date)' =>  $years
            ])->getResultArray();
    }
    public function getPurchaseOrderProduct($purchaseOrderID = false)
    {
        return $this->db->table('purchase_order_product')
            ->select('*, products.id AS productID, purchase_order_product.id AS purchaseOrderProductID')
            ->join('products', 'products.id = purchase_order_product.product_id')
            ->getWhere(['purchase_order_product.purchase_order_invoice' => $purchaseOrderID])->getResultArray();
    }
    public function getPurchaseOrderProductById($purchaseOrderID = false)
    {
        return $this->db->table('purchase_order_product')
            ->select('*, products.id AS productID, purchase_order_product.id AS purchaseOrderProductID')
            ->join('purchase_order', 'purchase_order.purchase_order_invoice = purchase_order_product.purchase_order_invoice')
            ->join('products', 'products.id = purchase_order_product.product_id')
            ->getWhere(['purchase_order.id' => $purchaseOrderID])->getRowArray();
    }
    public function getPurchaseOrderProductByProduct($productid)
    {
        return $this->db->table('purchase_order_product')->getWhere(['product_id' => $productid])->getResultArray();
    }
    public function getPurchaseOrderProductStock($purchaseOrderID, $productID)
    {
        return $this->db->table('purchase_order_product')->getWhere(['purchase_order_invoice' => $purchaseOrderID, 'product_id' => $productID])->getRowArray();
    }
    public function savePurchaseOrder($purchasingData, $purchasingProduct, $total)
    {
        $this->db->transBegin();
        $getMax    = $this->db->table('purchase_order')->selectMax('purchase_order.id')->get()->getRowArray();
        if ($getMax['id'] != NULL) {
            $maxNumber = $getMax['id'] + 1;
            $maxNumber = sprintf("%04s", $maxNumber);
        } else {
            $maxNumber = '0001';
        }
        $branchCode = session()->get('branch_code');
        $purchaseOrderCode =  date('dmy') . '01' . $branchCode . $maxNumber;
        # Insert data pembelian
        $this->db->table('purchase_order')->insert([
            'purchase_order_invoice'        => $purchaseOrderCode,
            'purchase_order_invoice_date'   => $purchasingData['inputTransactionDate'],
            'branch_id'                     => session()->get('branch_id'),
            'supplier_id'                   => $purchasingData['inputSupplier'],
            'purchase_order_cost'           => 0,
            'purchase_order_total'          => $total,
            'purchase_order_status'         => 0,
            'purchase_order_notes'          => $purchasingData['inputNote'],
            'purchase_order_created_by'     => session()->get('user_id'),
            'purchase_order_created_at'     => date('Y-m-d H:i:s')
        ]);

        # Looping jumlah data produk di keranjang
        foreach ($purchasingProduct as $product) {
            $per                = str_replace(" per ", "/", $product['name']);
            $perdua             = str_replace(" perdua ", "/", $per);
            $and                = str_replace(" dan ", "+", $perdua);
            $dandua             = str_replace(" dan2 ", "&", $and);
            $petikdua           = str_replace(" petikdua ", '"', $dandua);
            $petik              = str_replace(" petik ", "'", $petikdua);
            $titikdua           = str_replace(" titikdua ", ":", $petik);
            $garis              = str_replace(" garis ", "|", $titikdua);
            $petikbalik         = str_replace(" petikbalik ", "`", $garis);
            $bebas              = str_replace(" bebas ", "~", $petikbalik);
            $strip              = str_replace(" strip ", "-", $bebas);
            $open               = str_replace(" kurungbuka ", "(", $strip);
            $name               = str_replace(" kurungtutup ", ")", $open);
            # Insert data produk pembelian
            $this->db->table('purchase_order_product')->insert([
                'purchase_order_invoice'        => $purchaseOrderCode,
                'product_id'                    => $product['id'],
                'purchase_order_product_name'   => $name,
                'purchase_order_quantity'       => $product['qty'],
                'purchase_order_received'       => 0,
                'purchase_order_price'          => $product['price']
            ]);
        }
        #Check apakah data product ada, jika tidak masukan inputan baru
        $period = date('Y');
        $initialStockCheck = $this->db->table('stock_initial')->getWhere(['branch_id' => session()->get('branch_id'), 'stock_initial_period' => $period,])->getResultArray();
        if ($initialStockCheck == null) {
            foreach ($initialStockCheck as $product) {
                $this->db->table('stock_initial')->insert([
                    'branch_id'                     => session()->get('branch_id'),
                    'product_id'                    => $product['id'],
                    'stock_initial_period'          => $period,
                    'stock_initial_quantity'        => $product['qty'],
                    'stock_initial_nominal'         => $product['price'],
                    'stock_initial_created_by'      => session()->get('user_id'),
                    'stock_initial_created_at'      => date('Y-m-d H:i:s')
                ]);
            }
        }


        if ($this->db->transStatus() === false) {
            $this->db->transRollback();
            return false;
        } else {
            $this->db->transCommit();
            return true;
        }
    }
    public function updateStatusPurchaseOrder($statusPurchaseOrder)
    {
        # Fungsi untuk update status pembelian => 0 : Request; 1 : Paid;  2 : cancel;
        return $this->db->table('purchase_order')->update([
            'purchase_order_status' => $statusPurchaseOrder['inputPurchaseOrderStatus']
        ], ['id' => $statusPurchaseOrder['idPurchaseOrder']]);
    }
    public function updateProductReceive($ProductReceive)
    {
        $this->db->transBegin();
        foreach ($ProductReceive as $pr) {
            $this->db->table('purchase_order_product')->update([
                'purchase_order_received' => $pr['purchase_order_received']
            ], ['id' => $pr['id']]);
        }
        if ($this->db->transStatus() === false) {
            $this->db->transRollback();
            return false;
        } else {
            $this->db->transCommit();
            return true;
        }
    }
    public function receiveGood($purchaseOrderProduct, $invoice, $period)
    {
        if ($purchaseOrderProduct && $invoice && $period) {
            # FUNGSI untuk terima barang
            $this->db->transBegin();
            # Update jumlah stok di tabel product (total stok seluruh branch)
            $productsStock          = $this->db->table('stock_product')->getWhere(['branch_id' => session()->get('branch_id'), 'product_id' => $purchaseOrderProduct['product_id']])->getRowArray();
            $newAllProductStock     = $productsStock['stock_product_qty_new'] + $purchaseOrderProduct['purchase_order_received'];
            $productsStockBranch1          = $this->db->table('stock_product')->select('stock_product_qty_new')->getWhere(['branch_id' => 1, 'product_id' => $purchaseOrderProduct['product_id']])->getRowArray();
            $productsStockBranch2          = $this->db->table('stock_product')->select('stock_product_qty_new')->getWhere(['branch_id' => 2, 'product_id' => $purchaseOrderProduct['product_id']])->getRowArray();
            $productsStockBranch3          = $this->db->table('stock_product')->select('stock_product_qty_new')->getWhere(['branch_id' => 3, 'product_id' => $purchaseOrderProduct['product_id']])->getRowArray();
            #Update Tabel stock_product
            if ($newAllProductStock <= 0) {
                $newAllProductStock = 0;
            }
            if (session()->get('branch_id') == 1) {
                $newAllStock          = $productsStockBranch2['stock_product_qty_new'] + $productsStockBranch3['stock_product_qty_new'] +  $newAllProductStock;
            } elseif (session()->get('branch_id') == 2) {
                $newAllStock          = $productsStockBranch1['stock_product_qty_new'] + $productsStockBranch3['stock_product_qty_new'] +  $newAllProductStock;
            } else {
                $newAllStock          = $productsStockBranch1['stock_product_qty_new'] + $productsStockBranch2['stock_product_qty_new'] +  $newAllProductStock;
            }
            if ($newAllStock <= 0) {
                $newAllStock = 0;
            }
            $this->db->table('products')->update(['product_stock' => $newAllStock, 'product_updated_at' => date('Y-m-d H:i:s')], ['id' => $purchaseOrderProduct['product_id']]);


            $this->db->table('stock_product')->update(['stock_product_qty_new' => $newAllProductStock], ['branch_id' => session()->get('branch_id'), 'product_id' => $purchaseOrderProduct['product_id']]);
            $this->db->table('stock_initial')->update(['stock_initial_quantity' => $newAllProductStock, 'stock_initial_updated_at' => date('Y-m-d H:i:s')], ['branch_id' => session()->get('branch_id'), 'product_id' => $purchaseOrderProduct['product_id']]);
            #Insert Stock Card

            $this->db->table('stock_card')->insert([
                'branch_id'                 => session()->get('branch_id'),
                'product_id'                => $purchaseOrderProduct['product_id'],
                'sales_id'                  => 'P/O dari supplier',
                'stock_card_income'         => $purchaseOrderProduct['purchase_order_received'],
                'stock_card_created_at'     => date('Y-m-d H:i:s'),
                'stock_card_total'          => $newAllProductStock
            ]);


            if ($this->db->transStatus() === false) {
                $this->db->transRollback();
                return false;
            } else {
                $this->db->transCommit();
                return true;
            }
        } else {
            $this->db->transRollback();
            return false;
        }
    }
    public function getPurchaseReturn($purchaseOrderID = false)
    {
        if ($purchaseOrderID) {
            return $this->db->table('purchase_return')
                ->select('*, purchase_return.id AS purchaseReturnID, branch.id AS branchID')
                ->join('suppliers', 'suppliers.id = purchase_return.supplier_id')
                ->join('employee', 'purchase_return.purchase_return_returned_by = employee.id')
                ->join('branch', 'branch.id = purchase_return.branch_id')
                ->getWhere(['purchase_return_invoice' => $purchaseOrderID])->getRowArray();
        } else {
            return $this->db->table('purchase_return')
                ->select('*, purchase_return.id AS purchaseReturnID, branch.id AS branchID')
                ->join('suppliers', 'suppliers.id = purchase_return.supplier_id')
                ->join('employee', 'purchase_return.purchase_return_returned_by = employee.id')
                ->join('branch', 'branch.id = purchase_return.branch_id')
                ->get()->getResultArray();
        }
    }
    public function getPurchaseReturnProduct($purchaseReturnInvoice = false)
    {
        if ($purchaseReturnInvoice) {
            return $this->db->table('purchase_return_product')
                ->getWhere(['purchase_return_invoice' => $purchaseReturnInvoice])->getResultArray();
        }
    }
    public function savePurchaseReturn($Carts, $dataInput)
    {
        // dd($Carts, $dataInput);
        $this->db->transBegin();
        $getMax    = $this->db->table('purchase_return')->selectMax('purchase_return.id')->get()->getRowArray();
        if ($getMax['id'] != NULL) {
            $maxNumber = $getMax['id'] + 1;
            $maxNumber = sprintf("%04s", $maxNumber);
        } else {
            $maxNumber = '0001';
        }
        $branchCode = session()->get('branch_code');
        $purchaseOrderCode =  date('dmy') . '01' . $branchCode . $maxNumber;
        // dd($purchaseOrderCode);
        $this->db->table('purchase_return')->insert([
            'purchase_return_invoice'               => $purchaseOrderCode,
            'branch_id'                             => session()->get('branch_id'),
            'purchase_return_date_order'            => $dataInput['inputTransactionDate'],
            'supplier_id'                           => $dataInput['inputSupplier'],
            'purchase_return_reason'                => $dataInput['inputNote'],
            'purchase_return_returned_by'           => session()->get('user_id'),
            'purchase_return_returned_at'           => date('Y-m-d H:i:s'),
        ]);
        foreach ($Carts as $cart) {
            if ($cart['qty'] > 0) {
                $per                = str_replace(" per ", "/", $cart['name']);
                $perdua             = str_replace(" perdua ", "/", $per);
                $and                = str_replace(" dan ", "+", $perdua);
                $dandua             = str_replace(" dan2 ", "&", $and);
                $petikdua           = str_replace(" petikdua ", '"', $dandua);
                $petik              = str_replace(" petik ", "'", $petikdua);
                $titikdua           = str_replace(" titikdua ", ":", $petik);
                $garis              = str_replace(" garis ", "|", $titikdua);
                $petikbalik         = str_replace(" petikbalik ", "`", $garis);
                $bebas              = str_replace(" bebas ", "~", $petikbalik);
                $strip              = str_replace(" strip ", "-", $bebas);
                $open               = str_replace(" kurungbuka ", "(", $strip);
                $name               = str_replace(" kurungtutup ", ")", $open);
                $this->db->table('purchase_return_product')->insert([
                    'purchase_return_invoice'               => $purchaseOrderCode,
                    'product_id'                            => $cart['id'],
                    'purchase_return_product_name'          => $name,
                    'purchase_return_qty'                   => $cart['qty'],
                    'purchase_return_product_price'         => $cart['price'],
                ]);
                #update stock product pada table stock_product
                $productStock   = $this->db->table('stock_product')->getWhere(['branch_id' => session()->get('branch_id'), 'product_id' => $cart['id']])->getRowArray();
                $newStock       = $productStock['stock_product_qty_new'] - $cart['qty'];
                if ($newStock < 0) {
                    $newStock = 0;
                }
                $this->db->table('stock_product')->update(['stock_product_qty_new' => $newStock], ['branch_id' => session()->get('branch_id'), 'product_id' => $cart['id']]);

                #update stock product pada table product
                $products       = $this->db->table('products')->getWhere(['id' => $cart['id']])->getRowArray();
                $productsStockBranch1          = $this->db->table('stock_product')->select('stock_product_qty_new')->getWhere(['branch_id' => 1, 'product_id' => $cart['id']])->getRowArray();
                $productsStockBranch2          = $this->db->table('stock_product')->select('stock_product_qty_new')->getWhere(['branch_id' => 2, 'product_id' => $cart['id']])->getRowArray();
                $productsStockBranch3          = $this->db->table('stock_product')->select('stock_product_qty_new')->getWhere(['branch_id' => 3, 'product_id' => $cart['id']])->getRowArray();
                if (session()->get('branch_id') == 1) {
                    $newAllStock          = $productsStockBranch2['stock_product_qty_new'] + $productsStockBranch3['stock_product_qty_new'] +  $newStock;
                } elseif (session()->get('branch_id') == 2) {
                    $newAllStock          = $productsStockBranch1['stock_product_qty_new'] + $productsStockBranch3['stock_product_qty_new'] +  $newStock;
                } elseif (session()->get('branch_id') == 3) {
                    $newAllStock          = $productsStockBranch1['stock_product_qty_new'] + $productsStockBranch2['stock_product_qty_new'] +  $newStock;
                }
                if ($newAllStock <= 0) {
                    $newAllStock = 0;
                }
                $this->db->table('products')->update(['product_stock' => $newAllStock, 'product_updated_at' => date('Y-m-d H:i:s')], ['id' => $cart['id']]);
                $this->db->table('stock_initial')->update(['stock_initial_quantity' => $newAllStock, 'stock_initial_updated_at' => date('Y-m-d H:i:s')], ['branch_id' => session()->get('branch_id'), 'product_id' => $cart['id']]);
                $this->db->table('stock_card')->insert([
                    'branch_id'                 => session()->get('branch_id'),
                    'product_id'                => $cart['id'],
                    'sales_id'                  => 'Retur Barang',
                    'stock_card_outcome'        => $cart['qty'],
                    'stock_card_created_at'     => date('Y-m-d H:i:s'),
                    'stock_card_total'          => $newStock
                ]);
            }
        }
        if ($this->db->transStatus() === false) {
            $this->db->transRollback();
            return false;
        } else {
            $this->db->transCommit();
            return true;
        }
    }
}
