<?= $this->extend('layouts/main'); ?>
<?= $this->section('content'); ?>
<div class="row layout-top-spacing" id="form-row">
	<div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
		<div class="row">
			<div class="col-sm-10">
				<div class="widget-content widget-content-area ">
					<div class="row justify-content-between">
						<div class="col-md-5">
							<div class="form-group ">
								<div class="input-group">
									<input type="text" class="form-control" id="SkuProduct" aria-label="product" aria-describedby="basic-addon2" name="product" autofocus>
									<div class="input-group-append">
										<button class="btn btn-outline-primary" type="button" data-toggle="modal" id="tableProduct" data-target="#listProduct">Daftar Barang</button>
									</div>
								</div>
							</div>
							<br>
							<?php if ($Member) : ?>
								<div class="table-responsive">
									<table class="table text-left">
										<tr>
											<th>Nama Member :</th>
											<td><?= $Member['customer_fullname']; ?></td>
										</tr>
										<tr>
											<th>Alamat :</th>
											<td><?= $Member['customer_address']; ?></td>
										</tr>
										<tr>
											<th>Telepon :</th>
											<td><?= $Member['customer_telephone']; ?></td>
										</tr>
										<tr>
											<th>Total Point :</th>
											<td><?= $Member['customer_points']; ?>
												<?php if ($Member['customer_points'] >= 10000 || $Member['customer_points'] == 10000) : ?>
													<button type="button" class="btn btn-sm btn-primary float-right BtnDiscount" value="1" id="MemberBonus" name="B" data-id="<?= $Member['customer_code']; ?>" onclick="return confirm('Apakah sudah di inputkan semua barang belanjaan?')">Klaim</button>
												<?php endif; ?>
											</td>
										</tr>
									</table>
								</div>
							<?php endif; ?>
						</div>
						<div class="col-md-3 text-center">
							<?php if (1 == session()->get('branch_id')) : ?>
								<img src="<?= base_url('assets/img/logo_cikampek.jpeg'); ?>" alt="Logo Toko" width="70%">
							<?php else : ?>
								<img src="<?= base_url('assets/img/logotoko1.jpeg'); ?>" alt="Logo Toko" width="70%">
							<?php endif; ?>
						</div>
						<div class="col-md-4 text-center table-responsive">
							<table class="table text-left">
								<tr>
									<th>Kasir</th>
									<td> <?= $user['fullname']; ?></td>
								</tr>
								<tr>
									<th>Tanggal</th>
									<td><span id="CloCk"></span></td>
								</tr>
								<tr>
									<th>Alamat</th>
									<td><?= $branch['branch_address']; ?></td>
								</tr>
							</table>
							<input type="hidden" name="inputTransactionDate" value="<?= date('Y-m-d'); ?>">
						</div>
					</div>
					<hr>
					<div class="table-responsive">
						<table class="table table-bordered item-table">
							<thead>
								<tr>
									<th class="">#</th>
									<th>Nama Barang</th>
									<th class="">Harga Satuan</th>
									<th class="text-center">Jumlah</th>
									<th class="text-center">Disc %</th>
									<th class="text-center">Disc (Rp.)</th>
									<th class="text-right">Subtotal</th>
									<th></th>
								</tr>
							</thead>
							<tbody id="detailCart">
							</tbody>
						</table>
					</div>
				</div>
			</div>
			<div class="col-sm-2">
				<div class="widget-content widget-content-area">
					<a href="<?= base_url(); ?>" class="btn btn-dark btn-lg btn-block">Kembali</a>
					<button class="btn btn-danger btn-block btnClose" data-toggle="modal" data-target="#closingTransaction" onclick="return confirm('Apakah Anda yakin untuk menutup transaksi ?')">Tutup Kasir</button>
					<hr>
					<button class="btn btn-secondary btn-block " data-toggle="modal" data-target="#memberModal" id="Cst" <?= ($Member != null) ? 'disabled'  : '' ?>>Member</button>
					<button class="btn btn-info btn-block mb-2" data-toggle="modal" data-target="#FormCreateCustomers">Member Baru</button>
					<button class="btn btn-primary btn-block" data-toggle="modal" data-target="#discountModal">Discount</button>
					<button class="btn btn-outline-warning btn-block mb-2" data-toggle="modal" id="TransactionList" data-target="#transactionModal">Daftar Tunda Transaksi</button>
					<?php if ($Member != null) : ?>
						<form action="<?= base_url('cashier/saveTemp'); ?>" method="post">
							<input type="hidden" name="memberCode" id="memberCode" value="<?= $Member['id']; ?>">
							<button class="btn btn-warning btn-block mb-2 btnTempSave" type="submit" onclick="return confirm('Apakah Anda yakin melakukan tunda transaksi ?')">Tunda Transaksi</button>
						</form>
					<?php else : ?>
						<form action="<?= base_url('cashier/saveTemp'); ?>" method="post">
							<button class="btn btn-warning btn-block mb-2 btnTempSave" type="submit" onclick="return confirm('Apakah Anda yakin melakukan tunda transaksi ?')">Tunda Transaksi</button>
						</form>
					<?php endif; ?>
					<button class="btn btn-outline-dark btn-block mb-2" id="VoidBtn" data-toggle="modal" data-target="#transactionVoidModal">Daftar Void Transaksi</button>
					<button class="btn btn-danger btn-block resetData">Reset</button>
					<button class="btn btn-success btn-block " type="button" id="prosesBtn" style="font-size:25pt;">Proses</button>
				</div>
			</div>
		</div>
	</div>
</div>

<!-- Payment -->
<div class="row layout-top-spacing" id="payment-row" hidden>
	<div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
		<div class="widget-content widget-content-area br-6">
			<div class="row">
				<div class="col-2"></div>
				<div class="col-8">
					<form action="<?= base_url('cashier/save'); ?>" method="post">
						<input type="hidden" id="Invoices" name="Invoices">
						<input type="hidden" id="Tax" name="TotalTax">
						<div class="form-group row">
							<label for="inputPaymentMethod" class="col-sm-3 col-form-label col-form-label-sm">Metode Pembayaran</label>
							<div class="input-group mb-3 col-sm-9">
								<select id="paymentMethod" name="inputPaymentMethod" class="form-control selectpicker" data-live-search="true" required>
									<option value="">-- Pilih Metode Pembayaran --</option>
									<?php foreach ($PaymentMethod as $payment) : ?>
										<option value="<?= $payment['paymentMethodID']; ?>">
											<?php if ($payment['payment_method_code'] == 1) : ?>
												<span>Tunai</span>
											<?php elseif ($payment['payment_method_code'] == 2) : ?>
												<span>Debit</span>
											<?php else : ?>
												<span>Qris</span>
											<?php endif ?> - <?= $payment['payment_method_name']; ?>
										</option>
									<?php endforeach; ?>
								</select>
							</div>
						</div>
						<div class="form-group row" hidden id="cardNumber">
							<label for="inputCardNumber" class="col-sm-3 col-form-label col-form-label-sm">Nomor Kartu</label>
							<div class="input-group mb-3 col-sm-9">
								<input type="number" class="form-control" name="inputCardNumber" id="numberCardInput">
							</div>
						</div>
						<div class="form-group row" hidden id="cardHolder">
							<label for="inputCardHolder" class="col-sm-3 col-form-label col-form-label-sm">Nama Kartu</label>
							<div class="input-group mb-3 col-sm-9">
								<input type="text" class="form-control" name="inputCardHolder" id="holderCardInput">
							</div>
						</div>
						<div class="form-group row" hidden id="TypeQris">
							<label for="typeQris" class="col-sm-3 col-form-label col-form-label-sm">Jenis Qris</label>
							<div class="input-group mb-3 col-sm-9">
								<input type="text" class="form-control" name="typeQris" id="qrisType">
							</div>
						</div>
						<div class="form-group row" hidden id="numberPhone">
							<label for="phoneNumber" class="col-sm-3 col-form-label col-form-label-sm">Nomor Telpon Pelanggan</label>
							<div class="input-group mb-3 col-sm-9">
								<input type="text" class="form-control" name="phoneNumber" id="PhoneNumber">
							</div>
						</div>
						<div class="form-group row">
							<label for="inputDiscount" class="col-sm-3 col-form-label col-form-label-sm" style="font-size:13pt;">Total Diskon</label>
							<div class="input-group mb-3 col-sm-9 text-right">
								<div class="input-group-prepend">
									<span class="input-group-text" id="basic-addon6">Rp.</span>
								</div>
								<input type="text" class="form-control" readonly name="inputDiscount" id="TotalDiscount" style="font-size:15pt; color:black">
							</div>
						</div>
						<div class="form-group row">
							<label for="inputTotalTransaction" class="col-sm-3 col-form-label col-form-label-sm" style="font-size:25pt;">Total Transaksi</label>
							<div class="input-group mb-3 col-sm-9 text-right">
								<div class="input-group-prepend">
									<span class="input-group-text" id="basic-addon6">Rp.</span>
								</div>
								<input type="text" class="form-control" readonly name="inputTotalTransaction" id="TotalTransaksi" style="font-size:38pt; color:black">
							</div>
						</div>
						<div class="form-group row" id="totalCash" hidden>
							<label for="inputTotalCash" class="col-sm-3 col-form-label col-form-label-sm" style="font-size:25pt;">Total Pembayaran</label>
							<div class="input-group mb-3 col-sm-9">
								<div class="input-group-prepend">
									<span class="input-group-text" id="basic-addon6">Rp.</span>
								</div>
								<input type="number" class="form-control " name="inputTotalCash" id="cash" style="font-size:38pt; color:black">
							</div>
						</div>
						<div class="form-group row" id="moneyChange" hidden>
							<label for="inputMoneyBack" class="col-sm-3 col-form-label col-form-label-sm" style="font-size:25pt; ">Kembalian</label>
							<div class="input-group mb-3 col-sm-9">
								<div class="input-group-prepend">
									<span class="input-group-text" id="basic-addon6">Rp.</span>
								</div>
								<input type="text" class="form-control" readonly name="inputMoneyBack" id="moneyBack" style="font-size:38pt; color:black">
							</div>
						</div>
						<hr>
						<div class="text-center">
							<?php if ($Member != null) : ?>
								<input type="hidden" name="memberCode" id="memberCode" value="<?= $Member['id']; ?>">
							<?php endif; ?>
							<input type="hidden" class="form-control" readonly name="grandTotal" id="GrandTotalALL">
							<input type="hidden" class="form-control" readonly name="Cash" id="backMoney">
							<input type="hidden" class="form-control" readonly name="Claim" id="Claimed">
							<button class="btn btn-lg btn-outline-dark " type="button" id="back" style="font-size:18pt;">Kembali</button>
							<button class="btn btn-lg btn-success d-inline" type="submit" id="Print" style="font-size:18pt;">Proses</button>
						</div>
					</form>
				</div>
				<div class="col-2"></div>
			</div>
		</div>
	</div>
</div>


<!-- Modal Product list -->
<div class="modal fade" id="listProduct" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="listProductLabel" aria-hidden="true">
	<div class="modal-dialog modal-xl">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="listProductLabel">Data Barang</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
				<div class="table-responsive">
					<table class="table table-striped tableProduct dataTable" style="width:100%">
						<thead>
							<th>#</th>
							<th>Kategori Barang</th>
							<th>SKU</th>
							<th>Nama Barang</th>
							<th>Harga Barang</th>
							<th>Jumlah</th>
							<th>Aksi</th>
						</thead>
						<tbody>
							<?php
							$i = 1;
							foreach ($Products as $products) : ?>
								<tr>
									<td><?= $i++; ?></td>
									<td><?= $products['product_subdep_name'] ?> </td>
									<td><?= $products['product_sku'] ?> </td>
									<td><?= $products['product_name'] ?> </td>
									<td>Rp. <?= number_format($products['stock_product_selling_price']); ?></td>
									<td><input type="number" min="0" max="<?= $products['stock_product_qty_new']; ?>" name="quantity" id="quantity<?= $products['productID'] ?>" class="form-control" value="1">
									</td>
									<td>
										<button type="submit" class="btn btn-primary btn-sm AddBtn" data-id="<?= $products['productID'] ?>" data-name="<?= $products['product_name'] ?>" data-price="<?= $products['stock_product_selling_price'] ?>" data-sku="<?= $products['product_sku'] ?>">
											<svg xmlns="http://www.w3.org/2000/svg" width="6" height="6" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-plus-circle">
												<circle cx="12" cy="12" r="10"></circle>
												<line x1="12" y1="8" x2="12" y2="16"></line>
												<line x1="8" y1="12" x2="16" y2="12"></line>
											</svg> Tambah </button>
									</td>
								</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>

<!-- CLosing Transaction Modal -->
<div class="modal fade" id="closingTransaction" tabindex="-1" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h3 class="card-title"><b>Tutup Kasir</b> </h3>
			</div>
			<div class="modal-body">
				<div class="row">
					<div class="col-md-6">
						<h4 class="my-3">
							<?= session()->get('branch'); ?>
						</h4>
					</div>
					<div class="col-md-6 text-sm-right">
						<img src="<?= base_url('assets/img/logotoko.jpg'); ?>" alt="Logo Toko" width="50%">
					</div>
				</div>
				<hr>
				<form action="<?= base_url('cashier/closingCash'); ?>" method="post">
					<label for="inputTotalCash">Total Uang Tunai Penutupan</label>
					<div class="input-group mb-3 inputDisc ">
						<div class="input-group-prepend">
							<span class="input-group-text" id="basic-addon6">Rp. </span>
						</div>
						<input type="number" class="form-control " min="0" placeholder="0" name="inputTotalCash" id="inpuTotalCASH" autofocus required>
					</div>
			</div>
			<div class="modal-footer">
				<button type="submit" class="btn btn-primary">Simpan</button>
			</div>
			</form>
		</div>
	</div>
</div>

<!-- Discount Modal -->
<div class="modal fade" id="discountModal" tabindex="-1" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title">Diskon Penjualan</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
				<label for="">Input Persentase Manual Diskon</label>
				<div class="input-group mb-3 inputDisc ">
					<div class="input-group-prepend">
						<span class="input-group-text" id="basic-addon6">%</span>
					</div>
					<input type="number" class="form-control " min="0" placeholder="0" name="inputDiscountPercent" id="Precentage">
				</div>
			</div>
			<div class="modal-footer">
				<button type="submit" data-dismiss="modal" class="btn btn-primary btnDisc">Simpan</button>
			</div>
		</div>
	</div>
</div>


<!-- Member Modal -->
<div class="modal fade" id="memberModal" tabindex="-1" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title">Member</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
				<form action="" method="get">
					<div class="form-group">
						<label for="c">Nama Member</label>
						<select id="Cust" name="c" class="form-control selectpicker" data-live-search="true" required>
							<option selected>Pilih Member...</option>
							<?php foreach ($member as $m) : ?>
								<option value="<?= $m['customer_code']; ?>">
<?= $m['customer_fullname']; ?>
---<?= $m['customer_address']; ?>
---<?= $m['customer_telephone']; ?>
</option>
							<?php endforeach; ?>
						</select>
						<small id="passwordHelpBlock" class="form-text text-muted">
							*Isikan nama member.
						</small>
					</div>
			</div>
			<div class="modal-footer">
				<input type="hidden" id="PRDKID">
				<button type="submit" class="btn btn-primary" id="Member">Pilih</button>
			</div>
			</form>
		</div>
	</div>
</div>

<!-- Trasnaction Void Modal -->
<div class="modal fade" id="transactionVoidModal" tabindex="-1" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true">
	<div class="modal-dialog modal-xl" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title">Daftar Void Transaksi</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
				<div class="table-responsive">
					<table class="table ">
						<thead class="text-center">
							<th>#</th>
							<th>Invoice</th>
							<th>Tanggal Pembatalan</th>
							<th>Status Pembayaran</th>
							<th>Keterangan</th>
						</thead>
						<tbody id="table-Void">
							<tr>
								<td colspan="5" class="text-center">Belum Ada Tunda Transaksi</td>
							</tr>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- Trasnaction Modal -->
<div class="modal fade" id="transactionModal" tabindex="-1" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true">
	<div class="modal-dialog modal-xl" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title">Daftar Tunda Transaksi</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
				<div class="table-responsive">
					<table class="table">
						<thead class="text-center">
							<th>#</th>
							<th>Invoice</th>
							<th>Tanggal</th>
							<th>Status Pembayaran</th>
							<th>Aksi</th>
						</thead>
						<tbody id="table-salesOrder">
							<?php
							if ($SalesOrderCancel) :
								foreach ($SalesOrderCancel as $salesOrder) :
									$i = 1;   ?>
									<tr>
										<td> <?= $i++; ?> </td>
										<td> <?= $salesOrder['sales_order_invoices']; ?> </td>
										<td>
											<?php $prdate = new DateTime($salesOrder['sales_order_created_at']);
											echo $prdate->format('d F Y, H:i'); ?>
										</td>

										<td class="text-center my-3">
											<?php if ($salesOrder['sales_order_status'] == 2) { ?>
												<span class="badge badge-danger"> Dibatalkan </span>
											<?php } elseif ($salesOrder['sales_order_status'] == 0) { ?>
												<span class="badge badge-warning"> Ditunda </span>
											<?php } ?>
										</td>
										<td class="text-center">
											<?php if ($salesOrder['sales_order_status'] == 2) { ?>
												<button type="button" class="btn btn-danger btn-sm" disabled>Transaksi Dibatalkan</button>
											<?php } else { ?>
												<div class=" d-inline my-3">
													<button type="submit" id="inputSalesOrderStatus<?= $salesOrder['id']; ?>" class="btn btn-primary btn-sm my-2 btnContinueTrans" data-salesorder="<?= $salesOrder['id']; ?>">Melanjutkan Transaksi</button>
													<form action="<?= base_url('cashier/cancelOrder'); ?> " method="post">
														<input type="hidden" name="_method" value="DELETE">
														<input type="hidden" name="dataCancelOrder" id="dataCancelOrdER" value="<?= $salesOrder['id']; ?>">
														<button class="btn btn-danger btn-sm my-2" onclick="return confirm('Apakah Anda yakin melakukan cancel transaksi ?')">Batalkan Transaksi</button>
													</form>
												</div>
											<?php } ?>
										</td>
									</tr>';
								<?php endforeach; ?>
							<?php else : ?>
								<tr>
									<td colspan="5" class="text-center">Belum Ada Tunda Transaksi</td>
								</tr>
							<?php endif;  ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>

<div class="modal fade" id="FormCreateCustomers" tabindex="-1" role="dialog" aria-labelledby="FormCreateCustomersLabel" aria-hidden="true">
	<div class="modal-dialog modal-xl" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="FormCreateCustomersLabel">Registrasi Member Baru</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
			</div>
			<div class="modal-body">
				<form action="<?= base_url('cashier/saveCustomers'); ?>" method="post">
					<div class="form-group">
						<label for="inputCustomerFullname">Nama Lengkap Pelanggan</label>
						<input type="text" class="form-control" name="inputCustomerFullname" id="inputCustomerFullname" required>
					</div>
					<div class="row">
						<div class="col-4">
							<div class="form-group">
								<label for="inputCustomerBirthday">Tanggal lahir Pelanggan</label>
								<input type="text" class="form-control flatpickr flatpickr-input basicFlatpickr active" name="inputCustomerBirthday" id="inputCustomerBirthday" required>
							</div>
						</div>
						<div class="col-4">
							<div class="form-group">
								<label for="inputCustomerTelephone">Nomor Telepon Pelanggan</label>
								<input type="text" class="form-control" name="inputCustomerTelephone" id="inputCustomerTelephone" required>
							</div>
						</div>
						<div class="col-4">
							<div class="form-group">
								<label for="inputCustomerEmail">Email Pelanggan</label>
								<input type="text" class="form-control" name="inputCustomerEmail" id="inputCustomerEmail" required>
							</div>
						</div>
					</div>
					<div class="form-group">
						<label for="inputCustomerAddress">Alamat</label>
						<textarea class="form-control" id="inputCustomerAddress" name="inputCustomerAddress"></textarea>
					</div>
					<div class="row">
						<div class="col-4">
							<div class="form-group Province">
								<label for="inputCustomerProvince">Provinsi</label>
								<select id="Province" name="inputCustomerProvince" class="form-control selectpicker provinceID" data-live-search="true" required>
									<option selected>Pilih Provinsi...</option>
									<?php foreach ($Province as $province) : ?>
										<option value="<?= $province['id']; ?>"><?= $province['province_name']; ?></option>
									<?php endforeach; ?>
								</select>
							</div>
						</div>
						<div class="col-4" id="form_City">
							<div class="form-group">
								<label for="inputCustomerCity">Kabupaten/Kota</label>
								<select id="city" name="inputCustomerCity" class="form-control " required>
									<option selected>Pilih Kabupaten/Kota...</option>
								</select>
							</div>
						</div>
						<div class="col-4" id="form_Subdistrict">
							<div class="form-group">
								<label for="inputCustomerSubdistrict">Kecamatan</label>
								<select id="subdistrict" name="inputCustomerSubdistrict" class="form-control" required>
									<option selected>Pilih Kecamatan...</option>
								</select>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-7">
							<div class="form-group">
								<label for="inputCustomerIsActive">Status Member</label>
								<select class="form-control" id="inputCustomerIsActive" name="inputCustomerIsActive">
									<option>Pilih Status Pelanggan....</option>
									<option value="1">Aktif</option>
									<option value="0">Tidak Aktif</option>
								</select>
							</div>
						</div>
					</div>
			</div>
			<div class="modal-footer">
				<div class="d-grid gap-2 mt-3 float-right">
					<button class="btn btn-primary" type="submit" value="2" name="inputan">Simpan Data </button>
				</div>
				</form>
			</div>
		</div>
	</div>
</div>

<script>
	$('document').ready(function() {
		startTime();

		function startTime() {
			var today = new Date();
			var h = today.getHours();
			var m = today.getMinutes();
			var s = today.getSeconds();
			m = checkTime(m);
			s = checkTime(s);
			document.getElementById('CloCk').innerHTML = "<?= date_indo(date('Y-m-d')) ?>, " +
				h + ":" + m + ":" + s;
			var t = setTimeout(startTime, 500);
		}

		function checkTime(i) {
			if (i < 10) {
				i = "0" + i
			}; // add zero in front of numbers < 10
			return i;
		}


		//get data Cart insert to Transaction
		$('#prosesBtn').click(function() {
			if ($('#grandTotal').val() == 0) {
				alert('Masukan Data Barang Terlebih Dahulu');
			} else {

				$('#form-row').attr('hidden', true);
				$('#payment-row').attr('hidden', false);
				let grandTotal = $('#grandTotal').val();
				let discountItem = $('#discountItem').val();
				let discountTotal = $('#discountTotal').val();
				let taxTotal = $('#taxTotal').val();
				let invoices = $('#invoices').val();
				$('#TotalTransaksi').val(grandTotal);
				$('#TotalDiscount').val(discountTotal);
				$('#Invoices').val(invoices);
				$('#Tax').val(taxTotal);
			}
		});

		$('.BtnDiscount').click(function() {
			let ko = $('#MemberBonus').val();
			let total = $('#grandTotal').val();
			if (total >= 10000) {
				if (ko == 1) {
					let member_code = $(this).data("id");
					const row_id = $('#ProdctID').val();
					// console.log(member_code);
					// console.log(row_id);
					$.ajax({
						url: "<?= base_url('cart/updateCashierCartDiscountBonus'); ?>",
						method: "POST",
						type: 'JSON',
						data: {
							rowid: row_id,
							member_code: member_code,
						},
						success: function(result) {
							$('#MemberBonus').attr('disabled', true);
							$('#detailCart').html(result);
							$('#Claimed').val(ko);
						}
					});
				}
			} else {
				alert('Klaim minimal belanja 10rb')
			}
		});
		$('.btnTempSave').click(function() {
			let totalTax = $('#taxTotal').val();
			$('#taxGrandTotal').val(totalTax);

		});
		$('#back').click(function() {
			$('#form-row').attr('hidden', false);
			$('#payment-row').attr('hidden', true);

		});
		$('#paymentMethod').on('change', function() {
			let paymentMethod = $(this).val();
			if (paymentMethod == 1) {
				$('#totalCash').attr('hidden', false);
				$('#cash').attr('required', true);
				$('#cash').focus();
				$('#moneyBack').attr('required', true);
				$('#moneyChange').attr('hidden', false);
				$('#cardNumber').attr('hidden', true);
				$('#numberCardInput').attr('required', false);
				$('#cardHolder').attr('hidden', true);
				$('#holderCardInput').attr('required', false);
				$('#TypeQris').attr('hidden', true);
				$('#qrisType').attr('required', false);
				$('#numberPhone').attr('hidden', true);
				$('#PhoneNumber').attr('required', false);
			} else if (paymentMethod >= 2 && paymentMethod <= 4) {
				$('#cardNumber').attr('hidden', false)
				$('#numberCardInput').attr('required', true)
				$('#cardHolder').attr('hidden', false)
				$('#holderCardInput').attr('required', true)
				$('#totalCash').attr('hidden', true);
				$('#cash').attr('required', false);
				$('#moneyBack').attr('required', false);
				$('#moneyChange').attr('hidden', true);
				$('#TypeQris').attr('hidden', true);
				$('#qrisType').attr('required', false);
				$('#numberPhone').attr('hidden', true);
				$('#PhoneNumber').attr('required', false);
			} else {
				$('#TypeQris').attr('hidden', false);
				$('#qrisType').attr('required', true);
				$('#numberPhone').attr('hidden', false);
				$('#PhoneNumber').attr('required', true);
				$('#totalCash').attr('hidden', true);
				$('#cash').attr('required', false);
				$('#moneyBack').attr('required', false);
				$('#moneyChange').attr('hidden', true);
				$('#cardNumber').attr('hidden', true);
				$('#numberCardInput').attr('required', false);
				$('#cardHolder').attr('hidden', true);
				$('#holderCardInput').attr('required', false);
			}
		});
		//Calculation Cash Back
		$('#totalCash').on('keyup', function() {
			let grandTotal = $('#TotalTransaksi').val();
			let customerCash = $('#cash').val();
			let hitung = customerCash - grandTotal;

			$('#GrandTotalALL').val(customerCash);
			$('#backMoney').val(hitung);
			$('#moneyBack').val(hitung);
		});


		// // Load shopping cart
		$('#detailCart').load("<?= base_url('cart/loadChasierCart'); ?>");

		$('#Cst').click(function() {
			const product = $('#ProdctID').val();
			$('#PRDKID').val(product);
		});
		$('#Member').click(function() {
			const row_id = $('#PRDKID').val();
			const cust = $('#Cust').val();
			$.ajax({
				url: "<?= base_url('cart/updateCashierCartDiscountMember'); ?>",
				method: "POST",
				type: 'JSON',
				data: {
					rowid: row_id,
					customer: cust
				},
				success: function(result) {
					$('#detailCart').html(result);
				}
			});
		});



		//insertCart
		$('.tableProduct').on('click', '.AddBtn', function() {
			const queryString = window.location.search;
			const urlParams = new URLSearchParams(queryString);
			const cust = urlParams.get('c')
			const product_id = $(this).data("id");
			const price = $(this).data("price");
			const sku = $(this).data("sku");
			let quantity = $('#quantity' + product_id).val();
			let str = $(this).data("name");
			let slash = str.replace("/", " per ");
			let slashp = slash.replace("/", " perdua ");
			let and = slashp.replace(/\+/g, " dan ");
			let and2 = and.replace("&", " dan2 ");
			let quotes = and2.replace('"', " petikdua ");
			let quote = quotes.replace("'", " petik ");
			let colon = quote.replace(":", " titikdua ");
			let line = colon.replace("|", " garis ");
			let backtig = line.replace("`", " petikbalik ");
			let free = backtig.replace("~", " bebas ");
			let strip = free.replace("-", " strip ");
			let tag = strip.replace("(", " kurungbuka ");
			let name = tag.replace(")", " kurungtutup ");

			$.ajax({
				url: "<?= base_url('cart/insertChasierCart'); ?>",
				method: "POST",
				type: 'JSON',
				data: {
					id: product_id,
					name: name,
					qty: quantity,
					price: price,
					sku: sku,
					customer: cust
				},
				success: function(result) {
					$('#detailCart').html(result);
					$('#listProduct').modal('hide');

				}
			});
		});

		//DestroyCart
		$(document).on('click', '.resetData', function() {
			const row_id = $(this).attr("id");
			$.ajax({
				url: "<?= base_url('cart/destroyChasierCart'); ?>",
				method: "POST",
				type: 'JSON',
				data: {
					rowid: row_id,
				},
				success: function(result) {
					$('#detailCart').html(result);

					function goBack() {
						window.location.replace("<?= base_url('cashier'); ?>");
					}
					goBack();
				}
			});
		});
		//Remove Cart By Product
		$(document).on('click', '.removeStockChasiertId', function() {
			const row_id = $(this).attr("id");
			$.ajax({
				url: "<?= base_url('cart/removeCartChasier'); ?>",
				method: "POST",
				type: 'JSON',
				data: {
					rowid: row_id,
				},
				success: function(result) {
					$('#detailCart').html(result);
				}
			});
		});

		$('#closingTransaction').on('shown.bs.modal', function() {
			$('#inpuTotalCASH').focus();
		})
		//Update Quantity By Product
		$(document).on('input', '.inputQuantity', function() {
			const row_id = $(this).attr("id");
			let quantity = $(this).val();
			let price = $(this).data('price');
			$.ajax({
				url: "<?= base_url('cart/updateCartChasier'); ?>",
				method: "POST",
				type: 'JSON',
				data: {
					rowid: row_id,
					qty: quantity,
					price: price
				},
				success: function(result) {
					$('#detailCart').html(result);
				}
			});
		});

		//Update Discount By Product
		$(document).on('input', '.inputDiscount', function() {
			const row_id = $(this).attr("id");
			let quantity = $(this).data('qty');
			let price = $(this).data('price');
			let discount = $(this).val();
			$.ajax({
				url: "<?= base_url('cart/updateCartChasierDiscount'); ?>",
				method: "POST",
				type: 'JSON',
				data: {
					rowid: row_id,
					qty: quantity,
					price: price,
					discount: discount
				},
				success: function(result) {
					$('#detailCart').html(result);
				}
			});
		});

		$('.btnDisc').click(function() {
			let discinput = $('#Precentage').val();

			$.ajax({
				url: "<?= base_url('cart/showChasierCart'); ?>",
				method: "POST",
				type: 'JSON',
				data: {
					discountmanual: discinput
				},
				success: function(result) {
					$('#detailCart').html(result);
				}
			});
		});
		$('#tableProduct').click(function() {
			$.ajax({
				url: "<?= base_url('cashier/checkSalesOrder'); ?>",
				method: "POST",
				type: 'JSON',
				success: function(result) {}
			});
			$.ajax({
				url: "<?= base_url('cashier/getDataProduct'); ?>",
				method: "POST",
				type: 'JSON',
				success: function(result) {
					$('#table-product').html(result);
				}
			});
		});
		$('#VoidBtn').click(function() {
			$.ajax({
				url: "<?= base_url('cashier/getVoidTable'); ?>",
				method: "POST",
				type: 'JSON',
				success: function(result) {
					$('#table-Void').html(result);
				}
			});
		});

		//Continue Transaction
		let salesOrderID = $('#dataCancelOrdER').val();
		$('#inputSalesOrderStatus' + salesOrderID).click(function() {
			const salesOrder = $('#dataCancelOrdER').val();
			$('#transactionModal').modal('hide');
			$('#SalesOrderId').val(salesOrder)
			// console.log(salesOrder);
			$.ajax({
				url: "<?= base_url('cart/continueTransaction'); ?>",
				method: "POST",
				type: 'JSON',
				data: {
					sales: salesOrder,
				},
				success: function(result) {
					$('#detailCart').html(result);
				}
			});
		});


		$('#SkuProduct').change(function() {
			let skuProduct = $('#SkuProduct').val();
			const queryString = window.location.search;
			const urlParams = new URLSearchParams(queryString);
			const cust = urlParams.get('c')
			$.ajax({
				url: "<?= base_url('cart/searchProduct'); ?>",
				method: "POST",
				type: 'JSON',
				data: {
					sku: skuProduct,
					customer: cust

				},
				success: function(result) {
					if (result == false) {
						alert('Stok Produk Tidak Tersedia');
					} else {
						$('#detailCart').html(result);
					}
				}
			});
			$('#SkuProduct').val('')
		});
		$('.Province').on('change', ".provinceID", function() {
			const provinsi = $("#Province").val();
			$.ajax({
				url: "<?= base_url('cashier/getCity'); ?>",
				method: "POST",
				type: 'JSON',
				data: {
					province: provinsi,
				},
				success: function(result) {
					$("#city").html(result);
				}
			});
		});
		$('#form_City').on('change', "#city", function() {
			const kota = $("#city").val();
			$.ajax({
				url: "<?= base_url('cashier/getSubdistrict'); ?>",
				method: "POST",
				type: 'JSON',
				data: {
					city: kota,
				},
				success: function(result) {
					$("#subdistrict").html(result);
				}
			});
		});
		$('#Print').click(function() {
			let paymentMethod = $('#paymentMethod').val();
			if (paymentMethod) {
				if (paymentMethod == 1) {
					if ($('#cash').val()) {
						//window.open('<?= base_url('cashier/print'); ?>');
					} else {
						alert("Isikan Jumlah Pembayaran");
					}
				} else if (paymentMethod >= 2 && paymentMethod <= 4) {
					if ($('#holderCardInput').val() && $('#numberCardInput').val()) {
						//	window.open("<?= base_url('cashier/print'); ?>");
					} else {
						alert("Isikan Nomor Kartu dan Nama Kartu");
					}
				} else {
					if ($('#qrisType').val() && $('#PhoneNumber').val()) {
						//	window.open("<?= base_url('cashier/print'); ?>");
					} else {
						alert("Isikan Nomor Jenis Qris dan Nomor Pelanggan");
					}
				}
			} else {
				alert("Isikan Metode Pembayaran");
			}
		});
	});
</script>
<?= $this->endSection(); ?>