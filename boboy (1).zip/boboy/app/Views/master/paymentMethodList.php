<?= $this->extend('layouts/main'); ?>
<?= $this->section('content'); ?>
<div class="row">
	<div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
		<div class="widget-content widget-content-area ">
			<!-- <div class="text-right">
				<button class="btn btn-primary" data-toggle="modal" data-target="#formAddPaymentMethodModal">
					<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-plus-square">
						<rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
						<line x1="12" y1="8" x2="12" y2="16"></line>
						<line x1="8" y1="12" x2="16" y2="12"></line>
					</svg> Tambah Metode Pembayaran</button>
			</div> -->
			<div class="table-responsive">
				<table class="table table-striped dataTable" style="width:100%">
					<thead>
						<th>#</th>
						<th>Kode Metode Pembayaran</th>
						<th>Nama Tipe Pembayaran</th>
						<th>Membutuhkan Bank Penerbit Kartu</th>
						<th>Aksi</th>
					</thead>
					<tbody>
						<?php
						if ($PaymentMethod != null) :
							$i = 1;
							foreach ($PaymentMethod as $paymentmethod) : ?>
								<tr>
									<?php if ($paymentmethod['paymentMethodID'] != 0) : ?>
										<td><?= $i++; ?> </td>
										<td>
											<?php if ($paymentmethod['payment_method_code'] == 1) : ?>
												<span>Tunai</span>
											<?php elseif ($paymentmethod['payment_method_code'] == 2) : ?>
												<span>Debit</span>
											<?php else : ?>
												<span>Qris</span>
											<?php endif ?>
										</td>
										<td><?= $paymentmethod['payment_method_name'] ?> </td>
										<td><?= ($paymentmethod['need_issue'] == 1) ? 'Ya' : 'Tidak'; ?></td>
										<td>
											<button class="btn btn-primary btn-sm btnAdd" data-toggle="modal" data-target="#formUpdatePaymentMethodModal<?= $paymentmethod['paymentMethodID']; ?>">
												<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-edit">
													<path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
													<path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
												</svg> Ubah</button>
											<form action="<?= base_url('paymentMethod/deletePaymentMethod'); ?>" method="post" class="d-inline">
												<input type="hidden" name="paymentMethodID" id="paymentMethodID" value="<?= $paymentmethod['paymentMethodID']; ?>">
												<input type="hidden" name="_method" value="DELETE">
												<button type="submit" class="btn btn-outline-dark btn-sm" onclick="return confirm('Apakah anda yakin mengapus metode Pembayaran <?= $paymentmethod['payment_method_name'] ?>?')">
													<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-trash-2">
														<polyline points="3 6 5 6 21 6"></polyline>
														<path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
														<line x1="10" y1="11" x2="10" y2="17"></line>
														<line x1="14" y1="11" x2="14" y2="17"></line>
													</svg> Hapus</button>
											</form>
										</td>
									<?php endif; ?>
								</tr>
								<!-- Modal Update -->
								<div class="modal fade" id="formUpdatePaymentMethodModal<?= $paymentmethod['paymentMethodID']; ?>" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="formUpdatePaymentMethodModalLabel" aria-hidden="true">
									<div class="modal-dialog modal-lg" role="document">
										<div class="modal-content">
											<div class="modal-header">
												<h5 class="modal-title" id="formUpdatePaymentMethodModalLabel">Ubah Data Barang</h5>
												<button type="button" class="close" data-dismiss="modal" aria-label="Close">
													<span aria-hidden="true">&times;</span>
											</div>
											<div class="modal-body">
												<form action="<?= base_url('paymentMethod/updatePaymentMethod'); ?>" method="post">
													<input type="hidden" name="paymentMethodID" id="paymentmethodID" value="<?= $paymentmethod['paymentMethodID']; ?>">
													<div class="form-group">
														<label for="inputPaymentMethodCode">Kode Metode Pembayaran</label>
														<select id="inputPaymentMethodCode" name="inputPaymentMethodCode" class="form-control" required>
															<option selected>--- Pilih Tipe Pembayaran</option>
															<option value="1" <?= (1 == $paymentmethod['payment_method_code']) ? 'selected' : ''; ?>>Tunai</option>
															<option value="2" <?= (2 == $paymentmethod['payment_method_code']) ? 'selected' : ''; ?>>Debit</option>
															<option value="3" <?= (3 == $paymentmethod['payment_method_code']) ? 'selected' : ''; ?>>Qris</option>
														</select>
													</div>
													<div class="form-group">
														<label for="inputPaymentMethodName">Nama Tipe Pembayaran</label>
														<input type="text" class="form-control" name="inputPaymentMethodName" id="inputPaymentMethodName" value="<?= $paymentmethod['payment_method_name']; ?>" required>
													</div>
													<div class="form-group">
														<span class="new-control-indicator"></span><b>Membutuhkan Bank Penerbit Kartu?</b> <br> <br>
														<div class="form-check form-check-inline">
															<label class="new-control new-checkbox float-right" for="inputNeedIssue1">
																<input type="radio" class="new-check-input" name="inputNeedIssue" id="inputNeedIssue1" value="1" <?= ($paymentmethod['need_issue'] == 1) ? 'Checked' : ''; ?> required>
																<span class="new-control-indicator"></span><b>Membutuhkan</b>
															</label>
														</div>
														<div class="form-check form-check-inline">
															<label class="new-control new-checkbox float-right" for="inputNeedIssue2">
																<input type="radio" class="new-check-input" name="inputNeedIssue" id="inputNeedIssue2" value="0" <?= ($paymentmethod['need_issue'] == 0) ? 'Checked' : ''; ?> required>
																<span class="new-control-indicator"></span><b>Tidak Membutuhkan</b>
															</label>
														</div>
													</div>
													<div class="modal-footer">
														<button class="btn" data-dismiss="modal"><i class="flaticon-cancel-12"></i> Kembali</button>
														<button type="submit" class="btn btn-primary">Simpan</button>
													</div>
												</form>
											</div>
										</div>
									</div>
							<?php endforeach;
						endif; ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
12031502792

<!-- MODAL ADD PAYMENT METHOD -->
<div class="modal fade" id="formAddPaymentMethodModal" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="formAddPaymentMethodModalLabel" aria-hidden="true">
	<div class="modal-dialog modal-lg" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="formAddPaymentMethodModalLabel">Ubah Data Barang</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
			</div>
			<div class="modal-body">
				<form action="<?= base_url('paymentMethod/createPaymentMethod'); ?>" method="post">
					<div class="form-group">
						<label for="inputPaymentMethodCode">Kode Tipe Pembayaran</label>
						<select id="inputPaymentMethodCode" name="inputPaymentMethodCode" class="form-control" required>
							<option selected>--- Pilih Tipe Pembayaran</option>
							<option value="1">Tunai</option>
							<option value="2">Debit</option>
							<option value="3">Qris</option>
						</select>
					</div>
					<div class="form-group">
						<label for="inputPaymentMethodName">Nama Tipe Pembayaran</label>
						<input type="text" class="form-control" name="inputPaymentMethodName" id="inputPaymentMethodName" required>
					</div>
					<span class="new-control-indicator"></span><b>Membutuhkan Bank Penerbit Kartu?</b> <br> <br>
					<div class="form-group">
						<div class="form-check form-check-inline">
							<label class="new-control new-radio radio-primary float-right" for="inputNeedIssue1">
								<input type="radio" class="new-control-input" name="inputNeedIssue" id="inputNeedIssue2" value="1" required>
								<span class="new-control-indicator"></span><b>Membutuhkan</b>
							</label>
						</div>
						<div class="form-check form-check-inline">
							<label class="new-control new-radio radio-primary float-right" for="inputNeedIssue2">
								<input type="radio" class="new-control-input" name="inputNeedIssue" id="inputNeedIssue2" value="0" required>
								<span class="new-control-indicator"></span><b>Tidak Membutuhkan</b>
							</label>
						</div>
					</div>
			</div>
			<div class="modal-footer">
				<button class="btn" data-dismiss="modal"><i class="flaticon-cancel-12"></i> Kembali</button>
				<button type="submit" class="btn btn-primary">Simpan</button>
			</div>
			</form>
		</div>
	</div>
</div>
<?= $this->endSection(); ?>