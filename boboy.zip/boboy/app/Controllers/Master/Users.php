<?php

namespace App\Controllers\Master;

use App\Models\MasterModel;
use App\Controllers\BaseController;
use App\Models\EmployeeModel;

class Users extends BaseController
{
	public function __construct()
	{
		$this->MasterModel = new MasterModel();
		$this->EmployeeModel = new EmployeeModel();
	}
	public function index()
	{
		$data = array_merge($this->data, [
			'category'	=> 'Master',
			'title' 	=> 'Master User',
			'Users'		=> $this->userModel->getUser(),
			'Employee'	=> $this->EmployeeModel->getEmployeeByBranch(session()->get('branch_id')),
			'UserRole'	=> $this->userModel->getUserRole(),
			'Branch'   	=> $this->MasterModel->getBranch(),
			'Province'    	=> $this->MasterModel->getProvince(),
		]);
		return view('master/users/userList', $data);
	}
	public function userRoleAccess()
	{
		$role 		= $this->request->getGet('role');
		$userRole 	= $this->userModel->getUserRole($role);
		if (!$userRole) {
			return redirect()->to(base_url('users'));
		}
		$data = array_merge($this->data, [
			'category'			=> 'Master',
			'title' 			=> 'Master User',
			'MenuCategories'	=> $this->menuModel->getMenuCategory(),
			'Menus'				=> $this->menuModel->getMenu(),
			'Submenus'			=> $this->menuModel->getSubmenu(),
			'UserAccess'		=> $this->userModel->getAccessMenu($role),
			'role'				=> $this->userModel->getUserRole($role),
		]);
		return view('master/users/userAccessList', $data);
	}
	public function createRole()
	{
		$createRole = $this->userModel->createRole($this->request->getPost(null));
		if ($createRole) {
			session()->setFlashdata('notif_success', '<b>Berhasil menambahkan data role</b> ');
			return redirect()->to(base_url('users'));
		} else {
			session()->setFlashdata('notif_error', '<b>Gagal menambahkan data role</b> ');
			return redirect()->to(base_url('users'));
		}
	}
	public function updateRole()
	{
		$updateRole = $this->userModel->updateRole($this->request->getPost(null));
		if ($updateRole) {
			session()->setFlashdata('notif_success', '<b>Berhasil memperbarui data role</b> ');
			return redirect()->to(base_url('users'));
		} else {
			session()->setFlashdata('notif_error', '<b>Gagal memperbarui data role</b> ');
			return redirect()->to(base_url('users'));
		}
	}
	public function deleteRole($role)
	{
		if (!$role) {
			return redirect()->to(base_url('users'));
		}
		$deleteRole = $this->userModel->deleteRole($role);
		if ($deleteRole) {
			session()->setFlashdata('notif_success', '<b>Berhasil menghapus data role</b> ');
			return redirect()->to(base_url('users'));
		} else {
			session()->setFlashdata('notif_error', '<b>Gagal menghapus data role</b> ');
			return redirect()->to(base_url('users'));
		}
	}
	public function createUser()
	{
		if (!$this->validate(['inputUsername' => ['rules' => 'is_unique[users.username]']])) {
			session()->setFlashdata('notif_error', '<b>Failed to add new user</b> The user already exists! ');
			return redirect()->to(base_url('users'));
		}
		$createUser = $this->userModel->createUser($this->request->getPost(null));
		if ($createUser) {
			session()->setFlashdata('notif_success', '<b>Successfully added new user</b> ');
			return redirect()->to(base_url('users'));
		} else {
			session()->setFlashdata('notif_error', '<b>Failed to add new user</b> ');
			return redirect()->to(base_url('users'));
		}
	}
	public function updateUser()
	{
		$updateUser = $this->userModel->updateUser($this->request->getPost(null));
		if ($updateUser) {
			session()->setFlashdata('notif_success', '<b>Successfully update user data</b> ');
			return redirect()->to(base_url('users'));
		} else {
			session()->setFlashdata('notif_error', '<b>Failed to update user data</b> ');
			return redirect()->to(base_url('users'));
		}
	}
	public function deleteUser()
	{
		$userID 	= $this->request->getGet('id');
		$checkUser = $this->userModel->checkUserTransaction($userID);
		if ($checkUser == true) {
			$deleteUser = $this->userModel->deleteUser($userID);
			if ($deleteUser) {
				session()->setFlashdata('notif_success', '<b>Successfully delete user</b> ');
				return redirect()->to(base_url('users'));
			} else {
				session()->setFlashdata('notif_error', '<b>Failed to delete user</b> ');
				return redirect()->to(base_url('users'));
			}
		} else {
			session()->setFlashdata('notif_error', '<b>Gagal menghapus user. User Telah melakukan Transaksi</b> ');
			return redirect()->to(base_url('users'));
		}
	}

	public function changeMenuCategoryPermission()
	{
		$userAccess = $this->userModel->checkUserMenuCategoryAccess($this->request->getPost(null));
		if ($userAccess > 0) {
			$this->userModel->deleteMenuCategoryPermission($this->request->getPost(null));
		} else {
			$this->userModel->insertMenuCategoryPermission($this->request->getPost(null));
		}
	}

	public function changeMenuPermission()
	{
		$userAccess = $this->userModel->checkUserAccess($this->request->getPost(null));
		if ($userAccess > 0) {
			$this->userModel->deleteMenuPermission($this->request->getPost(null));
		} else {
			$this->userModel->insertMenuPermission($this->request->getPost(null));
		}
	}

	public function changeSubMenuPermission()
	{
		$userAccess = $this->userModel->checkUserSubmenuAccess($this->request->getPost(null));
		if ($userAccess > 0) {
			$this->userModel->deleteSubmenuPermission($this->request->getPost(null));
		} else {
			$this->userModel->insertSubmenuPermission($this->request->getPost(null));
		}
	}
	public function saveUsersAccess()
	{
		$menuCategory = $this->request->getPost('menuCategoriId');
		$menu		  = $this->request->getPost('menuID');
		$role_id	  = $this->request->getPost('RoleId');
		return $saveUsersAccess = $this->userModel->saveUsersAccess($menuCategory, $menu, $role_id);
	}
}
