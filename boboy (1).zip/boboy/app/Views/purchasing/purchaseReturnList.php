<?= $this->extend('layouts/main'); ?>
<?= $this->section('content'); ?>
<div class="row layout-top-spacing" id="cancel-row">
    <div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
        <div class="widget-content widget-content-area ">
            <div class="text-right">
                <a href="<?= base_url('purchaseReturn/return'); ?>" class="btn btn-primary">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-plus-square">
                        <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
                        <line x1="12" y1="8" x2="12" y2="16"></line>
                        <line x1="8" y1="12" x2="16" y2="12"></line>
                    </svg> Buat Pengembalian Pembelian</a>
            </div>
            <div class="table-responsive">
                <table class="table table-striped dataTable" style="width:100%">
                    <thead>
                        <tr class="text-center">
                            <th>#</th>
                            <th>Tanggal Pengembalian</th>
                            <th>Invoice</th>
                            <th>Supplier/Cabang</th>
                            <th class="no-content">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 1;
                        foreach ($PurchaseReturn as $return) : ?>
                            <tr class="text-center">
                                <td><?= $i++; ?></td>
                                <td><?php $prdate = new DateTime($return['purchase_return_returned_at']);
                                    echo date_indo($prdate->format('Y-m-d')) . ', ' . $prdate->format('H:i');  ?></td>
                                <td><?= $return['purchase_return_invoice']; ?></td>
                                <td><?= $return['supplier_company']; ?></td>
                                <td>
                                    <a href="<?= base_url('purchaseReturn/detail?id=' . $return['purchase_return_invoice']); ?>" class="btn btn-sm btn-warning btnDetail">Detail Retur Barang</a>
                                    <a href="<?= base_url('purchaseReturn/print?id=' . $return['purchase_return_invoice']); ?>" class="btn btn-sm btn-info ">Print Surat Jalan</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection(); ?>