<?php

namespace App\Controllers\Master;

use App\Controllers\BaseController;
// use App\Models\DataTableModel;
use App\Models\MasterModel;
use DateTime;
use \Hermawan\DataTables\DataTable;

class Products extends BaseController
{
	function __construct()
	{
		$this->MasterModel = new MasterModel();
		// $this->DataTableModel = new DataTableModel;
	}
	public function index()
	{
		$data = array_merge($this->data, [
			'category'			 		=> 'Master',
			'title'        		 		=> 'Halaman Kategori Barang',
			'ProductDivisi'    			=> $this->MasterModel->getProductDivisi(),
			'ProductDepartment'    		=> $this->MasterModel->getProductDepartment(),
			'CodeDepartment'			=> $this->MasterModel->getMaxCodeDepartment(),
			'ProductSubdepartment'    	=> $this->MasterModel->getProductSubdepartment(),
		]);
		return view('master/productCategoryList', $data);
	}

	public function printBarcodeProduct()
	{
		$p = $this->request->getGet('p');
		if ($p) {
			$pr = $p;
		} else {
			$pr = null;
		}
		$productID	= $this->request->getGet('productID');
		$print	= $this->request->getGet('total');
		$barcode =  new \Picqer\Barcode\BarcodeGeneratorSVG();
		$data = array_merge($this->data, [
			'Product'					=> $this->MasterModel->getProducts($productID),
			'Print'						=> $print,
			'barcode'					=> $barcode,
			'no'						=> 1,
			'p'							=> $pr
		]);
		return view('master/printBarcodeProduct', $data);
	}
	public function createProduct()
	{
		$data = array_merge($this->data, [
			'category'			 		=> 'Laporan',
			'title'        		 		=> 'Buat Barang baru',
			'Branch'    				=> $this->MasterModel->getBranch(),
			'ProductSubdepartment'    	=> $this->MasterModel->getProductSubdepartment(),
		]);
		return view('master/productFormCreate', $data);
	}
	public function saveProduct()
	{
		if (!$this->validate([
			'inputName' => [
				'rules'     => 'required|is_unique[products.product_name]',
			],
			'inputCategory' => [
				'rules'     => 'required',
			],
			'inputPurchasePrice' => [
				'rules'     => 'required',
			],
			'inputSellingPrice' => [
				'rules'     => 'required',
			],
		])) {
			session()->setFlashdata('notif_error', '<b>Gagal menambah produk, nama tidak boleh sama </b>');
			return redirect()->to(base_url('product/formCreate'));
		}

		$createProduct = $this->MasterModel->createProducts($this->request->getPost(null));
		if ($createProduct) {
			session()->setFlashdata('notif_success', '<b>Berhasil menambah product Baru </b>');
			return redirect()->to(base_url('product'));
		} else {
			session()->setFlashdata('notif_error', '<b>Gagal menambah produk Baru </b>');
			return redirect()->to(base_url('product'));
		}
	}
	public function updateProduct()
	{
		$productID = $this->request->getPost('productID');
		if (!$this->validate([
			'inputName' => [
				'rules'     => 'required',
			],
			'inputCategory' => [
				'rules'     => 'required',
			],
			'inputSKU' => [
				'rules'     => 'required|numeric',
			],
			'inputPurchasePrice' => [
				'rules'     => 'required',
			],
			'inputSellingPrice' => [
				'rules'     => 'required',
			],
		])) {
			session()->setFlashdata('notif_error', '<b>Gagal menambah produk, nama tidak boleh sama </b>');
			return redirect()->to(base_url('product/saveUpdateProduct?id=' . $productID));
		}
		$updateProduct = $this->MasterModel->updateProducts($this->request->getPost(null));
		if ($updateProduct) {
			session()->setFlashdata('notif_success', '<b>Berhasil update Product </b>');
			return redirect()->to(base_url('product'));
		} else {
			session()->setFlashdata('notif_error', '<b>Failed to update Product </b>');
			return redirect()->to(base_url('product/saveUpdateProduct?id=' . $productID));
		}
	}
	public function deleteProducts()
	{
		$deleteProduct = $this->MasterModel->deleteProducts($this->request->getPost('productID'));
		if ($deleteProduct) {
			session()->setFlashdata('notif_success', '<b>Berhasil delete Product </b>');
			return redirect()->to(base_url('product'));
		} else {
			session()->setFlashdata('notif_error', '<b>Failed to delete Product </b>');
			return redirect()->to(base_url('product'));
		}
	}
	public function createProductDivisi()
	{
		if (!$this->validate([
			'inputProductDivisiName' => [
				'rules'     => 'is_unique[product_divisi.product_divisi_name]',
			]
		])) {
			session()->setFlashdata('notif_error', '<b>Gagal membuat Divisi, nama tidak boleh sama </b>');
			return redirect()->to(base_url('productCategory'));
		}
		$createProductDivisi = $this->MasterModel->createProductDivisi($this->request->getPost(null));
		if ($createProductDivisi) {
			session()->setFlashdata('notif_success', '<b>Berhasil menambah product Divisi Baru </b>');
			return redirect()->to(base_url('productCategory'));
		} else {
			session()->setFlashdata('notif_error', '<b>Failed to add product Divisi Baru </b>');
			return redirect()->to(base_url('productCategory'));
		}
	}
	public function updateProductDivisi()
	{
		$updateProductDivisi = $this->MasterModel->updateProductDivisi($this->request->getPost(null));
		if ($updateProductDivisi) {
			session()->setFlashdata('notif_success', '<b>Berhasil update Product Divisi</b>');
			return redirect()->to(base_url('productCategory'));
		} else {
			session()->setFlashdata('notif_error', '<b>Failed to update Product Divisi</b>');
			return redirect()->to(base_url('productCategory'));
		}
	}
	public function deleteProductDivisi()
	{
		$deleteProductDivisi = $this->MasterModel->deleteProductDivisi($this->request->getPost('divisiID'));
		if ($deleteProductDivisi) {
			session()->setFlashdata('notif_success', '<b>Berhasil menghapus Product Divisi</b>');
			return redirect()->to(base_url('productCategory'));
		} else {
			session()->setFlashdata('notif_error', '<b>Gagal menghapus data, data berkaitan dengan produk divisi</b>');
			return redirect()->to(base_url('productCategory'));
		}
	}
	public function createProductDepartment()
	{
		if (!$this->validate([
			'inputProductDepartmentName' => [
				'rules'     => 'is_unique[product_department.product_department_name]',
			]

		])) {
			session()->setFlashdata('notif_error', '<b>Gagal membuat Department, nama tidak boleh sama </b>');
			return redirect()->to(base_url('productCategory'));
		}
		$createProductDepartment = $this->MasterModel->createProductDepartment($this->request->getPost(null));
		if ($createProductDepartment) {
			session()->setFlashdata('notif_success', '<b>Berhasil menambah product Department Baru </b>');
			return redirect()->to(base_url('productCategory'));
		} else {
			session()->setFlashdata('notif_error', '<b>Gagal Menambah product Department Baru </b>');
			return redirect()->to(base_url('productCategory'));
		}
	}
	public function updateProductDepartment()
	{
		$updateProductDepartment = $this->MasterModel->updateProductDepartment($this->request->getPost(null));
		if ($updateProductDepartment) {
			session()->setFlashdata('notif_success', '<b>Berhasil update Product Department</b>');
			return redirect()->to(base_url('productCategory'));
		} else {
			session()->setFlashdata('notif_error', '<b>Gagal memperbarui Product Department</b>');
			return redirect()->to(base_url('productCategory'));
		}
	}
	public function deleteProductDepartment()
	{
		$deleteProductDepartment = $this->MasterModel->deleteProductDepartment($this->request->getPost('departmentID'));
		if ($deleteProductDepartment) {
			session()->setFlashdata('notif_success', '<b>Berhasil delete Product Department</b>');
			return redirect()->to(base_url('productCategory'));
		} else {
			session()->setFlashdata('notif_error', '<b>Gagal menghapus data, data berkaitan dengan produk department</b>');
			return redirect()->to(base_url('productCategory'));
		}
	}
	public function createProductSubDepartment()
	{
		if (!$this->validate([
			'inputProductSubdepName' => [
				'rules'     => 'is_unique[product_subdepartment.product_subdep_name]',
			]
		])) {
			session()->setFlashdata('notif_error', '<b>Gagal membuat Department, nama tidak boleh sama </b>');
			return redirect()->to(base_url('productCategory'));
		}
		$createProductSubDepartment = $this->MasterModel->createProductSubDepartment($this->request->getPost(null));
		if ($createProductSubDepartment) {
			session()->setFlashdata('notif_success', '<b>Berhasil menambah product SubDepartment Baru </b>');
			return redirect()->to(base_url('productCategory'));
		} else {
			session()->setFlashdata('notif_error', '<b>Gagal menambah product SubDepartment Baru </b>');
			return redirect()->to(base_url('productCategory'));
		}
	}
	public function updateProductSubDepartment()
	{
		$updateProductSubDepartment = $this->MasterModel->updateProductSubDepartment($this->request->getPost(null));
		if ($updateProductSubDepartment) {
			session()->setFlashdata('notif_success', '<b>Berhasil update Product SubDepartment</b>');
			return redirect()->to(base_url('productCategory'));
		} else {
			session()->setFlashdata('notif_error', '<b>Gagal memperbarui Product SubDepartment</b>');
			return redirect()->to(base_url('productCategory'));
		}
	}
	public function deleteProductSubDepartment()
	{
		$deleteProductSubDepartment = $this->MasterModel->deleteProductSubDepartment($this->request->getPost('subdepartmentID'));
		if ($deleteProductSubDepartment) {
			session()->setFlashdata('notif_success', '<b>Berhasil delete Product SubDepartment</b>');
			return redirect()->to(base_url('productCategory'));
		} else {
			session()->setFlashdata('notif_error', '<b>Gagal menghapus data, data berkaitan dengan produk subdepartment lain</b>');
			return redirect()->to(base_url('productCategory'));
		}
	}
	public function product()
	{
		$data = array_merge($this->data, [
			'category'					=> 'Master',
			'title'         			=> 'Halaman Data Barang',
			'ProductSubdepartment'    	=> $this->MasterModel->getProductSubDepartment(),
		]);
		return view('master/productList', $data);
	}

	public function productAjax()
	{
		if ($this->request->isAJAX()) {
			$getProducts = $this->MasterModel->getProduct();
			return DataTable::of($getProducts)
				->format('product_purchase_price', function ($value) {
					return 'Rp. ' . number_format($value);
				})
				->format('product_selling_price', function ($value) {
					return 'Rp. ' . number_format($value);
				})
				->format('product_created_at', function ($value) {
					$prdate = new DateTime($value);
					return date_indo($prdate->format('Y-m-d'));
				})
				->format('product_updated_at', function ($value) {
					$prdate = new DateTime($value);
					return date_indo($prdate->format('Y-m-d'));
				})
				->add('action', function ($listProduct) {
					return
						'<div class="btn-group mr-2">
							<a href=" ' . base_url('product/saveUpdateProduct?id=') . $listProduct->productID  . '" class="btn btn-outline-primary btnUpdt">
                  			  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-edit text-primary">
                  			      <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                  			      <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                  			  </svg> Ubah
                			</a>
							<form action=" ' . base_url('product/deleteProducts') . ' " method="post" class="d-inline">
								<input type="hidden" name="productID" id="productID" value=" ' . $listProduct->productID . ' ">
								<input type="hidden" name="_method" value="DELETE">
								<button type="submit" class="btn btn-outline-danger" onclick="return confirm(" Apakah anda yakin mengapus ' . $listProduct->product_name . ' ? ")">
									<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-trash-2 text-danger">
										<polyline points="3 6 5 6 21 6"></polyline>
										<path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
										<line x1="10" y1="11" x2="10" y2="17"></line>
										<line x1="14" y1="11" x2="14" y2="17"></line>
									</svg> Hapus
								</button>
							</form>
						</div>';
				})
				->toJson(true);
		}
	}
	public function saveUpdateProduct()
	{
		$product = $this->request->getGet('id');
		$data = array_merge($this->data, [
			'category'			 		=> 'Master',
			'title'        		 		=> 'Halaman Update Barang',
			'Product'    				=> $this->MasterModel->getProducts($product),
			'ProductSubdepartment'    	=> $this->MasterModel->getProductSubDepartment(),

		]);
		return view('master/productUpdate', $data);
	}
	// public function saveUpdateStockProduct()
	// {
	// 	$product = $this->request->getGet('id');
	// 	$branch = $this->request->getGet('b');
	// 	$data = array_merge($this->data, [
	// 		'category'			 		=> 'Master',
	// 		'title'        		 		=> 'Halaman Update Barang',
	// 		'Product'    				=> $this->MasterModel->getStockProduct($product, $branch),
	// 		'ProductSubdepartment'    	=> $this->MasterModel->getProductSubDepartment(),
	// 		'branch'					=> $branch
	// 	]);
	// 	return view('report/productStockUpdate', $data);
	// }
	// public function updateProductStock()
	// {
	// 	$updateProduct = $this->MasterModel->updateProducts($this->request->getPost(null));
	// 	if ($updateProduct) {
	// 		session()->setFlashdata('notif_success', '<b>Berhasil update Product </b>');
	// 		return redirect()->to(base_url('branchStock'));
	// 	} else {
	// 		session()->setFlashdata('notif_error', '<b>Failed to update Product </b>');
	// 		return redirect()->to(base_url('branchStock'));
	// 	}
	// }
}
