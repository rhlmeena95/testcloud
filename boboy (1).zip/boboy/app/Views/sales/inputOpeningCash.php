<?= $this->extend('layouts/main'); ?>
<?= $this->section('content'); ?>
<div class="d-flex justify-content-center">
    <div class="col-6  mt-5">
        <div class="card">
            <div class="card-header">
                <div class="row">
                    <div class="col text-center">
                        <h3 class="card-title"><b>Modal Awal Kasir</b> </h3>
                        <h4> <?= session()->get('branch'); ?> </h4>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <form action="<?= base_url('cashier/saveOpeningCash'); ?>" method="post">
                    <label for="inputOpeningCash">Input Modal Awal</label>
                    <div class="input-group mb-3 ">
                        <div class="input-group-prepend">
                            <span class="input-group-text" id="basic-addon6">Rp.</span>
                        </div>
                        <input type="number" class="form-control " min="0" placeholder="0" name="inputOpeningCash" id="CashOpening">
                    </div>
                    <hr>
                    <div class="float-right">
                        <a href="<?= base_url('/'); ?>" class="btn btn-light">Kembali</a>
                        <button type="submit" data-dismiss="modal" id="Saved" class="btn btn-primary">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        $('#CashOpening').focus();
    });
</script>

<?= $this->endSection(); ?>