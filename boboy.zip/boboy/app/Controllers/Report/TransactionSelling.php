<?php

namespace App\Controllers\Report;

use App\Controllers\BaseController;
use App\Models\MasterModel;
use App\Models\SalesModel;

class TransactionSelling extends BaseController
{
	function __construct()
	{
		$this->SalesModel = new SalesModel();
		$this->MasterModel = new MasterModel();
	}
	public function index()
	{
		$branch = $this->request->getGet('branch');
		$month = $this->request->getGet('m');
		$years = $this->request->getGet('y');

		if ($branch && $month) {
			$Sales = $this->SalesModel->getSalesOrderByBranchandMonth($branch, $month, $years);
			$TotalTransaction = $this->SalesModel->getSalesTotalByBranchandMonth($branch, $month, $years);
			$totalDiscount = $this->SalesModel->getSumDiscount($branch, $month, $years);
		} else {
			$Sales = null;
			$TotalTransaction = null;
			$totalDiscount = null;
		}
		$data = array_merge($this->data, [
			'category'      	=> 'Laporan',
			'title'         	=> 'Transaksi Penjualan',
			'SalesOrder'		=> $Sales,
			'Branch'    		=> $this->MasterModel->getBranch(),
			'TotalTransaction'	=> $TotalTransaction,
			'inputBranch'		=> $branch,
			'totalDiscount'		=> $totalDiscount,
			'month'				=> $month,
			'years'				=> $years,
			'yearsNow'			=> date('Y')
		]);
		return view('report/transactionSelling', $data);
	}
	public function product()
	{
		$branch = $this->request->getGet('branch');
		$month = $this->request->getGet('m');
		$years = $this->request->getGet('y');

		if ($branch && $month) {
			$Sales = $this->SalesModel->getSalesOrderProductByBranchandMonth($branch, $month, $years);
		} elseif ($month) {
			$Sales = $this->SalesModel->getSalesOrderProductByMonth($month, $years);
		} else {
			$Sales = null;
		}
		$data = array_merge($this->data, [
			'category'      	=> 'Laporan',
			'title'         	=> 'Transaksi Penjualan',
			'SalesOrder'		=> $Sales,
			'Branch'    		=> $this->MasterModel->getBranch(),
			'inputBranch'		=> $branch,
			'month'				=> $month,
			'years'				=> $years,
			'yearsNow'			=> date('Y')
		]);
		return view('report/transactionSellingProduct', $data);
	}


	public function updateTaxType()
	{
		$invoice = $this->request->getPost('invoice');
		$tax =  $this->request->getPost('taxType');
		$updateTaxType = $this->SalesModel->updateTaxType($invoice, $tax);

		return redirect()->to(base_url('transactionSelling'));
	}
}
