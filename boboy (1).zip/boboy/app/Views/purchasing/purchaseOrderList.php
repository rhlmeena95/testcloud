<?= $this->extend('layouts/main'); ?>
<?= $this->section('content'); ?>

<div class="row layout-top-spacing" id="cancel-row">
    <div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
        <div class="widget-content widget-content-area">
            <?php if (1 == session()->get('branch_id')) : ?>
                <form action="<?= base_url('purchaseOrder'); ?>" method="get">
                    <div class="row">
                        <div class="col-sm-6"></div>
                        <div class="col-sm-6">
                            <div class="input-group">
                                <select class="custom-select" id="branch" name="branch" <?= (1 != session()->get('branch_id')) ? 'disabled' : ''; ?>>
                                    <option value="">-- Pilih Cabang -- </option>
                                    <?php foreach ($Branch as $branch) : ?>
                                        <option value="<?= $branch['branchID']; ?>" <?= ($inputBranch == $branch['branchID']) ? 'selected' : ''; ?>><?= $branch['branch_name']; ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <div class="input-group-append">
                                    <button type="submit" class="btn btn-primary">Lihat Data</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            <?php else : ?>
                <h2>Daftar Purchase Order Cabang <?= session()->get('branch'); ?></h2>
                <br>
            <?php endif; ?>
            <br>
            <div class="table-responsive">
                <table class="table table-striped dataTable" style="width:100%">
                    <thead>
                        <tr class="text-center">
                            <th>#</th>
                            <th>Tanggal</th>
                            <th>Invoice</th>
                            <th>Supplier</th>
                            <th class="no-content">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1;
                        foreach ($PurchaseOrders as $purchaseOrder) :
                        ?>
                            <tr>
                                <td class="text-center"><?= $no++ ?> </td>
                                <td class="text-center"><?php $prdate = new DateTime($purchaseOrder['purchase_order_created_at']);
                                                        echo date_indo($prdate->format('Y-m-d')) . ', ' . $prdate->format('H:i');  ?>
                                </td>
                                <td class="text-center"><?= $purchaseOrder['purchase_order_invoice'] ?> </td>
                                <td class="text-center"><?= $purchaseOrder['supplier_company'] ?> </td>
                                <td>
                                    <a class="btn btn-primary" href="<?= base_url('purchaseOrder/detail?id=' . $purchaseOrder['purchase_order_invoice']); ?> ">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-zoom-in">
                                            <circle cx="11" cy="11" r="8"></circle>
                                            <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                                            <line x1="11" y1="8" x2="11" y2="14"></line>
                                            <line x1="8" y1="11" x2="14" y2="11"></line>
                                        </svg> Detail</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection(); ?>