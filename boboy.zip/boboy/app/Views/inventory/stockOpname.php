<?= $this->extend('layouts/main'); ?>
<?= $this->section('content'); ?>

<div class="row">
    <div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
        <div class="widget-content widget-content-area br-6">
            <?php if (1 == session()->get('branch_id')) : ?>
                <form action="<?= base_url('stockOpname'); ?>" method="get">
                    <div class="row">
                        <div class="col-sm-4"></div>
                        <div class="col-sm-8">
                            <div class="input-group">
                                <select class="custom-select" id="branch" name="branch" <?= (1 != session()->get('branch_id')) ? 'disabled' : ''; ?>>
                                    <option value="">-- Pilih Cabang -- </option>
                                    <?php foreach ($Branch as $branch) : ?>
                                        <option value="<?= $branch['branchID']; ?>" <?= ($inputBranch == $branch['branchID']) ? 'selected' : ''; ?>><?= $branch['branch_name']; ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <select class="custom-select" id="subdepartment" name="sd">
                                    <option value="">-- Pilih Kategori -- </option>
                                    <?php foreach ($Subdepartment as $subdepartment) : ?>
                                        <option value="<?= $subdepartment['product_subdep_code']; ?>" <?= ($inputSubdepartment == $subdepartment['product_subdep_code']) ? 'selected' : ''; ?>><?= $subdepartment['product_subdep_name']; ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <div class="input-group-append">
                                    <button type="submit" class="btn btn-primary">Lihat Data</button>
                                    <a href="<?= base_url('stockOpname/history'); ?>" type="button" class="btn btn-outline-primary">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-archive">
                                            <polyline points="21 8 21 21 3 21 3 8"></polyline>
                                            <rect x="1" y="3" width="22" height="5"></rect>
                                            <line x1="10" y1="12" x2="14" y2="12"></line>
                                        </svg>
                                        Riwayat Stock Opname
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            <?php else : ?>
                <form action="<?= base_url('stockOpname'); ?>" method="get">
                    <div class="row">
                        <div class="col-sm-4"></div>
                        <div class="col-sm-8">
                            <div class="input-group">
                                <input type="hidden" name="branch" value="<?= session()->get('branch_id'); ?>">
                                <select class="custom-select" id="subdepartment" name="sd">
                                    <option value="">-- Pilih Kategori -- </option>
                                    <?php foreach ($Subdepartment as $subdepartment) : ?>
                                        <option value="<?= $subdepartment['product_subdep_code']; ?>" <?= ($inputSubdepartment == $subdepartment['product_subdep_code']) ? 'selected' : ''; ?>><?= $subdepartment['product_subdep_name']; ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <div class="input-group-append">
                                    <button type="submit" class="btn btn-primary">Lihat Data</button>
                                    <a href="<?= base_url('stockOpname/history'); ?>" type="button" class="btn btn-outline-primary">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-archive">
                                            <polyline points="21 8 21 21 3 21 3 8"></polyline>
                                            <rect x="1" y="3" width="22" height="5"></rect>
                                            <line x1="10" y1="12" x2="14" y2="12"></line>
                                        </svg>
                                        Riwayat Stock Opname
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            <?php endif; ?>
            <br>
            <div class="table-responsive">
                <table class="table table-striped dataTable" style="width:100%">
                    <thead>
                        <th>#</th>
                        <th>SKU</th>
                        <th>Kategori Barang</th>
                        <th>Nama Barang</th>
                        <th>Stok Fisik</th>
                        <!-- <th>Stok Gudang</th> -->
                        <!-- <th class="text-center">Keterangan</th> -->
                        <th class="text-center">Aksi</th>
                    </thead>
                    <tbody>
                        <?php
                        $i = 1;
                        if ($StockProduct != null) :
                            foreach ($StockProduct as $stockProduct) : ?>
                                <tr>
                                    <input type="hidden" name="ProductId" value="<?= $stockProduct['product_id']; ?>">
                                    <td><?= $i++; ?></td>
                                    <td><?= $stockProduct['product_sku'] ?> </td>
                                    <td class="text-wrap"><?= $stockProduct['product_subdep_name'] ?> </td>
                                    <td class="text-wrap"><?= $stockProduct['stock_product_name'] ?> </td>
                                    <input type="hidden" id="Stock<?= $stockProduct['product_id']; ?>">
                                    <!-- <td>
                                        <div class="form-group">
                                            <input type="number" min="0" class="form-control" name="InputStockDisplay" id="InputStockDisplay<?= $stockProduct['product_id']; ?>" value="0" required>
                                        </div>
                                    </td> -->
                                    <td>
                                        <div class="form-group">
                                            <input type="number" min="0" class="form-control inputStorage" data-id="<?= $stockProduct['product_id']; ?>" name="InputStockStorage" id="InputStockStorage<?= $stockProduct['product_id']; ?>" value="0" required>
                                        </div>
                                    </td>
                                    <!-- <td>
                                        <div class="form-group">
                                            <textarea class="form-control" id="inputNotes" name="inputNotes" rows="5" cols="40" required></textarea>
                                        </div>
                                    </td> -->
                                    <td>
                                        <button class="btn btn-primary btnUpdate" type="button" data-toggle="modal" data-target="#udpateStock" data-id="<?= $stockProduct['product_id']; ?>" data-stock="<?= $stockProduct['stock_product_qty_new']; ?>">Update</button>
                                        <button class="btn btn-warning btnHistory" type="button" data-toggle="modal" data-target="#historyLastUpdated" data-id="<?= $stockProduct['product_id']; ?>">Riwayat</button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else : ?>
                            <tr>
                                <td colspan="10" class="text-center">Tidak Ada Produk</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="historyLastUpdated" tabindex="-1" role="dialog" aria-labelledby="historyLastUpdatedLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="historyLastUpdatedLabel">Riwayat StockOpname</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
            </div>
            <div class="modal-body">
                <div class="table-responsive">
                    <table class="table table-striped dataTable" style="width:100%">
                        <thead>
                            <th>#</th>
                            <th>Nama Barang</th>
                            <th>Stok Display</th>
                            <th>Stok Gudang</th>
                            <th>Selisih</th>
                            <th>Mengubah Stock</th>
                            <th class="text-center">Keterangan</th>
                            <th>Terakhir Update</th>
                        </thead>
                        <tbody id="tableStockOpname">
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-dark" data-dismiss="modal"><i class="flaticon-cancel-12"></i> Tutup</button>
            </div>
        </div>
    </div>
</div>
<!-- Modal -->
<div class="modal fade" id="udpateStock" tabindex="-1" role="dialog" aria-labelledby="udpateStockLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="udpateStockLabel">Riwayat StockOpname</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
            </div>
            <div class="modal-body">
                <form action="<?= base_url('stockOpname/save'); ?>" method="post">
                    <input type="hidden" class="form-control" name="productId" id="IdProduct" readonly>
                    <input type="hidden" class="form-control" name="totalstock" id="StockTotal" readonly>
                    <input type="hidden" class="form-control" name="display" id="StockDisplay" readonly>
                    <input type="hidden" class="form-control" name="storage" id="StockStorage" readonly>
                    <div class="form-group">
                        <span>Keterangan</span><br>
                        <textarea class="form-control" id="inputNotes<?= $stockProduct['product_id']; ?>" name="inputNotes" rows="5" cols="40" required>-</textarea>
                    </div>
                    <div class="text-center mt-3">
                        <span>Ingin Mengubah Stock Cabang?</span><br>
                        <button class="btn btn-primary" type="submit" name="param" value="1">Ya</button>
                        <button class="btn btn-light" type="submit" name="param" value="0">Tidak</button>
                    </div>
                </form>
            </div>
            <!-- <div class="modal-footer">
                <button class="btn btn-dark" data-dismiss="modal"><i class="flaticon-cancel-12"></i> Tutup</button>
            </div> -->
        </div>
    </div>
</div>
<script>
    $('.btnHistory').click(function() {
        const product_id = $(this).data("id");
        $.ajax({
            url: "<?= base_url('stockOpname/tableHistory'); ?>",
            method: "POST",
            type: 'JSON',
            data: {
                product_id: product_id,
            },
            success: function(result) {
                $('#tableStockOpname').html(result);
            }
        });
    });
    $('.btnUpdate').click(function() {
        let product_id = $(this).data("id");
        let stock = $(this).data("stock");
        let stockNew = $('#InputStockDisplay' + product_id).val();
        let storage = $('#InputStockStorage' + product_id).val();
        let note = $('#inputNotes' + product_id).val();

        if (stockNew == 0 && storage == 0) {
            alert('Isikan nominal Stock Display dan stock Gudang terlebih dahulu')
        }
        $('#IdProduct').val(product_id);
        $('#StockTotal').val(stock);
        $('#StockDisplay').val(stockNew);
        $('#StockStorage').val(storage);
        $('#Notes').val(note);
    });
</script>

<?= $this->endSection(); ?>