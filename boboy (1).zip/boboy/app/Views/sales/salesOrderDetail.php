<?= $this->extend('layouts/main'); ?>
<?= $this->section('content'); ?>
<div class="d-flex justify-content-center ">
    <div class="col-sm-10 mt-4">
        <div class="widget-content widget-content-area ">
            <div class="row">
                <div class="col-sm-7">
                    <h5 class="inv-list-number"><?= $SalesOrder['branch_name']; ?></h5>
                    <b>Nomor : <?= $SalesOrder['sales_order_invoices']; ?></b> -
                    <?php $prdate = new DateTime($SalesOrder['sales_order_created_at']);
                    echo date_indo($prdate->format('Y-m-d'));  ?>
                    <p class="inv-email-address"><?= $SalesOrder['branch_address'] ?> <?= $SalesOrder['branch_telephone'] ?></p>
                </div>
                <div class="col-sm-5">
                    <table class="table table-sm">
                        <thead>
                            <tr>
                                <td>Status Pembayaran</td>
                                <?php if ($SalesOrder['sales_order_status'] == 1) : ?>
                                    <td><b class="text-success"> Transaksi Berhasil </b></td>
                                <?php else : ?>
                                    <td><b class="text-danger"> Transaksi Dibatalkan </b></td>
                                <?php endif; ?>
                            </tr>
                            <tr>
                                <td>Pelanggan</td>
                                <td><b> <?= ($SalesOrder['customer_fullname']) ? $SalesOrder['customer_fullname'] : ''; ?></b> <?= ($SalesOrder['customer_address']) ? $SalesOrder['customer_address'] : ''; ?> <?= ($SalesOrder['customer_telephone']) ? $SalesOrder['customer_telephone'] : ''; ?></td>
                            </tr>
                            <tr>
                                <td>Metode Pembayaran:</td>
                                <td><?= $SalesOrder['payment_method_name']; ?></td>
                            </tr>
                            <?php if ($SalesOrder['payment_method_id'] == 2) : ?>
                                <tr>
                                    <td>Nomor Kartu:</td>
                                    <td><?= ($SalesOrder['sales_order_account_no'] != null) ? $SalesOrder['sales_order_account_no'] : ''; ?></td>
                                </tr>
                                <tr>
                                    <td>Nama Pemegang Kartu:</td>
                                    <td><?= ($SalesOrder['sales_order_card_name'] != null) ? $SalesOrder['sales_order_card_name'] : ''; ?></td>
                                </tr>
                            <?php endif; ?>
                        </thead>
                    </table>
                </div>
            </div>
            <div class="table-responsive ">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Nama Produk</th>
                            <th>Kuantitas</th>
                            <th>Harga Barang</th>
                            <th>Diskon %</th>
                            <th>Diskon (Rp.)</th>
                            <th>Subtotal</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 1;
                        foreach ($SalesOrderProduct as $salesProduct) : ?>
                            <tr>
                                <td><?= $salesProduct['sales_order_product_name']; ?></td>
                                <td><?= $salesProduct['sales_order_quantity']; ?></td>
                                <td>RP. <?= number_format($salesProduct['sales_order_price']); ?></td>
                                <td><?= $salesProduct['sales_order_product_precentage_discount']; ?></td>
                                <td>RP. <?= number_format($salesProduct['sales_order_product_discount']); ?></td>
                                <td>RP. <?= number_format(($salesProduct['sales_order_price'] *  $salesProduct['sales_order_quantity']) - $salesProduct['sales_order_product_discount']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                        <tr class="font-weight-bold">
                            <td>Total Diskon :</td>
                            <td colspan="4"></td>
                            <td>Rp.<?= number_format($SalesOrder['sales_order_discount']); ?></td>
                        </tr>
                        <tr class="font-weight-bold">
                            <td>Total Transaksi :</td>
                            <td colspan="4"></td>
                            <td>Rp.<?= number_format($SalesOrder['sales_order_total'] - $SalesOrder['sales_order_discount']); ?></td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <?php if ($SalesOrder['sales_order_status'] == 2) : ?>
                <textarea name="reasonVoid" id="" cols="70" rows="5" readonly style="color:black"><?= ($SalesOrder['sales_order_void_description'] != null) ? $SalesOrder['sales_order_void_description'] : 'Tidak ada input alasan Pembatalan'; ?></textarea>
            <?php endif; ?>
        </div>
    </div>
</div>
<?= $this->endSection(); ?>