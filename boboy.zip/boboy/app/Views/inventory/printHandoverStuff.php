<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Point of Sale Toko Mainan Boboy">
    <meta name="author" content="Codavlo Indonesia">
    <link rel="icon" type="image/x-icon" href="<?= base_url('assets/img/logotoko1.jpeg') ?>" />
    <title>Print Surat Jalan | Toko Mainan Boboy</title>
    <script src="<?= base_url('assets/js/libs/jquery-3.6.0.js') ?>"></script>
    <style>
        hr {
            display: block;
            margin-top: 0.2em;
            margin-bottom: 0.2em;
            margin-left: 0.25em;
            margin-right: 0.25em;
            border-style: inset;
            border-width: 1px;
        }

        @media print {
            body * {
                visibility: hidden;
            }

            #section-to-print,
            #section-to-print * {
                visibility: visible;
            }

            #section-to-print {
                position: absolute;
                left: 0;
                top: 0;
            }
        }

        .text-center {
            margin-left: 7.5%;
            margin-top: 0.5%;
        }
    </style>
    <link href="<?= base_url('bootstrap/css/bootstrap.css') ?>" rel="stylesheet" type="text/css">
</head>

<body onload="window.print()">
    <div style="width:100%;" id="section-to-print">
        <div class="row" id="cancel-row">
            <div class="col-xl-12">
                <div class="col-sm-12">
                    <h3 class="inv-list-number " style="text-align: center"><strong><span class="inv-title">Surat Jalan Pengiriman Barang</span></strong></h3>
                </div>
                <hr>
                <table></table>
                <div class="row" style="text-align: center">
                    <div class="col-sm-8 mt-3">
                        <h6 class="inv-created-date"><span class="inv-title">Tanggal Pembuatan : </span> <br><br>
                            <?php $prdate = new DateTime($StockTransfer['request_at']);
                            ?>
                            <span class="inv-date"><b><?php echo date_indo($prdate->format('Y-m-d')) . ', ' . $prdate->format('H:i'); ?></b></span>
                        </h6>
                    </div>
                    <div class="col-sm-4 mt-3 d-inline">
                        <h6 class="inv-created-date"><span class="inv-title">Dibuat Oleh : </span> <br><br>
                            <span class="inv-date"><b><?= $StockTransfer['employee_name']; ?></b></span>
                        </h6>
                    </div>
                </div>
                <hr>
                <div class="row" style="text-align: center">
                    <div class="col-sm-8 mt-3">
                        <h6 class="inv-to"> <b>Cabang Tujuan :</b></h6>
                    </div>
                    <div class="col-sm-4 mt-3 d-inline">
                        <h6 class=" inv-title"> <b>Status Barang:</b> </h6>
                    </div>
                    <div class="col-sm-8 mt-3">
                        <h2><?= $StockTransfer['branch_name']; ?></h2>
                    </div>
                    <div class="col-sm-4 mt-3 d-inline">
                        <div class="inv--payment-info">
                            <h2 class="font-weight-bold ">
                                <?php if ($StockTransfer['status'] == 1) { ?>
                                    <span class="text-warning"> DIKIRIM </span>
                                <?php } else if ($StockTransfer['status'] == 2) { ?>
                                    <span class="text-success"> DITERIMA </span>
                                <?php } else if ($StockTransfer['status'] == 0) { ?>
                                    <span class="text-warning"> MEMINTA </span>
                                <?php } ?>
                            </h2>
                        </div>
                    </div>
                </div>
                <div class="table-responsive my-3">
                    <table class="table table-bordered" style="text-align: center">
                        <thead>
                            <tr class="text-center">
                                <th>#</th>
                                <th>Nama Produk</th>
                                <th>Kuantitas</th>
                                <th>Produk Yang Diterima</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $i = 1;
                            foreach ($StockTransferProducts as $product) : ?>
                                <tr class="text-center">
                                    <td><?= $i++; ?></td>
                                    <td><?= $product['stock_transfer_product_name']; ?></td>
                                    <td><?= $product['stock_transfer_product_quantity']; ?></td>
                                    <td>..............................</td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <br>
                <div class="text-right">
                    <h6>Tanda Tangan Penerima</h6>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                    <h6>(.................................) </h6>
                </div>
            </div>
        </div>
    </div>
    <div class="text-center">
        <button onclick="window.location.href='<?= base_url('stockTransfer'); ?>'">Kembali</button>
    </div>
    <script>
        function pageRedirect() {
            window.location.replace("<?= base_url('stockTransfer'); ?>");
        }
        setTimeout("pageRedirect()", 2000);
    </script>
</body>

</html>