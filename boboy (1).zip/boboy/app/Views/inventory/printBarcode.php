<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Point of Sale Toko Mainan Boboy">
    <meta name="author" content="Codavlo Indonesia">
    <link rel="icon" type="image/x-icon" href="<?= base_url('assets/img/logotoko1.jpeg') ?>" />
    <title>Print Barcode | Toko Mainan Boboy</title>
    <script src="<?= base_url('assets/js/libs/jquery-3.6.0.js') ?>"></script>
    <style>
        @media print {
            body * {
                visibility: hidden;
            }

            #section-to-print,
            #section-to-print * {
                visibility: visible;
            }

            #section-to-print {
                position: absolute;
                left: 0;
                top: 0;
            }
        }

        .text-center {
            margin-top: 1%;
            margin-right: 0.5%;
        }
    </style>
</head>

<body>
    <div style="width:10.33cm;" id="section-to-print">
        <table cellspacing='0' cellpadding='0' style="font-size:7pt; text-align:center; width:3.3cm;height:1.5mm;">
            <tr>
                <?php for ($i = 0; $i < $Print; $i++) : ?>
                    <td>
                        <?php if ($i == 1) : ?>
                            <div style=" margin-right:0.1cm;margin-bottom:0.12cm;margin-left:0.2cm">
                            <?php else : ?>
                                <div style=" margin-right:0.2cm;margin-bottom:0.12cm;margin-left:0.2cm">
                                <?php endif; ?>
                                <?= $Product['product_sku']; ?><br>
                                <?= $Product['product_name']; ?><br>
                                <span style="font-size:9pt;">Rp. <?= number_format($Product['product_selling_price']); ?></span>
                                <?= $barcode->getBarcode($Product['product_sku'], $barcode::TYPE_CODE_128); ?><br>
                                </div>
                    </td>
                    <?php if ($no++ % 3 == 0) : ?>
            </tr>
            <tr>
            <?php endif; ?>
        <?php endfor; ?>
            </tr>
        </table>
    </div>

    <br>
    <div class="text-center">
        <button id="btnPrint" onclick="window.print()">Cetak Barcode</button>
        <?php if ($p) : ?>
            <button onclick="window.location.href='<?= base_url('branchStock'); ?>'">Kembali</button>
        <?php else : ?>
            <button onclick="window.location.href='<?= base_url('product'); ?>'">Kembali</button>
        <?php endif; ?>
    </div>
</body>

</html>