<?php

namespace App\Controllers\Settings;

use App\Controllers\BaseController;
use App\Models\MasterModel;
use App\Models\SalesModel;

class VoidPeriod extends BaseController
{
	function __construct()
	{
		$this->SalesModel = new SalesModel();
		$this->MasterModel = new MasterModel();
	}
	public function index()
	{
		$branch = $this->request->getGet('branch');
		if ($branch) {
			$VoidPeriod = $this->SalesModel->getVoidPeriod($branch);
		} else {
			$VoidPeriod = $this->SalesModel->getVoidPeriod(session()->get('branch_id'));
		}
		$data = array_merge($this->data, [
			'category'  	=> 'Pengaturan',
			'title'         => 'Waktu Pembatalan',
			'VoidPeriod'	=> $VoidPeriod,
			'Branch'    	=> $this->MasterModel->getBranch(),
			'inputBranch'	=> $branch,
		]);

		return view('settings/voidPeriod', $data);
	}
	public function updateVoidPeriod()
	{
		$updateVoidPeriod = $this->SalesModel->updateVoidPeriod($this->request->getPost(null));
		if ($updateVoidPeriod) {
			session()->setFlashdata('notif_success', '<b>Berhasil merubah batas waktu pembatalan transaksi</b>');
			return redirect()->to(base_url('voidPeriod'));
		} else {
			session()->setFlashdata('notif_error', '<b>Gagal merubah batas waktu pembatalan transaksi</b>');
			return redirect()->to(base_url('voidPeriod'));
		}
	}
}
