<?= $this->extend('layouts/main'); ?>
<?= $this->section('content'); ?>
<div class="row">
    <div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
        <div class="widget-content widget-content-area br-6">
            <div class="table-responsive">
                <table class="table table-striped dataTable" style="width:100%">
                    <thead>
                        <th>#</th>
                        <th>Nama Product</th>
                        <th>Stok Display</th>
                        <th>Stok Gudang</th>
                        <th>Selisih</th>
                        <th>Deskripsi</th>
                        <th>Ceklist Terakhir</th>
                    </thead>
                    <tbody>
                        <?php
                        $i = 1;
                        if ($StockOpname != null) :
                            foreach ($StockOpname as $stockOpname) : ?>
                                <tr>
                                    <td><?= $i++; ?></td>
                                    <td><?= $stockOpname['stock_opname_product_name']; ?></td>
                                    <td><?= $stockOpname['stock_opname_qty_display']; ?></td>
                                    <td><?= $stockOpname['stock_opname_qty_storage']; ?></td>
                                    <td><?= $stockOpname['stock_opname_difference']; ?></td>
                                    <td><?= $stockOpname['stock_opname_description']; ?></td>
                                    <td><?php $prdate = new DateTime($stockOpname['stock_opname_created_at']);
                                        echo $prdate->format('d F Y') ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif;  ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection(); ?>