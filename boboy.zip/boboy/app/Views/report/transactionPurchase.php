<?= $this->extend('layouts/main'); ?>
<?= $this->section('content'); ?>
<div class="row layout-top-spacing" id="cancel-row">
    <div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
        <div class="widget">
            <div class="widget-content">
                <div class="row">
                    <?php if (1 != session()->get('branch_id')) : ?>
                        <div class="col-sm-6">
                            <h4>Transaksi Pembelian Cabang <?= session()->get('branch'); ?></h4>
                        </div>
                    <?php endif ?>
                    <div class="col-sm-6">
                        <form action="<?= base_url('transactionPurchase'); ?>" method="get">
                            <div class="input-group">
                                <?php if (1 == session()->get('branch_id')) : ?>
                                    <select class="custom-select" id="branch" name="branch" <?= (1 != session()->get('branch_id')) ? 'disabled' : ''; ?>>
                                        <option value="">-- Pilih Cabang -- </option>
                                        <?php foreach ($Branch as $branch) : ?>
                                            <option value="<?= $branch['branchID']; ?>" <?= ($inputBranch == $branch['branchID']) ? 'selected' : ''; ?>><?= $branch['branch_name']; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                <?php else : ?>
                                    <input type="hidden" name="branch" value="<?= session()->get('branch_id'); ?>">
                                <?php endif; ?>
                                <select class="custom-select" id="month" name="m" required>
                                    <option value="">-- Pilih Bulan --</option>
                                    <?php
                                    for ($i = 1; $i <= 12; $i++) : ?>
                                        <option value="<?= $i; ?>" <?= ($month) ? ($i == $month) ? 'selected' : '' : ''; ?>><?= bulan($i); ?> </option>
                                    <?php endfor; ?>
                                </select>
                                <select class="custom-select" id="years" name="y" required>
                                    <option value="">-- Pilih Tahun --</option>
                                    <?php
                                    $tg_awal = $yearsNow - 2;
                                    $tgl_akhir = $yearsNow + 2;
                                    for ($p = $tg_awal; $p <= $tgl_akhir; $p++) : ?>
                                        <option value="<?= $p; ?>" <?= ($years) ? ($p == $years) ? 'selected' : '' : ''; ?>><?= $p; ?> </option>
                                    <?php endfor; ?>
                                </select>
                                <div class="input-group-append">
                                    <button class="btn btn-primary" type="submit">Lihat Data</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <br>
                <div class="table-responsive">
                    <table class="table table-striped dataTable ">
                        <thead>
                            <tr class="text-center">
                                <th>#</th>
                                <th>Tanggal</th>
                                <th>Invoice</th>
                                <th>Supplier</th>
                                <th>Status</th>
                                <th class="no-content">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            if ($PurchaseOrders != null) :
                                $no = 1;
                                foreach ($PurchaseOrders as $purchaseOrder) :
                            ?>
                                    <tr>
                                        <td><?= $no++ ?> </td>
                                        <td><?= $purchaseOrder['purchase_order_invoice_date'] ?> </td>
                                        <td><?= $purchaseOrder['purchase_order_invoice'] ?> </td>
                                        <td><?= $purchaseOrder['supplier_company'] ?> </td>
                                        <td class="text-center"><?php if ($purchaseOrder['purchase_order_status'] == 1) { ?>
                                                <span class="badge badge-success"> DISETUJUI </span>
                                            <?php } else if ($purchaseOrder['purchase_order_status'] == 2) { ?>
                                                <span class="badge badge-danger"> DITOLAK </span>
                                            <?php } else if ($purchaseOrder['purchase_order_status'] == 0) { ?>
                                                <span class="badge badge-warning"> MENUNGGU </span>
                                            <?php } ?>
                                        </td>
                                        <td>
                                            <a class="btn btn-primary" href="<?= base_url('purchaseOrder/detail?id=' . $purchaseOrder['purchaseOrderID']); ?> ">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-zoom-in">
                                                    <circle cx="11" cy="11" r="8"></circle>
                                                    <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                                                    <line x1="11" y1="8" x2="11" y2="14"></line>
                                                    <line x1="8" y1="11" x2="14" y2="11"></line>
                                                </svg> Detail</a>

                                        </td>
                                    </tr>
                            <?php endforeach;
                            endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection(); ?>