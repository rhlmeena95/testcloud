<?= $this->extend('layouts/main'); ?>
<?= $this->section('content'); ?>
<div class="row layout-top-spacing" id="cancel-row">
	<div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
		<div class="widget-content widget-content-area br-6">
			<?php if (1 == session()->get('branch_id')) : ?>
				<form action="<?= base_url('stockCard'); ?>" method="get">
					<div class="row ChangeBtn" id="form_branch">
						<div class="col-sm-4"></div>
						<div class="col-sm-8">
							<div class="input-group">
								<select class="custom-select BRANCH" id="branch" name="branch" <?= (1 != session()->get('branch_id')) ? 'disabled' : ''; ?>>
									<option value="">-- Pilih Cabang -- </option>
									<?php foreach ($Branch as $branch) : ?>
										<option value="<?= $branch['branchID']; ?>" <?= ($inputBranch == $branch['branchID']) ? 'selected' : ''; ?>><?= $branch['branch_name']; ?></option>
									<?php endforeach; ?>
								</select>
								<select id="inputProduct" name="product" class="custom-select form_product">
									<option value="">-- Pilih Produk --</option>
									<?php foreach ($Product as $product) : ?>
										<option value="<?= $product['productID'] ?>" <?= ($inputProduct == $product['productID']) ? 'selected' : '' ?>><?= $product['product_subdep_name'] . ' - ' . $product['product_name'] ?></option>
									<?php endforeach; ?>
								</select>
								<div class="input-group-append">
									<button class="btn btn-primary" id="Tombol" type="submit">Lihat Data</button>
								</div>
							</div>
						</div>
					</div>
				</form>
			<?php else : ?>
				<div class="row ChangeBtn" id="form_branch">
					<div class="col-sm-6">
						<h4 class="mb-3">Stock Card Cabang <?= (session()->get('branch')) ?></h4>
					</div>
					<div class="col-sm-6">
						<form action="<?= base_url('stockCard'); ?>" method="get">
							<input type="hidden" name="branch" id="branch" value="<?= session()->get('branch_id'); ?>">
							<div class="input-group">
								<select id="inputProduct" name="product" class="custom-select">
									<option value="">-- Pilih Produk --</option>
									<?php foreach ($Product as $product) : ?>
										<option value="<?= $product['productID'] ?>" <?= ($inputProduct == $product['productID']) ? 'selected' : '' ?>><?= $product['product_subdep_name'] . ' - ' . $product['product_name'] ?></option>
									<?php endforeach; ?>
								</select>
								<div class="input-group-append">
									<button class="btn btn-primary" type="submit">Lihat Data</button>
								</div>
							</div>
						</form>
					</div>
				</div>
			<?php endif; ?>
			<br>
			<div class="table-responsive">
				<table class="table table-striped table-bordered " style="width:100%">
					<thead>
						<tr class="text-center">
							<th rowspan="2">Date</th>
							<th colspan="2">Stock In</th>
							<th colspan="2">Stock Out</th>
							<th>Saldo</th>
						</tr>
						<tr class="text-center">
							<th>Purchase Order</th>
							<th width="15%">Quantity</th>
							<th>Sales Order</th>
							<th width="15%">Quantity</th>
							<th>Quantity</th>
						</tr>
					</thead>
					<tbody>
						<tr class="text-center">
							<td colspan="5" class="text-center"><b>Stok Awal Pada <?= date('Y'); ?></b></td>
							<td><?= $InitialStock['stock_initial_quantity'] ?></td>
						</tr>
						<?php
						$qty_in         = 0;
						$qty_out        = 0;
						?>
						<?php foreach ($StockCard as $stockCard) :
							$qty_in         += $stockCard['stock_card_income'];
							$qty_out        += $stockCard['stock_card_outcome'];
							$initStock		= $InitialStock['stock_initial_quantity'];
							$qty_saldo      =  $initStock + $qty_in - $qty_out;
						?>

							<tr class="text-center">
								<?php $prdate = new DateTime($stockCard['stock_card_created_at']); ?>
								<td><?= date_indo($prdate->format('Y-m-d')) . ', ' . $prdate->format('H:i'); ?></td>
								<td><?= ($stockCard['purchase_id']) ? $stockCard['purchase_id'] : ''  ?></td>
								<td><?= ($stockCard['stock_card_income'] != 0) ? abs($stockCard['stock_card_income']) : '' ?></td>
								<td><?= ($stockCard['sales_id']) ? $stockCard['sales_id'] : '' ?></td>
								<td><?= ($stockCard['stock_card_outcome'] != 0) ? abs($stockCard['stock_card_outcome']) : '' ?></td>
								<td><?= $stockCard['stock_card_total']  ?></td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>

<script>
	$(document).ready(function() {
		$(".form_product").hide();
		$("#Tombol").hide();
		$('.ChangeBtn').on('change', ".BRANCH", function() {
			$(".form_product").show();
			$("#Tombol").show();
		});
	});
</script>

<?= $this->endSection(); ?>