<?php

namespace App\Controllers\Purchasing;

use App\Controllers\BaseController;
use App\Models\MasterModel;
use App\Models\PurchasingModel;

class PurchaseReturn extends BaseController
{
	public function __construct()
	{
		$this->PurchasingModel = new PurchasingModel();
		$this->MasterModel = new MasterModel();
	}
	public function index()
	{
		if ($this->request->getGet('id')) {
			$data = array_merge($this->data, [
				'category'      		=> 'Transaksi',
				'title'         		=> 'Pengembalian Pembelian',
				'PurchaseReturn'		=> $this->PurchasingModel->getPurchaseReturn($this->request->getGet('id')),
				'PurchaseReturnProduct'	=> $this->PurchasingModel->getPurchaseReturnProduct($this->request->getGet('id')),
			]);
			return view('purchasing/purchaseReturnDetail', $data);
		}
		$data = array_merge($this->data, [
			'category'      		=> 'Transaksi',
			'title'         		=> 'Pengembalian Pembelian',
			'PurchaseReturn'		=> $this->PurchasingModel->getPurchaseReturn(),
		]);
		return view('purchasing/purchaseReturnList', $data);
	}
	public function purchaseReturn()
	{
		$data = array_merge($this->data, [
			'category'      	=> 'Transaksi',
			'title'         	=> 'Pengembalian Barang',
			'Products'  		=> $this->MasterModel->getProducts(),
			'InvPurchaseOrder'  => $this->PurchasingModel->getMaxPurchaseOrder(),
			'Suppliers'    		=> $this->PurchasingModel->getSuppliers(),
		]);
		return view('purchasing/purchaseReturnForm', $data);
	}
	public function savePurchaseReturn()
	{
		$carts 					= $this->cart->contents();
		$savePurchaseReturn = $this->PurchasingModel->savePurchaseReturn($carts, $this->request->getPost(null));
		if ($savePurchaseReturn) {
			session()->setFlashdata('notif_success', '<b>Berhasil mengembalikan Barang</b>');
			$this->cart->destroy();
			return redirect()->to(base_url('purchaseReturn'));
		} else {
			session()->setFlashdata('notif_error', '<b>Gagal mengembalikan Barang</b>');
			return redirect()->to(base_url('purchaseReturn/return'));
		}
	}
	public function print()
	{
		$data = array_merge($this->data, [
			'category'      		=> 'Transaksi',
			'title'         		=> 'Pengembalian Pembelian',
			'PurchaseReturn'		=> $this->PurchasingModel->getPurchaseReturn($this->request->getGet('id')),
			'PurchaseReturnProduct'	=> $this->PurchasingModel->getPurchaseReturnProduct($this->request->getGet('id')),
		]);
		return view('purchasing/printPurchaseReturn', $data);
	}
}
