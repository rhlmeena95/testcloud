<?php

namespace App\Controllers\Master;

use App\Controllers\BaseController;
use App\Models\MasterModel;
use App\Models\PurchasingModel;

class Suppliers extends BaseController
{
	function __construct()
	{
		$this->PurchasingModel = new PurchasingModel();
		$this->MasterModel	   = new MasterModel();
	}
	public function index()
	{
		$data = array_merge($this->data, [
			'category'      => 'Master',
			'title'         => 'Supplier',
			'Suppliers'    => $this->PurchasingModel->getSuppliers(),
			'Province'    	=> $this->MasterModel->getProvince(),
			'City'    		=> $this->MasterModel->getCity(),
			'Subdistrict'   => $this->MasterModel->getSubdistrict(),
		]);

		return view('master/supplierList', $data);
	}

	public function createSuppliers()
	{
		$createSuppliers = $this->PurchasingModel->createSuppliers($this->request->getPost(null));
		if ($createSuppliers) {
			session()->setFlashdata('notif_success', '<b>Successfully added new Suppliers</b>');
			return redirect()->to(base_url('suppliers'));
		} else {
			session()->setFlashdata('notif_error', '<b>Failed to add new Suppliers</b>');
			return redirect()->to(base_url('suppliers'));
		}
	}
	public function updateSuppliers()
	{
		$updateSuppliers = $this->PurchasingModel->updateSuppliers($this->request->getPost(null));
		if ($updateSuppliers) {
			session()->setFlashdata('notif_success', '<b>Successfully update Suppliers</b>');
			return redirect()->to(base_url('suppliers'));
		} else {
			session()->setFlashdata('notif_error', '<b>Failed to update Suppliers</b>');
			return redirect()->to(base_url('suppliers'));
		}
	}
	// public function deleteSuppliers()
	// {
	// 	$deleteSuppliers = $this->PurchasingModel->deleteSuppliers($this->request->getPost('supplierID'));
	// 	if ($deleteSuppliers) {
	// 		session()->setFlashdata('notif_success', '<b>Successfully delete Suppliers</b>');
	// 		return redirect()->to(base_url('suppliers'));
	// 	} else {
	// 		session()->setFlashdata('notif_error', '<b>Failed to delete Suppliers</b>');
	// 		return redirect()->to(base_url('suppliers'));
	// 	}
	// }
}
