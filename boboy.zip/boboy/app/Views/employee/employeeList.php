<?= $this->extend('layouts/main'); ?>
<?= $this->section('content'); ?>
<h1 class="h3 mb-3"><strong><?= $title; ?></strong> Menu </strong><a href="<?= base_url('employee/createEmployee'); ?>" class="btn btn-primary  float-right">
		<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-plus-square">
			<rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
			<line x1="12" y1="8" x2="12" y2="16"></line>
			<line x1="8" y1="12" x2="16" y2="12"></line>
		</svg> Tambah Pegawai Baru</a></h1>
<div class="row layout-top-spacing" id="cancel-row">
	<div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
		<div class="widget-content widget-content-area br-6">
			<?php if (1 == session()->get('branch_id')) : ?>
				<form action="<?= base_url('employee'); ?>" method="get">
					<div class="row">
						<div class="col-sm-10">
							<div class="form-group">
								<select class="form-control" id="branch" name="branch" <?= (1 != session()->get('branch_id')) ? 'disabled' : ''; ?>>
									<option value="">-- Pilih Cabang -- </option>
									<?php foreach ($Branch as $branch) : ?>
										<option value="<?= $branch['branchID']; ?>" <?= ($inputBranch == $branch['branchID']) ? 'selected' : ''; ?>><?= $branch['branch_name']; ?></option>
									<?php endforeach; ?>
								</select>
							</div>
						</div> <?php if (1 ==  session()->get('branch_id')) : ?>
							<div class="col-sm-2">
								<button type="submit" class="btn btn-lg btn-block btn-outline-primary">Cari</button>
							</div>
						<?php endif; ?>
					</div>
				</form>
			<?php else : ?>
				<div class="form-group">
					<select class="form-control" id="branch" name="branch" <?= (1 != session()->get('branch_id')) ? 'disabled' : ''; ?>>
						<?php foreach ($Branch as $branch) : ?>
							<option value="<?= $branch['branchID']; ?>" <?= ($branch['branchID'] == session()->get('branch_id')) ? 'selected' : ''; ?>><?= $branch['branch_name']; ?></option>
						<?php endforeach; ?>
					</select>
				</div>
			<?php endif; ?>
			<div class="table-responsive">
				<table class="table table-striped dataTable" style="width:100%">
					<thead>
						<th>#</th>
						<th>Nip</th>
						<th>Nama Pegawai</th>
						<th>Email Pegawai</th>
						<th>Pegawai Cabang</th>
						<th>Jabatan Pegawai</th>
						<th>Aksi</th>
					</thead>
					<tbody>
						<?php if ($Employee != null) : ?>
							<?php
							$i = 1;
							foreach ($Employee as $employee) : ?>
								<tr>
									<td><?= $i++; ?> </td>
									<td><?= $employee['nip'] ?> </td>
									<td><?= $employee['employee_name'] ?> </td>
									<td><?= $employee['username']; ?></td>
									<td><?= $employee['branch_name']; ?></td>
									<td><?= $employee['role_name']; ?></td>
									<td>
										<div class="btn-group dropright mb-4 mr-2" role="group">
											<button id="btnDropRightOutline" type="button" class="btn btn-outline-primary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Manage

												<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-command">
													<path d="M18 3a3 3 0 0 0-3 3v12a3 3 0 0 0 3 3 3 3 0 0 0 3-3 3 3 0 0 0-3-3H6a3 3 0 0 0-3 3 3 3 0 0 0 3 3 3 3 0 0 0 3-3V6a3 3 0 0 0-3-3 3 3 0 0 0-3 3 3 3 0 0 0 3 3h12a3 3 0 0 0 3-3 3 3 0 0 0-3-3z"></path>
												</svg>
											</button>
											<div class="dropdown-menu" aria-labelledby="btnDropRightOutline">
												<a class="dropdown-item btnUpdt" data-toggle="modal" data-target="#formEmployeeUpdateModal" data-id="<?= $employee['employeeID']; ?>" data-nip="<?= $employee['employeeNIP']; ?>" data-name="<?= $employee['employee_name']; ?>" data-address="<?= $employee['employee_address']; ?>" data-phone="<?= $employee['employee_telephone']; ?>" data-username="<?= $employee['username']; ?>" data-province="<?= $employee['employee_province_id']; ?>" data-city="<?= $employee['employee_city_id']; ?>" data-subdistrict="<?= $employee['employee_subdistrict_id']; ?>" data-role="<?= $employee['role']; ?>" data-branch="<?= $employee['branch']; ?>">
													<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-edit">
														<path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
														<path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
													</svg> Ubah
												</a>
												<form action="<?= base_url('employee/deleteEmployee'); ?>" method="post" class="d-inline">
													<input type="hidden" name="employeeID" id="employeeID" value="<?= $employee['employeeID']; ?>">
													<input type="hidden" name="_method" value="DELETE">
													<a type="submit" class="dropdown-item" onclick="return confirm('Apakah anda yakin mengapus ?')">
														<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-trash-2">
															<polyline points="3 6 5 6 21 6"></polyline>
															<path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
															<line x1="10" y1="11" x2="10" y2="17"></line>
															<line x1="14" y1="11" x2="14" y2="17"></line>
														</svg> Hapus
													</a>
												</form>
												<a href="<?= base_url('employee/attendance?id=' . $employee['nip']); ?>" class="dropdown-item">

													<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-eye">
														<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
														<circle cx="12" cy="12" r="3"></circle>
													</svg>
													Detail Absensi
												</a>
											</div>
										</div>
									</td>
								</tr>
							<?php endforeach; ?>
						<?php endif; ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>


<div class="modal fade" id="formEmployeeUpdateModal" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="formEmployeeUpdateModalLabel" aria-hidden="true">
	<div class="modal-dialog modal-lg" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="formEmployeeUpdateModalLabel">Tambah Data Barang Baru</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
			</div>
			<div class="modal-body">
				<form action="<?= base_url('employee/updateEmployee'); ?>" method="post">
					<input type="hidden" name="inputEmployeeID" id="IDEmployee">
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label for="inputNipEmployee">NIP Pegawai :</label>
								<input type="text" class="form-control" name="inputNipEmployee" readonly id="NipEmployee" required>
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label for="inputEmployeeBranch">Pegawai Cabang</label>
								<select name="inputEmployeeBranch" id="EmployeeBranch" class="form-control" required <?= (1 != session()->get('branch_id')) ? 'disabled' : ''; ?>>
									<option value="">-- Pilih Cabang --</option>
									<?php foreach ($Branch as $branch) : ?>
										<option value="<?= $branch['branchID']; ?>" <?= (session()->get('branch_id') == $branch['branchID']) ? 'selected' : ''; ?>><?= $branch['branch_name']; ?></option>
									<?php endforeach; ?>
								</select>
							</div>
						</div>
					</div>
					<div class="form-group">
						<label for="inputEmployeeName">Nama Pegawai</label>
						<input type="text" class="form-control" name="inputEmployeeName" id="EmployeeName" required>
					</div>
					<div class="form-group">
						<label for="inputEmployeeAddress">Alamat Pegawai</label>
						<input type="text" class="form-control" name="inputEmployeeAddress" id="EmployeeAddress" required>
					</div>
					<div class="row">
						<div class="col-4 ProvinceUpdate">
							<div class="form-group Province">
								<label for="inputProvince">Provinsi</label>
								<select id="ProvinceEmployee" name="inputProvince" class="form-control selectpicker provinceID" data-live-search="true" required>
									<?php foreach ($Province as $province) : ?>
										<option value="<?= $province['id']; ?>"><?= $province['province_name']; ?></option>
									<?php endforeach; ?>
								</select>
							</div>
						</div>
						<div class="col-4" id="form_City">
							<div class="form-group">
								<label for="inputCity">Kabupaten/Kota</label>
								<select id="city" name="inputCity" class="form-control " required>
									<option selected>Pilih Kabupaten/Kota...</option>
								</select>
							</div>
						</div>
						<div class="col-4" id="form_Subdistrict">
							<div class="form-group">
								<label for="inputSubdistrict">Kecamatan</label>
								<select id="subdistrict" name="inputSubdistrict" class="form-control" required>
									<option selected>Pilih Kecamatan...</option>
								</select>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label for="inputEmployeeTelephone">Nomor Telepon</label>
								<input type="number" class="form-control" name="inputEmployeeTelephone" id="EmployeeTelephone" required>
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label for="inputEmployeeEmail">Email Pegawai</label>
								<input type="email" class="form-control" name="inputEmployeeEmail" id="EmployeeEmail" required>
							</div>
						</div>
					</div>
					<div class="form-group">
						<label for="inputEmployeeRole">Jabatan Pegawai</label>
						<select name="inputEmployeeRole" id="EmployeeRole" class="form-control" required>
							<option value="">-- Pilih Jabatan Pegawai --</option>
							<?php foreach ($role as $userRole) : ?>
								<option value="<?= $userRole['id']; ?>"><?= $userRole['role_name']; ?></option>
							<?php endforeach; ?>
						</select>
					</div>
					<div class="modal-footer">
						<a href="<?= base_url('employee'); ?>" class="btn" data-dismiss="modal"><i class="flaticon-cancel-12"></i> Kembali</a>
						<button type="submit" class="btn btn-primary">Simpan</button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>

<script>
	$(document).ready(function() {
		$(' .btnUpdt').click(function() {
			const employee_id = $(this).data("id");
			const employee_nip = $(this).data("nip");
			const employee_name = $(this).data("name");
			const employee_address = $(this).data("address");
			const employee_phone = $(this).data("phone");
			const employee_username = $(this).data("username");
			const employee_province = $(this).data("province");
			const employee_city = $(this).data("city");
			const employee_subdistrict = $(this).data("subdistrict");
			const employee_role = $(this).data("role");
			const employee_branch = $(this).data("branch");


			$('#IDEmployee').val(employee_id);
			$('#NipEmployee').val(employee_nip);
			$('#EmployeeName').val(employee_name);
			$('#EmployeeEmail').val(employee_username);
			$('#EmployeeAddress').val(employee_address);
			$('#ProvinceEmployee').val(employee_province);
			$('#city').val(employee_city);
			$('#subdistrict').val(employee_subdistrict);
			$('#EmployeeTelephone').val(employee_phone);
			$('#EmployeeRole').val(employee_role);
			$('#EmployeeBranch').val(employee_branch);
		});
		$('.ProvinceUpdate').on('change', ".provinceID", function() {
			const provinsi = $("#ProvinceEmployee").val();

			$.ajax({
				url: "<?= base_url('customers/getCity'); ?>",
				method: "POST",
				type: 'JSON',
				data: {
					province: provinsi,
				},
				success: function(result) {
					$("#city").html(result);
				}
			});
		});
		$('#form_City').on('change', "#city", function() {
			const kota = $("#city").val();

			$.ajax({
				url: "<?= base_url('customers/getSubdistrict'); ?>",
				method: "POST",
				type: 'JSON',
				data: {
					city: kota,
				},
				success: function(result) {
					$("#subdistrict").html(result);
				}
			});
		});
	});
</script>
<?= $this->endSection(); ?>