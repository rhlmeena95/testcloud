<?php

namespace App\Controllers\Report;

use App\Models\MasterModel;
use App\Controllers\BaseController;
use App\Models\InventoryModel;

class BranchStock extends BaseController
{
	function __construct()
	{
		$this->MasterModel = new MasterModel();
		$this->InventoryModel = new InventoryModel();
	}
	public function index()
	{
		$branch = $this->request->getGet('branch');
		if ($branch) {
			$branchStock = $this->InventoryModel->getStockProduct($branch);
		} else {
			$branchStock = $this->InventoryModel->getStockProduct();
		}
		$data = array_merge($this->data, [
			'category'      			=> 'Laporan',
			'title'         			=> 'Stok Cabang',
			'BranchStock'				=> $branchStock,
			'Branch'    				=> $this->MasterModel->getBranch(),
			'inputBranch'				=> $branch,
		]);
		return view('report/branchStock', $data);
	}
}
