<?php

namespace App\Models;

use CodeIgniter\Model;

class UserModel extends Model
{
	public function getUser($username = false, $userID = false)
	{
		if ($username) {
			return $this->db->table('users')
				->select('*,users.id AS userID,user_role.id AS roleID,branch.id AS branchID')
				->join('user_role', 'users.role = user_role.id')
				->join('branch', 'users.branch = branch.id')
				->where(['username' => $username])
				->get()->getRowArray();
		} elseif ($userID) {
			return $this->db->table('users')
				->select('*,users.id AS userID,user_role.id AS roleID,branch.id AS branchID')
				->join('user_role', 'users.role = user_role.id')
				->join('branch', 'users.branch = branch.id')
				->where(['users.id' => $userID])
				->get()->getRowArray();
		} else {
			return $this->db->table('users')
				->select('*,users.id AS userID,user_role.id AS roleID,branch.id AS branchID')
				->join('user_role', 'users.role = user_role.id')
				->join('branch', 'users.branch = branch.id')
				->get()->getResultArray();
		}
	}

	public function getAccessMenuCategory($role)
	{
		return $this->db->table('user_menu_category')
			->select('*,user_menu_category.id AS menuCategoryID')
			->join('user_access', 'user_menu_category.id = user_access.menu_category_id')
			->orderBy('sort_order')
			->where(['user_access.role_id' => $role])
			->get()->getResultArray();
	}
	public function getAccessMenu($role)
	{
		return $this->db->table('user_menu')
			->join('user_access', 'user_menu.id = user_access.menu_id')
			->where(['user_access.role_id' => $role])
			->get()->getResultArray();
	}

	public function getUserRole($role = false)
	{
		if ($role) {
			return $this->db->table('user_role')
				->where(['id' => $role])
				->get()->getRowArray();
		}

		return $this->db->table('user_role')
			->get()->getResultArray();
	}

	public function createUser($dataUser)
	{
		return $this->db->table('users')->insert([
			'fullname'		=> $dataUser['inputFullname'],
			'username' 		=> $dataUser['inputUsername'],
			'password' 		=> password_hash($dataUser['inputPassword'], PASSWORD_DEFAULT),
			'role' 			=> $dataUser['inputRole'],
			'branch'		=> $dataUser['inputBranch'],
			'created_at'    => date('Y-m-d h:i:s')
		]);
	}
	public function updateUser($dataUser)
	{
		return $this->db->table('users')->update([
			'fullname'		=> $dataUser['inputFullname'],
			'username' 		=> $dataUser['inputUsername'],
			'role' 			=> $dataUser['inputRole'],
			'branch'		=> $dataUser['inputBranch'],
			'updated_at'	=> date('Y-m-d h:i:s')
		], ['id' => $dataUser['userID']]);
	}
	public function deleteUser($userNip)
	{
		$this->db->table('employee')->delete(['nip' => $userNip]);
		return $this->db->table('users')->delete(['nip' => $userNip]);
	}

	public function createRole($dataRole)
	{
		return $this->db->table('user_role')->insert(['role_name' => $dataRole['inputRoleName']]);
	}
	public function updateRole($dataRole)
	{
		return $this->db->table('user_role')->update(['role_name' => $dataRole['inputRoleName']], ['id' => $dataRole['roleID']]);
	}
	public function deleteRole($role)
	{
		return $this->db->table('user_role')->delete(['id' => $role]);
	}
	public function checkUserMenuCategoryAccess($dataAccess)
	{
		return  $this->db->table('user_access')
			->where([
				'role_id' => $dataAccess['roleID'],
				'menu_category_id' => $dataAccess['menuCategoryID']
			])
			->countAllResults();
	}

	public function checkUserAccess($dataAccess)
	{
		return  $this->db->table('user_access')
			->where([
				'role_id' => $dataAccess['roleID'],
				'menu_id' => $dataAccess['menuID']
			])->countAllResults();
	}

	public function checkUserSubmenuAccess($dataAccess)
	{
		return  $this->db->table('user_access')
			->where([
				'role_id' => $dataAccess['roleID'],
				'submenu_id' => $dataAccess['submenuID']
			])
			->countAllResults();
	}
	public function saveUsersAccess($dataMenuCategory, $dataMenu, $role_id)
	{
		foreach ($dataMenuCategory as $MenuCategory) {
			$checkMenuCategory = $this->db->table('user_access')->getWhere(['role_id' => $role_id, 'menu_category_id' => $MenuCategory])->getResultArray();
			if ($checkMenuCategory) {
				$this->db->table('user_access')->delete(['role_id' => $role_id, 'menu_category_id' => $MenuCategory]);
			} else {
				$this->db->table('user_access')->insert([
					'role_id' 			=> $role_id,
					'menu_category_id' 	=> $MenuCategory,
				]);
			}
		}
		foreach ($dataMenu as $Menu) {
			$checkMenu = $this->db->table('user_access')->getWhere(['role_id' => $role_id, 'menu_id' => $Menu])->getRowArray();
			if ($checkMenu) {
				$this->db->table('user_access')->delete(['role_id' => $role_id, 'menu_id' => $Menu]);
			} else {
				$this->db->table('user_access')->insert([
					'role_id' 			=> $role_id,
					'menu_id' 			=> $Menu,
				]);
			}
		}
		return true;
	}
	public function insertMenuCategoryPermission($dataAccess)
	{
		return $this->db->table('user_access')->insert(['role_id' => $dataAccess['roleID'], 'menu_category_id' => $dataAccess['menuCategoryID']]);
	}
	public function deleteMenuCategoryPermission($dataAccess)
	{
		return $this->db->table('user_access')->delete(['role_id' => $dataAccess['roleID'], 'menu_category_id' => $dataAccess['menuCategoryID']]);
	}

	public function insertMenuPermission($dataAccess)
	{
		return $this->db->table('user_access')->insert(['role_id' => $dataAccess['roleID'], 'menu_id' => $dataAccess['menuID']]);
	}
	public function deleteMenuPermission($dataAccess)
	{
		return $this->db->table('user_access')->delete(['role_id' => $dataAccess['roleID'], 'menu_id' => $dataAccess['menuID']]);
	}

	public function insertSubmenuPermission($dataAccess)
	{
		return $this->db->table('user_access')->insert(['role_id' => $dataAccess['roleID'], 'submenu_id' => $dataAccess['submenuID']]);
	}
	public function deleteSubmenuPermission($dataAccess)
	{
		return $this->db->table('user_access')->delete(['role_id' => $dataAccess['roleID'], 'submenu_id' => $dataAccess['submenuID']]);
	}
	public function checkUserTransaction($userID)
	{
		$employeeId = $this->db->table('employee')->getWhere(['nip' => $userID])->getRowArray();
		$transaction = $this->db->table('transaction')->where(['opening_by' => $employeeId['id']])->countAllResults();
		if ($transaction == 0) {
			$purchaseOrder = $this->db->table('purchase_order')->where(['purchase_order_created_by' => $employeeId['id']])->countAllResults();
			if ($purchaseOrder == 0) {
				$salesOrder = $this->db->table('sales_order')->where(['sales_order_cashier' => $employeeId['id']])->countAllResults();
				if ($salesOrder == 0) {
					$stockTransfer = $this->db->table('stock_transfer')->where(['request_by' => $employeeId['id']])->countAllResults();
					if ($stockTransfer == 0) {
						return true;
					} else {
						return false;
					}
				} else {
					return false;
				}
			} else {
				return false;
			}
		} else {
			return false;
		}
	}
}
