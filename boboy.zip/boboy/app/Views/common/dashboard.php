<?= $this->extend('layouts/main'); ?>
<?= $this->section('content'); ?>
<div class="text-center">
    <?php if (1 == session()->get('branch_id')) : ?>
        <img src="<?= base_url('assets/img/logo_cikampek.jpeg'); ?>" alt="logo toko" class="img-fluid" width="30%">
    <?php else : ?>
        <img src="<?= base_url('assets/img/logotoko1.jpeg'); ?>" alt="logo toko" class="img-fluid" width="30%">
    <?php endif; ?>

</div>
<?= $this->endSection(); ?>