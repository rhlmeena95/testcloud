<div class="topbar-nav header navbar" role="banner">
    <nav id="topbar">
        <ul class="navbar-nav theme-brand flex-row  text-center">
            <li class="nav-item theme-logo">
                <a href="index.html">
                    <img src="assets/img/90x90.jpg" class="navbar-logo" alt="logo">
                </a>
            </li>
            <li class="nav-item theme-text">
                <a href="index.html" class="nav-link"> BOBOY </a>
            </li>
        </ul>
        <ul class="list-unstyled menu-categories" id="topAccordion">
            <?php
            foreach ($MenuCategory as $mCategory) :
                if ($mCategory['parent'] > 0) :
            ?>
                    <li class="menu single-menu <?= ($segment == $mCategory['url']) ? 'active' : ''; ?>">
                        <a href="#<?= $mCategory['url']; ?>" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                            <div class="">
                                <!-- <//?= $mCategory['icon']; ?> -->
                                <span><?= $mCategory['menu_category']; ?></span>
                            </div>
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down">
                                <polyline points="6 9 12 15 18 9"></polyline>
                            </svg>
                        </a>
                        <ul class="collapse submenu list-unstyled" id="<?= $mCategory['menu_category']; ?>" data-parent="#topAccordion">
                            <?php
                            $Menu = getMenu($mCategory['menuCategoryID'], $user['role']);
                            foreach ($Menu as $menu) :
                                if ($menu['parent'] > 0) :
                                    $SubMenu =  getSubMenu($menu['menu_id'], $user['role']);
                            ?>
                                    <li class="sub-sub-submenu-list ">
                                        <a href="#<?= $menu['url']; ?>" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                                            <?= $menu['title']; ?>
                                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-right">
                                                <polyline points="9 18 15 12 9 6"></polyline>
                                            </svg> </a>
                                        <ul class="collapse list-unstyled sub-submenu" id="<?= $menu['url']; ?>" data-parent="#<?= $menu['url']; ?>">
                                            <?php foreach ($SubMenu as $subMenu) : ?>
                                                <li class="<?= ($subsegment == $subMenu['url']) ? 'active' : ''; ?>">
                                                    <a href="<?= base_url($menu['url'] . '/' . $subMenu['url']); ?>"> <?= $subMenu['title']; ?> </a>
                                                </li>
                                            <?php endforeach; ?>
                                        </ul>
                                    </li>
                                <?php
                                else :
                                ?>
                                    <li class="<?= ($segment == $menu['url']) ? 'active' : ''; ?>">
                                        <a href="<?= base_url($menu['url']); ?>"> <?= $menu['title']; ?></a>
                                    </li>
                            <?php endif;
                            endforeach; ?>
                        </ul>
                    </li>
                <?php else : ?>
                    <li class="menu single-menu <?= ($segment == $mCategory['url']) ? 'active' : ''; ?>">
                        <a href="<?= base_url($mCategory['url']); ?>">
                            <div class="">
                                <!-- <//?= $mCategory['icon']; ?> -->
                                <span><?= $mCategory['menu_category']; ?></span>
                            </div>
                        </a>
                    </li>
            <?php
                endif;
            endforeach;
            ?>
            <li class="menu single-menu ">
                <a href="<?= base_url('Welcome/logout'); ?>">
                    <div class="">
                        <!--   <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-log-out">
                            <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path>
                            <polyline points="16 17 21 12 16 7"></polyline>
                            <line x1="21" y1="12" x2="9" y2="12"></line>
                        </svg> -->
                        <span>Keluar</span>
                    </div>
                </a>
            </li>
        </ul>
    </nav>
</div>