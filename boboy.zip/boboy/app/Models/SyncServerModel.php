<?php

namespace App\Models;

use CodeIgniter\Model;

class SyncServerModel extends Model
{
    protected $serverDB;
    function __construct()
    {
        $this->db           = \Config\Database::connect('server');
        $this->serverDB     = \Config\Database::connect();
    }
    public function syncProduct()
    {
        $this->serverDB->transBegin();
        #Products  
        $Product = $this->db->table('products')->join('stock_product', 'stock_product.product_id = products.id')->get()->getResultArray();
        foreach ($Product as $product) {
            $checkingProduct = $this->serverDB->table('products')->where(['product_sku' => $product['product_sku'], 'product_created_at' => $product['product_created_at']])->countAllResults();
            if ($checkingProduct == 0) {
                $this->serverDB->table('products')->insert([
                    'product_subdepartment_id'  => $product['product_subdepartment_id'],
                    'product_sku'               => $product['product_sku'],
                    'product_name'              => $product['product_name'],
                    'product_stock'             => $product['product_stock'],
                    'product_purchase_price'    => $product['product_purchase_price'],
                    'product_selling_price'     => $product['product_selling_price'],
                    'product_points'            => $product['product_points'],
                    'product_created_at'        => $product['product_created_at'],
                    'product_updated_at'        => $product['product_updated_at']
                ]);
                $productID =  $this->serverDB->insertID();
                if (session()->get('branch_id') == 1) {
                    $this->serverDB->table('stock_product')->insert([
                        'branch_id'                     => 1,
                        'product_id'                    => $productID,
                        'stock_product_subdep_id'       => $product['product_subdepartment_id'],
                        'stock_product_name'            => $product['product_name'],
                        'stock_product_qty_new'         => $product['stock_product_qty_new'],
                        'stock_product_price'           => $product['product_purchase_price'],
                        'stock_product_selling_price'   => $product['product_selling_price']
                    ]);
                    $this->serverDB->table('stock_initial')->insert([
                        'branch_id'                     => 1,
                        'product_id'                    => $productID,
                        'stock_initial_period'          => date('Y'),
                        'stock_initial_quantity'        => $product['stock_product_qty_new'],
                        'stock_initial_nominal'         => $product['product_selling_price'],
                        'stock_initial_created_by'      => session()->get('user_id'),
                        'stock_initial_created_at'      => date('Y-m-d H:i:s')
                    ]);
                    $this->serverDB->table('stock_product')->insert([
                        'branch_id'                     => 2,
                        'product_id'                    => $productID,
                        'stock_product_subdep_id'       => $product['product_subdepartment_id'],
                        'stock_product_name'            => $product['product_name'],
                        'stock_product_qty_new'         => 0,
                        'stock_product_price'           => $product['product_purchase_price'],
                        'stock_product_selling_price'   => $product['product_selling_price']
                    ]);
                    $this->serverDB->table('stock_initial')->insert([
                        'branch_id'                     => 2,
                        'product_id'                    => $productID,
                        'stock_initial_period'          => date('Y'),
                        'stock_initial_quantity'        => 0,
                        'stock_initial_nominal'         => $product['product_selling_price'],
                        'stock_initial_created_by'      => session()->get('user_id'),
                        'stock_initial_created_at'      => date('Y-m-d H:i:s')
                    ]);
                    $this->serverDB->table('stock_product')->insert([
                        'branch_id'                     => 3,
                        'product_id'                    => $productID,
                        'stock_product_subdep_id'       => $product['product_subdepartment_id'],
                        'stock_product_name'            => $product['product_name'],
                        'stock_product_qty_new'         => 0,
                        'stock_product_price'           => $product['product_purchase_price'],
                        'stock_product_selling_price'   => $product['product_selling_price']
                    ]);
                    $this->serverDB->table('stock_initial')->insert([
                        'branch_id'                     => 3,
                        'product_id'                    => $productID,
                        'stock_initial_period'          => date('Y'),
                        'stock_initial_quantity'        => 0,
                        'stock_initial_nominal'         => $product['product_selling_price'],
                        'stock_initial_created_by'      => session()->get('user_id'),
                        'stock_initial_created_at'      => date('Y-m-d H:i:s')
                    ]);
                } elseif (session()->get('branch_id') == 2) {
                    $this->serverDB->table('stock_product')->insert([
                        'branch_id'                     => 2,
                        'product_id'                    => $productID,
                        'stock_product_subdep_id'       => $product['product_subdepartment_id'],
                        'stock_product_name'            => $product['product_name'],
                        'stock_product_qty_new'         => $product['stock_product_qty_new'],
                        'stock_product_price'           => $product['product_purchase_price'],
                        'stock_product_selling_price'   => $product['product_selling_price']
                    ]);
                    $this->serverDB->table('stock_initial')->insert([
                        'branch_id'                     => 2,
                        'product_id'                    => $productID,
                        'stock_initial_period'          => date('Y'),
                        'stock_initial_quantity'        => $product['stock_product_qty_new'],
                        'stock_initial_nominal'         => $product['product_selling_price'],
                        'stock_initial_created_by'      => session()->get('user_id'),
                        'stock_initial_created_at'      => date('Y-m-d H:i:s')
                    ]);
                    $this->serverDB->table('stock_product')->insert([
                        'branch_id'                     => 1,
                        'product_id'                    => $productID,
                        'stock_product_subdep_id'       => $product['product_subdepartment_id'],
                        'stock_product_name'            => $product['product_name'],
                        'stock_product_qty_new'         => 0,
                        'stock_product_price'           => $product['product_purchase_price'],
                        'stock_product_selling_price'   => $product['product_selling_price']
                    ]);
                    $this->serverDB->table('stock_initial')->insert([
                        'branch_id'                     => 1,
                        'product_id'                    => $productID,
                        'stock_initial_period'          => date('Y'),
                        'stock_initial_quantity'        => 0,
                        'stock_initial_nominal'         => $product['product_selling_price'],
                        'stock_initial_created_by'      => session()->get('user_id'),
                        'stock_initial_created_at'      => date('Y-m-d H:i:s')
                    ]);
                    $this->serverDB->table('stock_product')->insert([
                        'branch_id'                     => 3,
                        'product_id'                    => $productID,
                        'stock_product_subdep_id'       => $product['product_subdepartment_id'],
                        'stock_product_name'            => $product['product_name'],
                        'stock_product_qty_new'         => 0,
                        'stock_product_price'           => $product['product_purchase_price'],
                        'stock_product_selling_price'   => $product['product_selling_price']
                    ]);
                    $this->serverDB->table('stock_initial')->insert([
                        'branch_id'                     => 3,
                        'product_id'                    => $productID,
                        'stock_initial_period'          => date('Y'),
                        'stock_initial_quantity'        => 0,
                        'stock_initial_nominal'         => $product['product_selling_price'],
                        'stock_initial_created_by'      => session()->get('user_id'),
                        'stock_initial_created_at'      => date('Y-m-d H:i:s')
                    ]);
                } elseif (session()->get('branch_id') == 3) {
                    $this->serverDB->table('stock_product')->insert([
                        'branch_id'                     => 3,
                        'product_id'                    => $productID,
                        'stock_product_subdep_id'       => $product['product_subdepartment_id'],
                        'stock_product_name'            => $product['product_name'],
                        'stock_product_qty_new'         => $product['stock_product_qty_new'],
                        'stock_product_price'           => $product['product_purchase_price'],
                        'stock_product_selling_price'   => $product['product_selling_price']
                    ]);
                    $this->serverDB->table('stock_initial')->insert([
                        'branch_id'                     => 3,
                        'product_id'                    => $productID,
                        'stock_initial_period'          => date('Y'),
                        'stock_initial_quantity'        => $product['stock_product_qty_new'],
                        'stock_initial_nominal'         => $product['product_selling_price'],
                        'stock_initial_created_by'      => session()->get('user_id'),
                        'stock_initial_created_at'      => date('Y-m-d H:i:s')
                    ]);
                    $this->serverDB->table('stock_product')->insert([
                        'branch_id'                     => 1,
                        'product_id'                    => $productID,
                        'stock_product_subdep_id'       => $product['product_subdepartment_id'],
                        'stock_product_name'            => $product['product_name'],
                        'stock_product_qty_new'         => 0,
                        'stock_product_price'           => $product['product_purchase_price'],
                        'stock_product_selling_price'   => $product['product_selling_price']
                    ]);
                    $this->serverDB->table('stock_initial')->insert([
                        'branch_id'                     => 1,
                        'product_id'                    => $productID,
                        'stock_initial_period'          => date('Y'),
                        'stock_initial_quantity'        => 0,
                        'stock_initial_nominal'         => $product['product_selling_price'],
                        'stock_initial_created_by'      => session()->get('user_id'),
                        'stock_initial_created_at'      => date('Y-m-d H:i:s')
                    ]);
                    $this->serverDB->table('stock_product')->insert([
                        'branch_id'                     => 2,
                        'product_id'                    => $productID,
                        'stock_product_subdep_id'       => $product['product_subdepartment_id'],
                        'stock_product_name'            => $product['product_name'],
                        'stock_product_qty_new'         => 0,
                        'stock_product_price'           => $product['product_purchase_price'],
                        'stock_product_selling_price'   => $product['product_selling_price']
                    ]);
                    $this->serverDB->table('stock_initial')->insert([
                        'branch_id'                     => 2,
                        'product_id'                    => $productID,
                        'stock_initial_period'          => date('Y'),
                        'stock_initial_quantity'        => 0,
                        'stock_initial_nominal'         => $product['product_selling_price'],
                        'stock_initial_created_by'      => session()->get('user_id'),
                        'stock_initial_created_at'      => date('Y-m-d H:i:s')
                    ]);
                }
            } else {
                $produkNonServer =  $this->serverDB->table('products')->getWhere(['product_sku' => $product['product_sku'], 'product_created_at' => $product['product_created_at']])->getRowArray();
                $this->serverDB->table('products')->update([
                    'product_subdepartment_id'  => $product['product_subdepartment_id'],
                    'product_name'              => $product['product_name'],
                    'product_purchase_price'    => $product['product_purchase_price'],
                    'product_selling_price'     => $product['product_selling_price'],
                    'product_points'            => $product['product_points'],
                    'product_created_at'        => $product['product_created_at'],
                    'product_updated_at'        => $product['product_updated_at']
                ], ['product_sku' => $product['product_sku']]);
                $this->serverDB->table('stock_initial')->update([
                    'stock_initial_nominal'         => $product['product_selling_price'],
                    'stock_initial_updated_at'      => date('Y-m-d H:i:s')
                ], [
                    'product_id'                    => $produkNonServer['id'],
                    'branch_id'                     => session()->get('branch_id')
                ]);

                $this->serverDB->table('stock_product')->update([
                    'stock_product_subdep_id'       => $product['product_subdepartment_id'],
                    'stock_product_name'            => $product['product_name'],
                    'stock_product_price'           => $product['product_purchase_price'],
                    'stock_product_selling_price'   => $product['product_selling_price']
                ],  [
                    'product_id'                    => $produkNonServer['id'],
                    'branch_id'                     => session()->get('branch_id')
                ]);
                $this->serverDB->table('stock_card')->insert([
                    'branch_id'                     => session()->get('branch_id'),
                    'product_id'                    => $produkNonServer['id'],
                    'purchase_id'                   => "Download Data Server",
                    'stock_card_income_nominal'     => 0,
                    'stock_card_created_at'         => date('Y-m-d H:i:s'),
                ]);
            }
        }
        if ($this->serverDB->transStatus() === false) {
            $this->serverDB->transRollback();
            return false;
        } else {
            $this->serverDB->transCommit();
            return true;
        }
    }
    public function syncEmployee()
    {
        $this->serverDB->transBegin();
        $Employee = $this->db->table('employee')
            ->getWhere(['MONTH(employee_updated_at)' =>  date('m')])->getResultArray();
        foreach ($Employee as  $employee) {
            $checkingEmployee = $this->serverDB->table('employee')->where(['nip' => $employee['nip']])->countAllResults();
            if ($checkingEmployee == 0) {
                $this->serverDB->table('employee')->insert([
                    'nip'                     => $employee['nip'],
                    'employee_name'           => $employee['employee_name'],
                    'employee_address'        => $employee['employee_address'],
                    'employee_telephone'      => $employee['employee_telephone'],
                    'employee_province_id'    => $employee['employee_province_id'],
                    'employee_city_id'        => $employee['employee_city_id'],
                    'employee_subdistrict_id' => $employee['employee_subdistrict_id'],
                    'employee_created_at'     => $employee['employee_created_at'],
                ]);
            } else {
                $this->serverDB->table('employee')->update([
                    'employee_name'           => $employee['employee_name'],
                    'employee_address'        => $employee['employee_address'],
                    'employee_telephone'      => $employee['employee_telephone'],
                    'employee_province_id'    => $employee['employee_province_id'],
                    'employee_city_id'        => $employee['employee_city_id'],
                    'employee_subdistrict_id' => $employee['employee_subdistrict_id'],
                    'employee_updated_at'     => $employee['employee_updated_at'],
                ], ['nip' => $employee['nip']]);
            }
        }
        $Users = $this->db->table('users')->getWhere(['MONTH(updated_at)' =>  date('m')])->getResultArray();
        foreach ($Users as  $user) {
            $checkingUser = $this->serverDB->table('users')->where(['nip' => $user['nip'], 'branch' => session()->get('branch_id')])->countAllResults();
            if ($checkingUser == 0) {
                $this->serverDB->table('users')->insert([
                    'nip'           => $user['nip'],
                    'fullname'      => $user['fullname'],
                    'username'      => $user['username'],
                    'password'      => $user['password'],
                    'role'          => $user['role'],
                    'branch'        => $user['branch'],
                    'created_at'    => $user['created_at'],
                ]);
            } else {
                $this->serverDB->table('users')->update([
                    'fullname'      => $user['fullname'],
                    'username'      => $user['username'],
                    'password'      => $user['password'],
                    'role'          => $user['role'],
                    'branch'        => $user['branch'],
                    'updated_at'    => $user['updated_at'],
                ], ['nip' => $user['nip']]);
            }
        }


        if ($this->serverDB->transStatus() === false) {
            $this->serverDB->transRollback();
            return false;
        } else {
            $this->serverDB->transCommit();
            return true;
        }
    }
    public function syncStockTransfer()
    {
        $this->serverDB->transBegin();
        #Table Stock Transfer
        $StockTransfer = $this->db->table('stock_transfer')
            ->groupStart()
            ->where('branch_origin = ', session()->get('branch_id'))
            ->orGroupStart()
            ->where('branch_destination = ', session()->get('branch_id'))
            ->groupEnd()
            ->groupEnd()
            ->where('request_at > DATE_SUB(NOW(),INTERVAL 2 WEEK)')->get()->getResultArray();
        foreach ($StockTransfer as $stockTransfer) {
            $employeeReq = $this->db->table('employee')->select('nip, id')->getWhere(['id' => $stockTransfer['request_by']])->getRowArray();
            $requestBy = $this->serverDB->table('employee')->select('nip, id')->getWhere(['nip' => $employeeReq['nip']])->getRowArray();
            $employeeRec = $this->db->table('employee')->select('nip, id')->getWhere(['id' => $stockTransfer['received_by']])->getRowArray();
            if ($requestBy) {
                if ($employeeRec != null) {
                    $receive = $this->serverDB->table('employee')->select('nip, id')->getWhere(['nip' => $employeeRec['nip']])->getRowArray();
                    $receiveBy = $receive['id'];
                } else {
                    $receiveBy = 0;
                }
            } else {
                $this->serverDB->transRollback();
                return 'employee';
            }
            $checkingStockTransfer = $this->serverDB->table('stock_transfer')->where(['id' => $stockTransfer['id']])->countAllResults();
            if ($checkingStockTransfer == 0) {
                $this->serverDB->table('stock_transfer')->insert([
                    'id'                    => $stockTransfer['id'],
                    'branch_origin'         => $stockTransfer['branch_origin'],
                    'branch_destination'    => $stockTransfer['branch_destination'],
                    'status'                => $stockTransfer['status'],
                    'request_by'            => $requestBy['id'],
                    'request_at'            => $stockTransfer['request_at'],
                    'shipped_at'            => $stockTransfer['shipped_at'],
                    'received_by'           => $receiveBy,
                    'received_at'           => $stockTransfer['received_at'],
                ]);
            } else {
                $this->serverDB->table('stock_transfer')->update([
                    'status'                => $stockTransfer['status'],
                    'request_by'            => $requestBy['id'],
                    'received_by'           => $receiveBy,
                    'received_at'           => $stockTransfer['received_at'],
                ], ['request_at' => $stockTransfer['request_at'], 'id' => $stockTransfer['id']]);
            }
            #Stock Transfer Product
            $StockTransferProduct = $this->db->table('stock_transfer_product')->getWhere(['stock_transfer_id' => $stockTransfer['id']])->getResultArray();
            foreach ($StockTransferProduct as $stockTransferProduct) {
                $checkingStockTransferProduct = $this->serverDB->table('stock_transfer_product')->where(['stock_transfer_id' => $stockTransferProduct['stock_transfer_id'], 'product_id' => $stockTransferProduct['product_id']])->countAllResults();

                if ($checkingStockTransferProduct == 0) {
                    $this->serverDB->table('stock_transfer_product')->insert([
                        'stock_transfer_id'                 => $stockTransferProduct['stock_transfer_id'],
                        'product_id'                        => $stockTransferProduct['product_id'],
                        'stock_transfer_product_name'       => $stockTransferProduct['stock_transfer_product_name'],
                        'stock_transfer_product_quantity'   => $stockTransferProduct['stock_transfer_product_quantity'],
                        'stock_transfer_product_receive'    => $stockTransferProduct['stock_transfer_product_receive'],
                        'stock_order_price_product'         => $stockTransferProduct['stock_order_price_product'],
                    ]);
                    //update All Data Stock on Product
                    $stockProductnonServer = $this->db->table('stock_product')->select('branch_id, product_id, stock_product_qty_new')->getWhere(['product_id' => $stockTransferProduct['product_id'], 'branch_id' => session()->get('branch_id')])->getRowArray();
                    //table Products
                    $product = $this->db->table('products')->select('id, product_stock')->where('id', $stockTransferProduct['product_id'])->get()->getRowArray();
                    $this->serverDB->table('products')->update(['product_stock' => $product['product_stock']], ['id' => $stockTransferProduct['product_id']]);
                    //Table Stock Product
                    $newQtyStockProduct = $stockProductnonServer['stock_product_qty_new'];
                    $this->serverDB->table('stock_product')->update(['stock_product_qty_new' => $newQtyStockProduct], ['branch_id' => session()->get('branch_id'), 'product_id' => $stockTransferProduct['product_id']]);
                    $this->serverDB->table('stock_initial')->update(['stock_initial_quantity' => $newQtyStockProduct, 'stock_initial_updated_at' => date('Y-m-d H:i:s')], ['branch_id' => session()->get('branch_id'), 'product_id' => $stockTransferProduct['product_id']]);
                    if ($stockTransfer['branch_origin'] == session()->get('branch_id')) {
                        $this->serverDB->table('stock_card')->insert([
                            'branch_id'                     => session()->get('branch_id'),
                            'product_id'                    => $stockTransferProduct['product_id'],
                            'sales_id'                      => "Transfer Stok Ke " .  $stockTransfer['branch_destination'],
                            'stock_card_outcome'            => $stockTransferProduct['stock_transfer_product_quantity'],
                            'stock_card_outcome_nominal'    => '',
                            'stock_card_created_at'         => date('Y-m-d H:i:s'),
                            'stock_card_total'              => $newQtyStockProduct
                        ]);
                    } else {
                        $this->serverDB->table('stock_card')->insert([
                            'branch_id'                     => session()->get('branch_id'),
                            'product_id'                    => $stockTransferProduct['product_id'],
                            'sales_id'                      => "Menerima Transfer Stok Ke " .  $stockTransfer['branch_destination'],
                            'stock_card_income'             => $stockTransferProduct['stock_transfer_product_quantity'],
                            'stock_card_income_nominal'    => '',
                            'stock_card_created_at'         => date('Y-m-d H:i:s'),
                            'stock_card_total'              => $newQtyStockProduct
                        ]);
                    }
                } else {
                    $this->serverDB->table('stock_transfer_product')->update([
                        'stock_transfer_product_name'       => $stockTransferProduct['stock_transfer_product_name'],
                        'stock_transfer_product_receive'    => $stockTransferProduct['stock_transfer_product_receive'],
                        'stock_order_price_product'         => $stockTransferProduct['stock_order_price_product'],
                    ], [
                        'stock_transfer_id'                 => $stockTransferProduct['stock_transfer_id'],
                        'product_id'                        => $stockTransferProduct['product_id'],
                    ]);
                    $stockProductnonServer = $this->db->table('stock_product')->select('branch_id, product_id, stock_product_qty_new')->getWhere(['product_id' => $stockTransferProduct['product_id'], 'branch_id' => session()->get('branch_id')])->getRowArray();
                    //table Products
                    $product = $this->db->table('products')->select('id, product_stock')->where('id', $stockTransferProduct['product_id'])->get()->getRowArray();
                    $this->serverDB->table('products')->update(['product_stock' => $product['product_stock']], ['id' => $stockTransferProduct['product_id']]);
                    //Table Stock Product
                    $newQtyStockProduct = $stockProductnonServer['stock_product_qty_new'];
                    $this->serverDB->table('stock_product')->update(['stock_product_qty_new' => $newQtyStockProduct], ['branch_id' => session()->get('branch_id'), 'product_id' => $stockTransferProduct['product_id']]);
                    $this->serverDB->table('stock_initial')->update(['stock_initial_quantity' => $newQtyStockProduct, 'stock_initial_updated_at' => date('Y-m-d H:i:s')], ['branch_id' => session()->get('branch_id'), 'product_id' => $stockTransferProduct['product_id']]);
                    if ($stockTransfer['branch_origin'] == session()->get('branch_id')) {
                        $this->serverDB->table('stock_card')->insert([
                            'branch_id'                     => session()->get('branch_id'),
                            'product_id'                    => $stockTransferProduct['product_id'],
                            'sales_id'                      => "Transfer Stok Ke " .  $stockTransfer['branch_destination'],
                            'stock_card_outcome'            => $stockTransferProduct['stock_transfer_product_quantity'],
                            'stock_card_outcome_nominal'    => '',
                            'stock_card_created_at'         => date('Y-m-d H:i:s'),
                            'stock_card_total'              => $newQtyStockProduct
                        ]);
                    } else {
                        $this->serverDB->table('stock_card')->insert([
                            'branch_id'                     => session()->get('branch_id'),
                            'product_id'                    => $stockTransferProduct['product_id'],
                            'sales_id'                      => "Menerima Transfer Stok Ke " .  $stockTransfer['branch_destination'],
                            'stock_card_income'             => $stockTransferProduct['stock_transfer_product_quantity'],
                            'stock_card_income_nominal'    => '',
                            'stock_card_created_at'         => date('Y-m-d H:i:s'),
                            'stock_card_total'              => $newQtyStockProduct
                        ]);
                    }
                }
            }
        }

        if ($this->serverDB->transStatus() === false) {
            $this->serverDB->transRollback();
            return false;
        } else {
            $this->serverDB->transCommit();
            return true;
        }
    }
    public function syncCustomer()
    {
        $this->serverDB->transBegin();
        $Customers = $this->db->table('customers')
            ->GroupStart()
            ->orGroupStart()
            ->where(['MONTH(customer_updated_at)' =>  date('m'), 'YEAR(customer_updated_at)' =>  date('Y')])
            ->orGroupStart()
            ->where(['MONTH(customer_created_at)' =>  date('m'), 'YEAR(customer_created_at)' =>  date('Y')])
            ->groupEnd()
            ->groupEnd()
            ->groupEnd()
            ->get()->getResultArray();
        foreach ($Customers as $customer) {
            $checkingCustomer = $this->serverDB->table('customers')->where(['customer_code' => $customer['customer_code']])->countAllResults();
            if ($checkingCustomer == 0) {
                $this->serverDB->table('customers')->insert([
                    'customer_code'             => $customer['customer_code'],
                    'customer_fullname'         => $customer['customer_fullname'],
                    'customer_birthday'         => $customer['customer_birthday'],
                    'customer_address'          => $customer['customer_address'],
                    'customer_subdistrict'      => $customer['customer_subdistrict'],
                    'customer_city'             => $customer['customer_city'],
                    'customer_province'         => $customer['customer_province'],
                    'customer_telephone'        => $customer['customer_telephone'],
                    'customer_email'            => $customer['customer_email'],
                    'customer_points'           => $customer['customer_points'],
                    'customer_is_active'        => $customer['customer_is_active'],
                    'customer_created_by'       => $customer['customer_created_by'],
                    'customer_created_at'       => $customer['customer_created_at'],
                    'customer_updated_by'       => $customer['customer_updated_by'],
                    'customer_updated_at'       => $customer['customer_updated_at'],
                ]);
            } else {
                $this->serverDB->table('customers')->update([
                    'customer_fullname'         => $customer['customer_fullname'],
                    'customer_birthday'         => $customer['customer_birthday'],
                    'customer_address'          => $customer['customer_address'],
                    'customer_subdistrict'      => $customer['customer_subdistrict'],
                    'customer_city'             => $customer['customer_city'],
                    'customer_province'         => $customer['customer_province'],
                    'customer_telephone'        => $customer['customer_telephone'],
                    'customer_email'            => $customer['customer_email'],
                    'customer_points'           => $customer['customer_points'],
                    'customer_is_active'        => $customer['customer_is_active'],
                    'customer_created_by'       => $customer['customer_created_by'],
                    'customer_created_at'       => $customer['customer_created_at'],
                    'customer_updated_by'       => $customer['customer_updated_by'],
                    'customer_updated_at'       => $customer['customer_updated_at'],
                ], ['customer_code' => $customer['customer_code']]);
            }
        }
        if ($this->serverDB->transStatus() === false) {
            $this->serverDB->transRollback();
            return false;
        } else {
            $this->serverDB->transCommit();
            return true;
        }
    }
    public function syncProductCategory()
    {
        $this->serverDB->transBegin();
        $ProductDivisi = $this->db->table('product_divisi')->get()->getResultArray();
        foreach ($ProductDivisi as $productDivisi) {
            $checkingProductDivisi = $this->serverDB->table('product_divisi')->where(['product_divisi_code' => $productDivisi['product_divisi_code']])->countAllResults();
            $getMax    = $this->serverDB->table('product_divisi')->selectMax('product_divisi.id')->get()->getRowArray();
            $id = $getMax['id'] + 1;
            if ($checkingProductDivisi == 0) {
                $this->serverDB->table('product_divisi')->insert([
                    'id'                  => $id,
                    'product_divisi_name' => $productDivisi['product_divisi_name'],
                    'product_divisi_code' => $id
                ]);
            } else {
                $this->serverDB->table('product_divisi')->update([
                    'product_divisi_name' => $productDivisi['product_divisi_name']
                ], ['product_divisi_code' => $productDivisi['product_divisi_code']]);
            }
        }

        $ProductDepartment = $this->db->table('product_department')->get()->getResultArray();
        foreach ($ProductDepartment as $productDepartment) {
            $checkingproductDepartment = $this->serverDB->table('product_department')->where(['product_department_code' => $productDepartment['product_department_code'], 'product_department_code' => $productDepartment['product_department_code'], 'product_divisi_id' => $productDepartment['product_divisi_id']])->countAllResults();
            $getMaxid    = $this->serverDB->table('product_department')->selectMax('product_department.id')->get()->getRowArray();
            $idDepartment = $getMaxid['id'] + 1;
            if ($checkingproductDepartment == 0) {
                $this->serverDB->table('product_department')->insert([
                    'product_department_code'   => $idDepartment,
                    'product_department_name'   => $productDepartment['product_department_name'],
                    'product_divisi_id'         => $productDepartment['product_divisi_id']
                ]);
            } else {
                $this->serverDB->table('product_department')->update([
                    'product_department_name'   => $productDepartment['product_department_name'],
                    'product_divisi_id'         => $productDepartment['product_divisi_id']
                ], ['product_department_code' => $productDepartment['product_department_code']]);
            }
        }

        $ProductSubdepartment = $this->db->table('product_subdepartment')->get()->getResultArray();
        foreach ($ProductSubdepartment as $productSubdepartment) {
            $checkingproductSubdepartment = $this->serverDB->table('product_subdepartment')->where(['product_subdep_code' => $productSubdepartment['product_subdep_code'], 'product_subdep_code' => $productSubdepartment['product_subdep_code'], 'product_divisi_id' => $productSubdepartment['product_divisi_id'], 'product_department_id' => $productSubdepartment['product_department_id']])->countAllResults();
            if ($checkingproductSubdepartment == 0) {
                $this->serverDB->table('product_subdepartment')->insert([
                    'product_subdep_code'       => $productSubdepartment['product_subdep_code'],
                    'product_subdep_name'       => $productSubdepartment['product_subdep_name'],
                    'product_divisi_id'         => $productSubdepartment['product_divisi_id'],
                    'product_department_id'     => $productSubdepartment['product_department_id']
                ]);
            } else {
                $this->serverDB->table('product_subdepartment')->update([
                    'product_subdep_name'       => $productSubdepartment['product_subdep_name'],
                    'product_divisi_id'         => $productSubdepartment['product_divisi_id'],
                    'product_department_id'     => $productSubdepartment['product_department_id']
                ], ['product_subdep_code' => $productSubdepartment['product_subdep_code'],]);
            }
        }
        if ($this->serverDB->transStatus() === false) {
            $this->serverDB->transRollback();
            return false;
        } else {
            $this->serverDB->transCommit();
            return true;
        }
    }
    public function syncStockOpname()
    {
        $this->serverDB->transBegin();
        $StockOpname = $this->db->table('stock_opname')
            ->where('stock_opname_created_at > DATE_SUB(NOW(),INTERVAL 1 WEEK)')
            ->getwhere(['stock_opname_branch_id' => session()->get('branch_id')])->getResultArray();
        foreach ($StockOpname as  $stockOpname) {
            $checkingStockOpname = $this->serverDB->table('stock_opname')->where(['stock_opname_created_at' => $stockOpname['stock_opname_created_at'], 'stock_opname_branch_id' => session()->get('branch_id')])->countAllResults();
            if ($checkingStockOpname == 0) {
                $this->serverDB->table('stock_opname')->insert([
                    'stock_opname_branch_id'                     => $stockOpname['stock_opname_branch_id'],
                    'stock_opname_product_id'                    => $stockOpname['stock_opname_product_id'],
                    'stock_opname_product_name'                  => $stockOpname['stock_opname_product_name'],
                    'stock_opname_qty'                           => $stockOpname['stock_opname_qty'],
                    'stock_opname_qty_display'                   => $stockOpname['stock_opname_qty_display'],
                    'stock_opname_qty_storage'                   => $stockOpname['stock_opname_qty_storage'],
                    'stock_opname_difference'                    => $stockOpname['stock_opname_difference'],
                    'stock_opname_description'                   => $stockOpname['stock_opname_description'],
                    'stock_opname_created_at'                    => $stockOpname['stock_opname_created_at'],
                    'stock_opname_updated_at'                    => $stockOpname['stock_opname_updated_at'],
                    'stock_opname_is_change'                     => $stockOpname['stock_opname_is_change'],
                ]);
                $product = $this->db->table('products')->select('id, product_sku, product_stock')->where(['id' => $stockOpname['stock_opname_product_id']])->get()->getRowArray();
                $productServer =  $this->serverDB->table('products')->select('id, product_sku, product_stock')->where(['product_sku' => $product['product_sku']])->get()->getRowArray();
                if (!$productServer) {
                    return false;
                }
                $stockProductnonServer = $this->db->table('stock_product')->select('branch_id, product_id, stock_product_qty_new')->getWhere(['product_id' => $product['id'], 'branch_id' => session()->get('branch_id')])->getRowArray();
                //table Products
                $this->serverDB->table('products')->update(['product_stock' => $product['product_stock']], ['id' => $productServer['id']]);
                //Table Stock Product
                $newQtyStockProduct = $stockProductnonServer['stock_product_qty_new'];
                if ($newQtyStockProduct <= 0) {
                    $newQtyStockProduct = 0;
                }
                $this->serverDB->table('stock_product')->update(['stock_product_qty_new' => $newQtyStockProduct], ['branch_id' => session()->get('branch_id'), 'product_id' => $productServer['id']]);
                $this->serverDB->table('stock_initial')->update(['stock_initial_quantity' => $newQtyStockProduct, 'stock_initial_updated_at' => date('Y-m-d H:i:s')], ['branch_id' => session()->get('branch_id'), 'product_id' => $productServer['id']]);
                $StockCard = $this->db->table('stock_card')->getWhere(['product_id' => $productServer['id'], 'stock_card_created_at' => $stockOpname['stock_opname_created_at']])->getResultArray();
                foreach ($StockCard as $stockCard) {
                    $checkcard = $this->serverDB->table('stock_card')->where(['product_id' => $stockCard['product_id'], 'stock_card_created_at' => $stockCard['stock_card_created_at']])->countAllResults();
                    if ($checkcard == 0) {
                        $this->serverDB->table('stock_card')->insert([
                            'branch_id'                     => $stockCard['branch_id'],
                            'product_id'                    => $productServer['id'],
                            'purchase_id'                   => $stockCard['purchase_id'],
                            'sales_id'                      => $stockCard['sales_id'],
                            'stock_card_income'             => $stockCard['stock_card_income'],
                            'stock_card_income_nominal'     => $stockCard['stock_card_income_nominal'],
                            'stock_card_outcome'            => $stockCard['stock_card_outcome'],
                            'stock_card_outcome_nominal'    => $stockCard['stock_card_outcome_nominal'],
                            'stock_card_created_at'         => $stockCard['stock_card_created_at'],
                            'stock_card_total'              => $stockCard['stock_card_total'],
                        ]);
                    }
                }
            } else {
                $this->serverDB->table('stock_opname')->update([
                    'stock_opname_product_name'                  => $stockOpname['stock_opname_product_name'],
                    'stock_opname_qty'                           => $stockOpname['stock_opname_qty'],
                    'stock_opname_qty_display'                   => $stockOpname['stock_opname_qty_display'],
                    'stock_opname_qty_storage'                   => $stockOpname['stock_opname_qty_storage'],
                    'stock_opname_difference'                    => $stockOpname['stock_opname_difference'],
                    'stock_opname_description'                   => $stockOpname['stock_opname_description'],
                    'stock_opname_created_at'                    => $stockOpname['stock_opname_created_at'],
                    'stock_opname_updated_at'                    => $stockOpname['stock_opname_updated_at'],
                    'stock_opname_is_change'                     => $stockOpname['stock_opname_is_change'],
                ], [
                    'stock_opname_branch_id'                     => $stockOpname['stock_opname_branch_id'],
                    'stock_opname_product_id'                    => $stockOpname['stock_opname_product_id'],
                ]);
                $product = $this->db->table('products')->select('id, product_sku, product_stock')->where(['id' => $stockOpname['stock_opname_product_id']])->get()->getRowArray();
                $productServer =  $this->serverDB->table('products')->select('id, product_sku, product_stock')->where(['product_sku' => $product['product_sku']])->get()->getRowArray();
                if (!$productServer) {
                    return false;
                }
                $stockProductnonServer = $this->db->table('stock_product')->select('branch_id, product_id, stock_product_qty_new')->getWhere(['product_id' => $product['id'], 'branch_id' => session()->get('branch_id')])->getRowArray();
                //table Products
                $this->serverDB->table('products')->update(['product_stock' => $product['product_stock']], ['id' => $productServer['id']]);
                //Table Stock Product
                $newQtyStockProduct = $stockProductnonServer['stock_product_qty_new'];
                if ($newQtyStockProduct <= 0) {
                    $newQtyStockProduct = 0;
                }
                $this->serverDB->table('stock_product')->update(['stock_product_qty_new' => $newQtyStockProduct], ['branch_id' => session()->get('branch_id'), 'product_id' => $productServer['id']]);
                $this->serverDB->table('stock_initial')->update(['stock_initial_quantity' => $newQtyStockProduct, 'stock_initial_updated_at' => date('Y-m-d H:i:s')], ['branch_id' => session()->get('branch_id'), 'product_id' => $productServer['id']]);
                $StockCard = $this->db->table('stock_card')->getWhere(['product_id' => $productServer['id'], 'stock_card_created_at' => $stockOpname['stock_opname_created_at']])->getResultArray();
                foreach ($StockCard as $stockCard) {
                    $checkcard = $this->serverDB->table('stock_card')->where(['product_id' => $stockCard['product_id'], 'stock_card_created_at' => $stockCard['stock_card_created_at']])->countAllResults();
                    if ($checkcard == 0) {
                        $this->serverDB->table('stock_card')->insert([
                            'branch_id'                     => $stockCard['branch_id'],
                            'product_id'                    => $productServer['id'],
                            'purchase_id'                   => $stockCard['purchase_id'],
                            'sales_id'                      => $stockCard['sales_id'],
                            'stock_card_income'             => $stockCard['stock_card_income'],
                            'stock_card_income_nominal'     => $stockCard['stock_card_income_nominal'],
                            'stock_card_outcome'            => $stockCard['stock_card_outcome'],
                            'stock_card_outcome_nominal'    => $stockCard['stock_card_outcome_nominal'],
                            'stock_card_created_at'         => $stockCard['stock_card_created_at'],
                            'stock_card_total'              => $stockCard['stock_card_total'],
                        ]);
                    }
                }
            }
        }
        if ($this->serverDB->transStatus() === false) {
            $this->serverDB->transRollback();
            return false;
        } else {
            $this->serverDB->transCommit();
            return true;
        }
    }
    public function syncPurchaseOrder()
    {
        $this->serverDB->transBegin();
        $Supplier = $this->db->table('suppliers')->get()->getResultArray();
        foreach ($Supplier as $supplier) {
            $checkSupplier = $this->serverDB->table('suppliers')->where(['supplier_company' => $supplier['supplier_company']])->countAllResults();
            if ($checkSupplier == 0) {
                $this->serverDB->table('suppliers')->insert([
                    'supplier_company'      => $supplier['supplier_company'],
                    'supplier_contact'      => $supplier['supplier_contact'],
                    'supplier_telephone'    => $supplier['supplier_telephone'],
                    'supplier_address'      => $supplier['supplier_address'],
                    'province_id'           => $supplier['province_id'],
                    'city_id'               => $supplier['city_id'],
                    'subdistrict_id'        => $supplier['subdistrict_id'],
                ]);
            } else {
                $this->serverDB->table('suppliers')->update([
                    'supplier_contact'      => $supplier['supplier_contact'],
                    'supplier_telephone'    => $supplier['supplier_telephone'],
                    'supplier_address'      => $supplier['supplier_address'],
                    'province_id'           => $supplier['province_id'],
                    'city_id'               => $supplier['city_id'],
                    'subdistrict_id'        => $supplier['subdistrict_id'],
                ], ['supplier_company'      => $supplier['supplier_company'],]);
            }
        }
        $PurchaseOrder = $this->db->table('purchase_order')
            ->where('purchase_order_created_at > DATE_SUB(NOW(),INTERVAL 1 WEEK)')
            ->getwhere(['branch_id' => session()->get('branch_id')])->getResultArray();
        foreach ($PurchaseOrder as  $purchaseOrder) {
            $createdBy = $this->db->table('employee')->select('id, nip')->getWhere(['id' => $purchaseOrder['purchase_order_created_by']])->getRowArray();
            $employeeCreated = $this->serverDB->table('employee')->select('id, nip')->getWhere(['nip' => $createdBy['nip']])->getRowArray();
            if ($employeeCreated == null) {
                $this->serverDB->transRollback();
                return 'created';
            }
            $returned = $this->db->table('employee')->select('id, nip')->getWhere(['id' => $purchaseOrder['purchase_order_returned_by']])->getRowArray();
            if ($returned) {
                $employeeReturned = $this->serverDB->table('employee')->select('id, nip')->getWhere(['nip' => $returned['nip']])->getRowArray();
            } else {
                $employeeReturned['id'] = 0;
            }
            $countpurchase = $this->serverDB->table('purchase_order')->where(['purchase_order_invoice' => $purchaseOrder['purchase_order_invoice'], 'branch_id' => session()->get('branch_id')])->countAllResults();
            if ($countpurchase == 0) {
                $this->serverDB->table('purchase_order')->insert([
                    'purchase_order_invoice'                => $purchaseOrder['purchase_order_invoice'],
                    'purchase_order_invoice_date'           => $purchaseOrder['purchase_order_invoice_date'],
                    'branch_id'                             => $purchaseOrder['branch_id'],
                    'supplier_id'                           => $purchaseOrder['supplier_id'],
                    'purchase_order_cost'                   => $purchaseOrder['purchase_order_cost'],
                    'purchase_order_total'                  => $purchaseOrder['purchase_order_total'],
                    'purchase_order_status'                 => $purchaseOrder['purchase_order_status'],
                    'purchase_order_created_by'             => $employeeCreated['id'],
                    'purchase_order_created_at'             => $purchaseOrder['purchase_order_created_at'],
                    'purchase_order_returned_by'            => $employeeReturned['id'],
                    'purchase_order_return_reason'          => $purchaseOrder['purchase_order_return_reason'],
                    'purchase_order_returned_at'            => $purchaseOrder['purchase_order_returned_at'],
                    'purchase_order_notes'                  => $purchaseOrder['purchase_order_notes'],
                ]);
            } else {
                $this->serverDB->table('purchase_order')->update([
                    'purchase_order_invoice'                => $purchaseOrder['purchase_order_invoice'],
                    'purchase_order_invoice_date'           => $purchaseOrder['purchase_order_invoice_date'],
                    'supplier_id'                           => $purchaseOrder['supplier_id'],
                    'purchase_order_cost'                   => $purchaseOrder['purchase_order_cost'],
                    'purchase_order_total'                  => $purchaseOrder['purchase_order_total'],
                    'purchase_order_status'                 => $purchaseOrder['purchase_order_status'],
                    'purchase_order_created_by'             => $employeeCreated['id'],
                    'purchase_order_created_at'             => $purchaseOrder['purchase_order_created_at'],
                    'purchase_order_returned_by'            => $employeeReturned['id'],
                    'purchase_order_return_reason'          => $purchaseOrder['purchase_order_return_reason'],
                    'purchase_order_returned_at'            => $purchaseOrder['purchase_order_returned_at'],
                    'purchase_order_notes'                  => $purchaseOrder['purchase_order_notes'],
                ], [
                    'purchase_order_invoice'                => $purchaseOrder['purchase_order_invoice'],
                    'branch_id'                             => $purchaseOrder['branch_id']
                ]);
            }
            $PurchaseOrderProduct = $this->db->table('purchase_order_product')->getWhere(['purchase_order_invoice' => $purchaseOrder['purchase_order_invoice']])->getResultArray();
            foreach ($PurchaseOrderProduct as $purchaseOrderProduct) {
                $CheckpurchaseOrderProduct = $this->serverDB->table('purchase_order_product')->where(['purchase_order_invoice' => $purchaseOrderProduct['purchase_order_invoice'], 'product_id' => $purchaseOrderProduct['product_id']])->countAllResults();
                if ($CheckpurchaseOrderProduct == 0) {
                    $this->serverDB->table('purchase_order_product')->insert([
                        'purchase_order_invoice'        => $purchaseOrderProduct['purchase_order_invoice'],
                        'product_id'                    => $purchaseOrderProduct['product_id'],
                        'purchase_order_product_name'   => $purchaseOrderProduct['purchase_order_product_name'],
                        'purchase_order_quantity'       => $purchaseOrderProduct['purchase_order_quantity'],
                        'purchase_order_received'       => $purchaseOrderProduct['purchase_order_received'],
                        'purchase_order_price'          => $purchaseOrderProduct['purchase_order_price'],
                    ]);
                    //update All Data Stock on Product
                    $stockProductnonServer = $this->db->table('stock_product')->select('branch_id, product_id, stock_product_qty_new')->getWhere(['product_id' => $purchaseOrderProduct['product_id'], 'branch_id' => session()->get('branch_id')])->getRowArray();
                    $newQtyStockProduct = $stockProductnonServer['stock_product_qty_new'];
                    //table Products
                    $product = $this->db->table('products')->select('id, product_stock, product_sku')->where(['id' => $purchaseOrderProduct['product_id']])->get()->getRowArray();
                    $productServer = $this->serverDB->table('products')->select('id, product_stock, product_sku')->where(['product_sku' => $product['product_sku']])->get()->getRowArray();
                    if ($productServer == null) {
                        return "product";
                    }
                    $stockProductBranch1 = $this->serverDB->table('stock_product')->select('stock_product_qty_new')->getWhere(['branch_id' => 1, 'product_id' => $productServer['id']])->getRowArray();
                    $stockProductBranch2 = $this->serverDB->table('stock_product')->select('stock_product_qty_new')->getWhere(['branch_id' => 2, 'product_id' => $productServer['id']])->getRowArray();
                    $stockProductBranch3 = $this->serverDB->table('stock_product')->select('stock_product_qty_new')->getWhere(['branch_id' => 3, 'product_id' => $productServer['id']])->getRowArray();
                    if (session()->get('branch_id') == 1) {
                        $newAllStock          = $stockProductBranch2['stock_product_qty_new'] + $stockProductBranch3['stock_product_qty_new'] +  $newQtyStockProduct;
                    } elseif (session()->get('branch_id') == 2) {
                        $newAllStock          = $stockProductBranch1['stock_product_qty_new'] + $stockProductBranch3['stock_product_qty_new'] +  $newQtyStockProduct;
                    } elseif (session()->get('branch_id') == 3) {
                        $newAllStock          = $stockProductBranch1['stock_product_qty_new'] + $stockProductBranch2['stock_product_qty_new'] +  $newQtyStockProduct;
                    }
                    if ($newAllStock < 0) {
                        $newAllStock = 0;
                    }
                    $this->serverDB->table('products')->update(['product_stock' => $newAllStock], ['product_sku' =>  $productServer['product_sku']]);
                    //Table Stock Product
                    $this->serverDB->table('stock_product')->update(['stock_product_qty_new' => $newQtyStockProduct], ['branch_id' => session()->get('branch_id'), 'product_id' => $productServer['id']]);
                    $this->serverDB->table('stock_initial')->update(['stock_initial_quantity' => $newQtyStockProduct, 'stock_initial_updated_at' => date('Y-m-d H:i:s')], ['branch_id' => session()->get('branch_id'), 'product_id' => $productServer['id']]);
                    $this->serverDB->table('stock_card')->insert([
                        'branch_id'                     => session()->get('branch_id'),
                        'product_id'                    => $productServer['id'],
                        'purchase_id'                   => $purchaseOrder['purchase_order_invoice'],
                        'stock_card_income'             => $newQtyStockProduct,
                        'stock_card_income_nominal'     => 0,
                        'stock_card_created_at'         => date('Y-m-d H:i:s'),
                        'stock_card_total'              => $newQtyStockProduct
                    ]);
                } else {
                    $this->serverDB->table('purchase_order_product')->update([
                        'purchase_order_product_name'   => $purchaseOrderProduct['purchase_order_product_name'],
                        'purchase_order_quantity'       => $purchaseOrderProduct['purchase_order_quantity'],
                        'purchase_order_received'       => $purchaseOrderProduct['purchase_order_received'],
                        'purchase_order_price'          => $purchaseOrderProduct['purchase_order_price'],
                    ], [
                        'purchase_order_invoice'        => $purchaseOrderProduct['purchase_order_invoice'],
                        'product_id'                    => $purchaseOrderProduct['product_id'],
                    ]);
                    //update All Data Stock on Product
                    $stockProductnonServer = $this->db->table('stock_product')->select('branch_id, product_id, stock_product_qty_new')->getWhere(['product_id' => $purchaseOrderProduct['product_id'], 'branch_id' => session()->get('branch_id')])->getRowArray();
                    $newQtyStockProduct = $stockProductnonServer['stock_product_qty_new'];
                    //table Products
                    $product = $this->db->table('products')->select('id, product_stock, product_sku')->where(['id' => $purchaseOrderProduct['product_id']])->get()->getRowArray();
                    $productServer = $this->serverDB->table('products')->select('id, product_stock, product_sku')->where(['product_sku' => $product['product_sku']])->get()->getRowArray();
                    if ($productServer == null) {
                        return "product";
                    }
                    $stockProductBranch1 = $this->serverDB->table('stock_product')->select('stock_product_qty_new')->getWhere(['branch_id' => 1, 'product_id' => $productServer['id']])->getRowArray();
                    $stockProductBranch2 = $this->serverDB->table('stock_product')->select('stock_product_qty_new')->getWhere(['branch_id' => 2, 'product_id' => $productServer['id']])->getRowArray();
                    $stockProductBranch3 = $this->serverDB->table('stock_product')->select('stock_product_qty_new')->getWhere(['branch_id' => 3, 'product_id' => $productServer['id']])->getRowArray();
                    if (session()->get('branch_id') == 1) {
                        $newAllStock          = $stockProductBranch2['stock_product_qty_new'] + $stockProductBranch3['stock_product_qty_new'] +  $newQtyStockProduct;
                    } elseif (session()->get('branch_id') == 2) {
                        $newAllStock          = $stockProductBranch1['stock_product_qty_new'] + $stockProductBranch3['stock_product_qty_new'] +  $newQtyStockProduct;
                    } elseif (session()->get('branch_id') == 3) {
                        $newAllStock          = $stockProductBranch1['stock_product_qty_new'] + $stockProductBranch2['stock_product_qty_new'] +  $newQtyStockProduct;
                    }
                    if ($newAllStock < 0) {
                        $newAllStock = 0;
                    }
                    $this->serverDB->table('products')->update(['product_stock' => $newAllStock], ['product_sku' =>  $productServer['product_sku']]);
                    //Table Stock Product
                    $this->serverDB->table('stock_product')->update(['stock_product_qty_new' => $newQtyStockProduct], ['branch_id' => session()->get('branch_id'), 'product_id' => $productServer['id']]);
                    $this->serverDB->table('stock_initial')->update(['stock_initial_quantity' => $newQtyStockProduct, 'stock_initial_updated_at' => date('Y-m-d H:i:s')], ['branch_id' => session()->get('branch_id'), 'product_id' => $productServer['id']]);
                    $this->serverDB->table('stock_card')->insert([
                        'branch_id'                     => session()->get('branch_id'),
                        'product_id'                    => $productServer['id'],
                        'purchase_id'                   => $purchaseOrder['purchase_order_invoice'],
                        'stock_card_income'             => $newQtyStockProduct,
                        'stock_card_income_nominal'     => 0,
                        'stock_card_created_at'         => date('Y-m-d H:i:s'),
                        'stock_card_total'              => $newQtyStockProduct
                    ]);
                }
            }
        }

        if ($this->serverDB->transStatus() === false) {
            $this->serverDB->transRollback();
            return false;
        } else {
            $this->serverDB->transCommit();
            return true;
        }
    }
}
