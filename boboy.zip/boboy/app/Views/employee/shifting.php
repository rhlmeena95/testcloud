<?= $this->extend('layouts/main'); ?>
<?= $this->section('content'); ?>

<h1 class="h3 mb-3">Management <strong><?= $title; ?></strong></h1>

<div class="row layout-top-spacing" id="cancel-row">
	<div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
		<div class="widget-content widget-content-area br-6">
			<div class="row">
				<div class="col-sm-6 float-left">
					<a href="<?= base_url('shifting/createManagementShift'); ?>" class="btn btn-primary">
						<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-plus-circle">
							<circle cx="12" cy="12" r="10"></circle>
							<line x1="12" y1="8" x2="12" y2="16"></line>
							<line x1="8" y1="12" x2="16" y2="12"></line>
						</svg>
						Buat Shift Karyawan
					</a>
					<!-- </?php if (session()->get('role') == 1) : ?>
					</?php endif ?> -->
				</div>
				<div class="col-sm-6">
					<form action="<?= base_url('shifting'); ?>" method="get">
						<div class="input-group">
							<select class="custom-select" id="employee" name="e">
								<option value="">-- Pilih Karyawan -- </option>
								<?php foreach ($Employee as $employee) : ?>
									<option value="<?= $employee['employeeNIP']; ?>" <?= ($emp == $employee['employeeNIP']) ? 'selected' : ''; ?>><?= $employee['employee_name']; ?></option>
								<?php endforeach; ?>
							</select>
							<select class="custom-select" id="month" name="m" aria-label="Example select with button addon" required>
								<option value="">-- Pilih Bulan --</option>
								<?php
								for ($i = 01; $i <= 12; $i++) : ?>
									<option value="<?= $i; ?>" <?= ($month) ? ($i == $month) ? 'selected' : '' : ''; ?>><?= bulan($i); ?> </option>
								<?php endfor; ?>
							</select>
							<div class="input-group-append">
								<button class="btn btn-primary" type="submit">Tampilkan</button>
							</div>
						</div>
					</form>
				</div>
			</div>
			<table class="table table-striped dataTable" style="width:100%">
				<thead class="text-center">
					<th>#</th>
					<th>Nama Karyawan</th>
					<th>Tanggal</th>
					<th>Shift</th>
					<th>Aksi</th>
				</thead>
				<tbody>
					<?php if ($EmployeeShifting != null) : ?>
						<?php
						$i = 1;
						foreach ($EmployeeShifting as $shift) : ?>
							<tr class="text-center">
								<td><?= $i++; ?></td>
								<td><?= $shift['employee_name']; ?></td>
								<td><?= longdate_indo($shift['attandance_date']); ?></td>
								<td><?= $shift['shift_name']; ?></td>
								<td>
									<div class="btn-group dropright mb-4 mr-2" role="group">
										<button id="btnDropRightOutline" type="button" class="btn btn-outline-primary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Manage
											<polyline points="9 18 15 12 9 6"></polyline>
											</svg>
										</button>
										<div class="dropdown-menu" aria-labelledby="btnDropRightOutline">
											<button data-toggle="modal" data-target="#updateEmployeeShift" class="dropdown-item btnUpdate" data-id="<?= $shift['attandanceID']; ?>" data-nip="<?= $shift['attandance_nip']; ?>" data-date="<?= $shift['attandance_date']; ?>" data-shift="<?= $shift['attandance_shift_id']; ?>">
												<svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-edit text-primary">
													<path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
													<path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
												</svg>
												Ubah
											</button>
											<form action="<?= base_url('shifting/deleteManagementShift'); ?>" method="post" class="d-inline">
												<input type="hidden" name="shiftManagementID" id="shiftManagementID" value="<?= $shift['attandanceID']; ?>">
												<input type="hidden" name="_method" value="DELETE">
												<button type="submit" class="dropdown-item " onclick="return confirm('Apakah anda yakin mengapus ?')">
													<svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-trash-2 text-danger">
														<polyline points="3 6 5 6 21 6"></polyline>
														<path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
														<line x1="10" y1="11" x2="10" y2="17"></line>
														<line x1="14" y1="11" x2="14" y2="17"></line>
													</svg> Hapus
												</button>
											</form>
										</div>
									</div>

								</td>
							</tr>
						<?php endforeach; ?>
					<?php endif; ?>
				</tbody>
			</table>
		</div>
	</div>
</div>




<div class="modal fade" id="updateEmployeeShift" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="updateEmployeeShiftLabel" aria-hidden="true">
	<div class="modal-dialog modal-lg modal-dialog-centered" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="updateEmployeeShiftLabel">Tambah Shift Baru</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
			</div>
			<div class="modal-body">
				<form action="<?= base_url('shifting/updateManagementShift'); ?>" method="post">
					<div class="table-responsive">
						<table class="table mb-4" id="EmployeeShift">
							<thead>
								<tr>
									<th class="text-center">Nama Pegawai</th>
									<th>Shift Karyawan</th>
									<th class="">Tanggal</th>
								</tr>
							</thead>
							<tbody>
								<tr>
									<td>
										<input type="hidden" id="employeeID" name="inputEmployeeID">
										<select class="custom-select" id="EmployeeNIP" name="inputEmployee">
											<option value="">-- Pilih Karyawan -- </option>
											<?php foreach ($Employee as $employee) : ?>
												<option value="<?= $employee['employeeNIP']; ?>"><?= $employee['employee_name']; ?></option>
											<?php endforeach; ?>
										</select>
									</td>
									<td>
										<select class="custom-select" id="ShiftEmployee" name="inputEmployeeShift">
											<option value="">-- Pilih Shift -- </option>
											<?php foreach ($Shifting as $shift) : ?>
												<option value="<?= $shift['id']; ?>"><?= $shift['shift_name']; ?></option>
											<?php endforeach; ?>
										</select>
									</td>
									<td>
										<input type="date" class="form-control  active" name="inputDateShift" id="DateEmployee" required>
									</td>
								</tr>
							</tbody>
						</table>
						<div class="text-right">
							<button type="submit" class="btn btn-primary btn-lg">Simpan</button>
						</div>
				</form>
			</div>
		</div>
	</div>
</div>

<script>
	$('.btnUpdate').click(function() {
		const id = $(this).data("id");
		const nip = $(this).data("nip")
		const date = $(this).data("date")
		const shift = $(this).data("shift")

		$('#EmployeeNIP').val(nip);
		$('#ShiftEmployee').val(shift);
		$('#DateEmployee').val(date);
		$('#employeeID').val(id);
	});
</script>

<?= $this->endSection(); ?>