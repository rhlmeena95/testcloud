<?php

namespace App\Controllers\Settings;

use App\Controllers\BaseController;
use App\Models\MasterModel;
use App\Models\SalesModel;

class Discount extends BaseController
{
	function __construct()
	{
		$this->SalesModel = new SalesModel();
		$this->MasterModel = new MasterModel();
	}
	public function index()
	{
		$data = array_merge($this->data, [
			'category'  		=> 'Pengaturan',
			'title'         	=> 'Diskon',
			'discountMember'	=> $this->SalesModel->getDiscountMembership(),
			'discountItem'		=> $this->SalesModel->getDiscountByMinimumItem(),
			'DiscountCategoryP'	=> $this->SalesModel->getDiscountByCategoryProduct(),
			'DiscountBirthday'	=> $this->SalesModel->getDiscountByBirthday(),
			'Subdepartment'		=> $this->MasterModel->getProductSubdepartment(),
		]);
		return view('settings/discount', $data);
	}
	public function createDiscount()
	{
		$createDiscount = $this->SalesModel->createDiscount($this->request->getPost(null));
		if ($createDiscount) {
			session()->setFlashdata('notif_success', '<b>Berhasil menambah Diskon</b>');
			return redirect()->to(base_url('discount'));
		} else {
			session()->setFlashdata('notif_error', '<b>Gagal menambah Diskon</b>');
			return redirect()->to(base_url('discount'));
		}
	}
	public function updateDiscount()
	{
		$updateDiscount = $this->SalesModel->updateDiscount($this->request->getPost(null));
		if ($updateDiscount) {
			session()->setFlashdata('notif_success', '<b>Berhasil memperbaharui Diskon</b>');
			return redirect()->to(base_url('discount'));
		} else {
			session()->setFlashdata('notif_error', '<b>Gagal memperbaharui Diskon</b>');
			return redirect()->to(base_url('discount'));
		}
	}
	public function updateStatusDiscount()
	{
		$id = $this->request->getPost('id');
		$status =  $this->request->getPost('status');
		$this->SalesModel->updateStatusDiscount($id, $status);
	}
}
