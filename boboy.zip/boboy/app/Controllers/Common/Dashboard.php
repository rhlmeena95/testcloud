<?php

namespace App\Controllers\Common;

use App\Controllers\BaseController;

class Dashboard extends BaseController
{
	public function index()
	{
		$data = array_merge($this->data, [
			'category'      => 'Home',
			'title'         => 'Dashboard'
		]);
		return view('common/dashboard', $data);
	}
}
