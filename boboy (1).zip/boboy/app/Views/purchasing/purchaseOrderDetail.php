<?= $this->extend('layouts/main'); ?>
<?= $this->section('content'); ?>
<style>
    @media print {
        body * {
            visibility: hidden;
        }

        #section-to-print,
        #section-to-print * {
            visibility: visible;
        }

        #section-to-print {
            position: absolute;
            left: 0;
            top: 0;
        }
    }
</style>
<h3 class="my-3">
    Detail <strong><?= $title; ?> Cabang <?= session()->get('branch'); ?> </strong>
</h3>
<div class="row layout-top-spacing">
    <div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
        <div class="row">
            <div class="col-xl-9" id="section-to-print">
                <div class="widget-content widget-content-area br-6">
                    <div class="col-sm-12 text-sm-right">
                        <h5 class="inv-list-number"><span class="inv-title">Nomor Invoice : </span>
                            <span class="inv-number"><b><?= $PurchaseOrders['purchase_order_invoice']; ?></b></span>
                        </h5>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-sm-8 mt-3">
                            <h6 class="inv-created-date"><span class="inv-title">Tanggal Transaksi : </span>
                                <span class="inv-date"><b><?= $PurchaseOrders['purchase_order_invoice_date']; ?></b></span>
                            </h6>
                        </div>
                        <div class="col-sm-4 mt-3 d-inline">
                            <h6 class="inv-created-date"><span class="inv-title">Dibuat Oleh : </span>
                                <span class="inv-date"><b><?= $PurchaseOrders['employee_name']; ?></b></span>
                            </h6>
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-xl-8 col-lg-7 col-md-6 col-sm-4 align-self-center">
                            <h6 class="inv-to"> <b> Nama Pemasok :</b></h6>
                        </div>
                        <div class="col-xl-4 col-lg-5 col-md-6 col-sm-8 align-self-center order-sm-0 order-1 inv--payment-info">
                            <h6 class=" inv-title"> <b>Status Pembayaran:</b> </h6>
                        </div>
                        <div class="col-xl-8 col-lg-7 col-md-6 col-sm-4">
                            <h2><?= $PurchaseOrders['supplier_company']; ?></h2>
                        </div>
                        <div class="col-xl-4 col-lg-5 col-md-6 col-sm-8 col-12 order-sm-0 order-1">
                            <div class="inv--payment-info">
                                <h2 class="font-weight-bold ">
                                    <?php if ($PurchaseOrders['purchase_order_status'] == 1) { ?>
                                        <span class="text-success"> DISETUJUI </span>
                                    <?php } else if ($PurchaseOrders['purchase_order_status'] == 2) { ?>
                                        <span class="text-danger"> DITOLAK </span>
                                    <?php } else if ($PurchaseOrders['purchase_order_status'] == 0) { ?>
                                        <span class="text-warning"> MENUNGGU </span>
                                    <?php } ?>
                                </h2>
                            </div>
                        </div>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-striped my-3">
                            <thead>
                                <tr class="text-center">
                                    <th>#</th>
                                    <th>Nama Produk</th>
                                    <th>Kuantitas</th>
                                    <th>Total pembayaran</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $i = 1;
                                foreach ($Products as $product) : ?>
                                    <tr class="text-center">
                                        <td><?= $i++; ?></td>
                                        <td><?= $product['purchase_order_product_name']; ?></td>
                                        <td><?= $product['purchase_order_quantity']; ?></td>
                                        <td>RP. <?= number_format($product['purchase_order_price']); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="row mt-4">
                        <div class="col-sm-12 col-12 order-sm-1 order-0 text-right">
                            <div class="text-sm-right">
                                <div class="row">
                                    <div class="col-sm-9 col-7 grand-total-title">
                                        <h5 class="">Cost : </h5>
                                    </div>
                                    <div class="col-sm-3 col-5 grand-total-amount">
                                        <h5>RP. <?= number_format($PurchaseOrders['purchase_order_cost']); ?></h5>
                                    </div>
                                    <div class="col-sm-9 col-7 grand-total-title">
                                        <h4 class="">Grand Total : </h4>
                                    </div>
                                    <div class="col-sm-3 col-5 grand-total-amount">
                                        <h4>RP. <?= number_format($PurchaseOrders['purchase_order_total']); ?></h4>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row mt-4">
                        <div class="col-sm-12 col-12 order-sm-0 order-1">
                            <h5>Note: </h5><?= $PurchaseOrders['purchase_order_notes']; ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3">
                <div class="widget-content widget-content-area br-6">
                    <div class="card-body">
                        <button class="btn btn-info btn-block mt-3 mr-2" value="print" onclick="PrintDiv()">Cetak/Print</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    function PrintDiv() {
        print();
    }
</script>

<?= $this->endSection(); ?>