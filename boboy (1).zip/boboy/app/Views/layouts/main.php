<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="Point of Sale Toko Mainan Boboy">
	<meta name="author" content="Codavlo Indonesia">
	<meta name="keywords" content="Codavlo Indonesia, bootstrap, point of sale, admin, dashboard, pos, boboy, toko mainan">


	<?php if (1 == session()->get('branch_id')) : ?>
		<link rel="icon" type="image/x-icon" href="<?= base_url('assets/img/logo_cikampek.jpeg') ?>" />
	<?php else : ?>
		<link rel="icon" type="image/x-icon" href="<?= base_url('assets/img/logotoko1.jpeg') ?>" />
	<?php endif; ?>
	<title><?= $title ?> | Toko Mainan Boboy</title>
	<!-- <link href="https://fonts.googleapis.com/css?family=Quicksand:400,500,600,700&display=swap" rel="stylesheet" /> -->
	<link href="<?= base_url('bootstrap/css/bootstrap.css') ?>" rel="stylesheet" type="text/css" />

	<link href="<?= base_url('assets/css/plugins.css') ?>" rel="stylesheet" type="text/css" />
	<link href="<?= base_url('assets/css/custom.css') ?>" rel="stylesheet" type="text/css" />
	<!-- <link href="<?= base_url('assets/css/scrollspyNav.css') ?>" rel="stylesheet" type="text/css" /> -->
	<link href="<?= base_url('assets/css/alert.css') ?>" rel="stylesheet" type="text/css">
	<link href="<?= base_url('assets/css/invoice-form.css') ?>" rel="stylesheet" type="text/css" />
	<link href="<?= base_url('assets/css/forms/theme-checkbox-radio.css') ?>" rel="stylesheet" type="text/css">
	<link href="<?= base_url('assets/css/dashboard.css') ?>" rel="stylesheet" type="text/css" />
	<link href="<?= base_url('plugins/table/datatable/datatables.css') ?>" rel="stylesheet" type="text/css">
	<link href="<?= base_url('plugins/table/datatable/custom_dt_html5.css') ?>" rel="stylesheet" type="text/css">
	<link href="<?= base_url('plugins/table/datatable/dt-global_style.css') ?>" rel="stylesheet" type="text/css">
	<link href="<?= base_url('plugins/bootstrap-select/bootstrap-select.min.css') ?>" rel="stylesheet" type="text/css">
	<link href="<?= base_url('plugins/flatpickr/flatpickr.css') ?>" rel="stylesheet" type="text/css">
	<link href="<?= base_url('plugins/flatpickr/custom-flatpickr.css') ?>" rel="stylesheet" type="text/css">
	<link href="<?= base_url('plugins/flatpickr/flatpickr.css'); ?>" rel="stylesheet" type="text/css">
	<script src="<?= base_url('assets/js/libs/jquery-3.6.0.js') ?>"></script>

</head>

<body style="background-image: url(<?= base_url('assets/img/background-1.jpeg') ?>);">

	<?php if ($segment != "cashier") : ?>
		<?= $this->include('layouts/topbar'); ?>
	<?php endif; ?>
	<div class="main-container">
		<div id="content" class="main-content">
			<div class="layout-px-spacing">
				<?php if ($segment != "cashier" && $segment != "home") : ?>
					<!-- <div class="page-header">
						<nav class="breadcrumb-one" aria-label="breadcrumb">
							<ol class="breadcrumb">
								<li class="breadcrumb-item">
									<a href="#"><?= $category; ?></a>
								</li>
								<li class="breadcrumb-item active" aria-current="page">
									<a href="#"><?= $title; ?></a>
								</li>
							</ol>
						</nav>
					</div> -->
				<?php endif; ?>
				<?= $this->include('common/alerts'); ?>
				<?= $this->renderSection('content'); ?>
			</div>
		</div>
	</div>
	<script src="<?= base_url('bootstrap/js/bootstrap.bundle.min.js') ?>"></script>
	<script src="<?= base_url('plugins/flatpickr/flatpickr.js'); ?>"></script>
	<script src="<?= base_url('plugins/perfect-scrollbar/perfect-scrollbar.min.js') ?>"></script>
	<script src="<?= base_url('assets/js/app.js') ?>"></script>
	<script>
		$(document).ready(function() {
			App.init();
		});
	</script>
	<script src="<?= base_url('assets/js/custom.js') ?>"></script>
	<!-- <script src="<?= base_url('assets/js/scrollspyNav.js') ?>"></script> -->
	<script src="<?= base_url('plugins/bootstrap-select/bootstrap-select.min.js') ?>"></script>
	<script src="<?= base_url('plugins/table/datatable/datatables.js') ?>"></script>
	<script src="<?= base_url('plugins/table/datatable/button-ext/dataTables.buttons.min.js') ?>"></script>
	<script src="<?= base_url('plugins/table/datatable/button-ext/jszip.min.js') ?>"></script>
	<script src="<?= base_url('plugins/table/datatable/button-ext/buttons.html5.min.js') ?>"></script>
	<script src="<?= base_url('plugins/table/datatable/button-ext/buttons.print.min.js') ?>"></script>
	<script>
		var currentDate = new Date();
		flatpickr(document.getElementsByClassName('basicFlatpickr'));
		flatpickr(document.getElementsByClassName("datePicker"), {
			defaultDate: currentDate,
		});

		$('.dataTable').DataTable({
			"dom": "<'dt--top-section'<'row'<'col-sm-12 col-md-6 d-flex justify-content-md-start justify-content-center'B><'col-sm-12 col-md-6 d-flex justify-content-md-end justify-content-center mt-md-0 mt-3'f>>>" +
				"<'table-responsive'tr>" +
				"<'dt--bottom-section d-sm-flex justify-content-sm-between text-center'<'dt--pages-count  mb-sm-0 mb-3'i><'dt--pagination'p>>",
			buttons: {
				buttons: [{
						extend: 'copy',
						className: 'btn btn-sm'
					},
					{
						extend: 'csv',
						className: 'btn btn-sm'
					},
					{
						extend: 'excel',
						className: 'btn btn-sm'
					},
					{
						extend: 'print',
						className: 'btn btn-sm'
					}
				]
			},
			"oLanguage": {
				"oPaginate": {
					"sPrevious": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-left"><line x1="19" y1="12" x2="5" y2="12"></line><polyline points="12 19 5 12 12 5"></polyline></svg>',
					"sNext": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-right"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>'
				},
				"sInfo": "Showing page _PAGE_ of _PAGES_",
				"sSearch": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-search"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>',
				"sSearchPlaceholder": "Search...",
				"sLengthMenu": "Results :  _MENU_",
			},
			"stripeClasses": [],
			"lengthMenu": [7, 10, 20, 50],
			"pageLength": 7
		});
		$('.dataTableNoButton').DataTable({
			"dom": "<'dt--top-section'<'row'<'col-12 col-sm-6 d-flex justify-content-sm-start justify-content-center'l><'col-12 col-sm-6 d-flex justify-content-sm-end justify-content-center mt-sm-0 mt-3'f>>>" +
				"<'table-responsive'tr>" +
				"<'dt--bottom-section d-sm-flex justify-content-sm-between text-center'<'dt--pages-count  mb-sm-0 mb-3'i><'dt--pagination'p>>",
			"oLanguage": {
				"oPaginate": {
					"sPrevious": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-left"><line x1="19" y1="12" x2="5" y2="12"></line><polyline points="12 19 5 12 12 5"></polyline></svg>',
					"sNext": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-right"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>'
				},
				"sInfo": "Showing page _PAGE_ of _PAGES_",
				"sSearch": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-search"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>',
				"sSearchPlaceholder": "Search...",
				"sLengthMenu": "Results :  _MENU_",
			},
			"stripeClasses": [],
			"lengthMenu": [7, 10, 20, 50],
			"pageLength": 7
		});
	</script>
</body>

</html>