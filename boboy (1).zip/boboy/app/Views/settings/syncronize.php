<?= $this->extend('layouts/main'); ?>
<?= $this->section('content'); ?>
<div class="card">
    <div class="card-body">
        <h4 class="card-title text-center mb-4"><b>Singkron Data Server</b></h4>
        <table class="table">
            <thead>
                <th>#</th>
                <th>Data</th>
                <th>Aksi</th>
            </thead>
            <tbody>
                <tr>
                    <td>1</td>
                    <td>Data Kategori Produk</td>
                    <td>
                        <a href="<?= base_url('sync/productCategory'); ?>" class="btn btn-primary">Upload</a>
                        <a href="<?= base_url('sync/productCategory?id=1'); ?>" class="btn btn-outline-primary">Download Data</a>
                    </td>
                </tr>
                <tr>
                    <td>2</td>
                    <td>Data Produk</td>
                    <td>
                        <a href="<?= base_url('sync/product'); ?>" class="btn btn-primary">Upload</a>
                        <a href="<?= base_url('sync/product?id=1'); ?>" class="btn btn-outline-primary" onclick="return confirm('Download data akan memakan waktu lama, pastikan internet anda stabil.')">Download Semua Data Barang</a>
                        <a href="<?= base_url('sync/product?id=2'); ?>" class="btn btn-outline-warning">Download Data Stock</a>
                    </td>
                </tr>
                <tr>
                    <td>3</td>
                    <td>Data Penjualan</td>
                    <td>
                        <a href="<?= base_url('sync/salesOrder'); ?>" class="btn btn-primary">Upload</a>
                    </td>
                </tr>
                <tr>
                    <td>4</td>
                    <td>Data Karyawan</td>
                    <td>
                        <a href="<?= base_url('sync/employee'); ?>" class="btn btn-primary">Upload</a>
                        <a href="<?= base_url('sync/employee?id=1'); ?>" class="btn btn-outline-primary">Download Data</a>
                    </td>
                </tr>
                <tr>
                    <td>5</td>
                    <td>Data Stock Transfer</td>
                    <td>
                        <a href="<?= base_url('sync/stockTransfer'); ?>" class="btn btn-primary">Upload</a>
                        <a href="<?= base_url('sync/stockTransfer?id=1'); ?>" class="btn btn-outline-primary">Download Data</a>
                    </td>
                </tr>
                <tr>
                    <td>6</td>
                    <td>Data Customer</td>
                    <td>
                        <a href="<?= base_url('sync/customer'); ?>" class="btn btn-primary">Upload</a>
                        <a href="<?= base_url('sync/customer?id=1'); ?>" class="btn btn-outline-primary">Download Data</a>
                    </td>
                </tr>
                <tr>
                    <td>7</td>
                    <td>Data Stock Opaname</td>
                    <td>
                        <a href="<?= base_url('sync/StockOpname'); ?>" class="btn btn-primary">Upload</a>
                        <a href="<?= base_url('sync/StockOpname?id=1'); ?>" class="btn btn-outline-primary">Download Data</a>
                    </td>
                </tr>
                <tr>
                    <td>8</td>
                    <td>Data Purchase Order</td>
                    <td>
                        <a href="<?= base_url('sync/PurchaseOrder'); ?>" class="btn btn-primary">Upload</a>
                        <a href="<?= base_url('sync/PurchaseOrder?id=1'); ?>" class="btn btn-outline-primary">Download Data</a>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>
<?= $this->endSection(); ?>