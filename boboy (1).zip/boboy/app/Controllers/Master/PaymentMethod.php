<?php

namespace App\Controllers\Master;

use App\Controllers\BaseController;
use App\Models\MasterModel;


class PaymentMethod extends BaseController
{
	function __construct()
	{
		$this->MasterModel = new MasterModel();
	}
	public function index()
	{
		$data = array_merge($this->data, [
			'category'		=> 'Master',
			'title'         => 'Tipe Pembayaran',
			'PaymentMethod'    => $this->MasterModel->getPaymentMethod()
		]);
		return view('master/paymentMethodList', $data);
	}
	public function createPaymentMethod()
	{
		$createPaymentMethod = $this->MasterModel->createPaymentMethod($this->request->getPost(null));
		if ($createPaymentMethod) {
			session()->setFlashdata('notif_success', '<b>Successfully added new Payment Method</b>');
			return redirect()->to(base_url('paymentMethod'));
		} else {
			session()->setFlashdata('notif_error', '<b>Failed to add new Payment Method</b>');
			return redirect()->to(base_url('paymentMethod'));
		}
	}
	public function updatePaymentMethod()
	{
		$updatePaymentMethod = $this->MasterModel->updatePaymentMethod($this->request->getPost(null));
		if ($updatePaymentMethod) {
			session()->setFlashdata('notif_success', '<b>Successfully update Payment Method</b>');
			return redirect()->to(base_url('paymentMethod'));
		} else {
			session()->setFlashdata('notif_error', '<b>Failed to update Payment Method</b>');
			return redirect()->to(base_url('paymentMethod'));
		}
	}
	public function deletePaymentMethod()
	{
		$deletePaymentMethod = $this->MasterModel->deletePaymentMethod($this->request->getPost('paymentMethodID'));
		if ($deletePaymentMethod) {
			session()->setFlashdata('notif_success', '<b>Successfully delete Payment Method</b>');
			return redirect()->to(base_url('paymentMethod'));
		} else {
			session()->setFlashdata('notif_error', '<b>Failed to delete Payment Method</b>');
			return redirect()->to(base_url('paymentMethod'));
		}
	}
}
