<?= $this->extend('layouts/main'); ?>
<?= $this->section('content'); ?>
<div class="row layout-top-spacing" id="cancel-row">
    <div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
        <div class="widget-content widget-content-area ">
            <div class="text-right">
                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#supplierForm">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-plus-circle">
                        <circle cx="12" cy="12" r="10"></circle>
                        <line x1="12" y1="8" x2="12" y2="16"></line>
                        <line x1="8" y1="12" x2="16" y2="12"></line>
                    </svg>
                    Tambah Supplier
                </button>
            </div>
            <div class="table-responsive">
                <table class="table table-striped dataTable" style="width:100%">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Perusahaan Supplier</th>
                            <th>Kontak</th>
                            <th>Nomor Telepon</th>
                            <th>Alamat Supplier</th>
                            <th class="no-content">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 1;
                        foreach ($Suppliers as $suppliers) : ?>
                            <tr>
                                <td><?= $i++; ?> </td>
                                <td><?= $suppliers['supplier_company'] ?> </td>
                                <td><?= $suppliers['supplier_contact'] ?> </td>
                                <td><?= $suppliers['supplier_telephone'] ?> </td>
                                <td><?= $suppliers['supplier_address'] ?>, <?= $suppliers['subdistrict_name'] ?>, <?= $suppliers['city_type'] ?> <?= $suppliers['city_name'] ?>, <?= $suppliers['province_name'] ?> </td>
                                <td>
                                    <button class="btn btn-primary btn-sm btnSupp" data-toggle="modal" data-target="#formUpdateSuppliersModal" data-id="<?= $suppliers['supplierID']; ?>" data-company="<?= $suppliers['supplier_company'] ?>" data-contact="<?= $suppliers['supplier_contact'] ?>" data-phone="<?= $suppliers['supplier_telephone'] ?>" data-address="<?= $suppliers['supplier_address'] ?>" data-city="<?= $suppliers['city'] ?>" data-province="<?= $suppliers['province'] ?>" data-subdistrict="<?= $suppliers['subdistrict_id'] ?>">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-edit">
                                            <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                                            <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                                        </svg> Ubah
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Modal Create Product -->
<div class="modal fade" id="supplierForm" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="supplierFormLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="supplierFormLabel">Tambah Data Supplier</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
            </div>
            <div class="modal-body">
                <form action="<?= base_url('suppliers/createSuppliers'); ?>" method="post">
                    <div class="form-group">
                        <label for="inputSupplierCompany">Perusahaan Supplier</label>
                        <input type="text" class="form-control" name="inputSupplierCompany" id="inputSupplierCompany" required>
                    </div>
                    <div class="form-group">
                        <label for="inputSupplierContact">Kontak</label>
                        <input type="text" class="form-control" name="inputSupplierContact" id="inputSupplierContact" required>
                    </div>
                    <div class="form-group">
                        <label for="inputSupplierTelephone">Nomor Telepon</label>
                        <input type="text" class="form-control" name="inputSupplierTelephone" id="inputSupplierTelephone" required>
                    </div>
                    <div class="form-group">
                        <label for="inputSupplierAddress">Alamat Pemasok</label>
                        <input type="text" class="form-control" name="inputSupplierAddress" id="inputSupplierAddress" required>
                    </div>
                    <div class="row">
                        <div class="col-4">
                            <div class="form-group Province">
                                <label for="inputSupplierProvince">Provinsi</label>
                                <select id="Province" name="inputSupplierProvince" class="form-control selectpicker provinceID" data-live-search="true" required>
                                    <option selected>Pilih Provinsi...</option>
                                    <?php foreach ($Province as $province) : ?>
                                        <option value="<?= $province['id']; ?>"><?= $province['province_name']; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-4" id="form_City">
                            <div class="form-group">
                                <label for="inputSupplierCity">Kabupaten/Kota</label>
                                <select id="city" name="inputSupplierCity" class="form-control " required>
                                    <option selected>Pilih Kabupaten/Kota...</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-4" id="form_Subdistrict">
                            <div class="form-group">
                                <label for="inputSupplierSubdistrict">Kecamatan</label>
                                <select id="subdistrict" name="inputSupplierSubdistrict" class="form-control" required>
                                    <option selected>Pilih Kecamatan...</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn" data-dismiss="modal"><i class="flaticon-cancel-12"></i> Kembali</button>
                        <button type="submit" class="btn btn-primary">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Modal Update Branch -->
<div class="modal fade" id="formUpdateSuppliersModal" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="formUpdateSuppliersModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="formUpdateSuppliersModalLabel">Ubah Data Cabang</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
            </div>
            <div class="modal-body">
                <form action="<?= base_url('suppliers/updateSuppliers'); ?>" method="post">
                    <input type="hidden" id="idSupplier" name="supplierID">
                    <div class="form-group">
                        <label for="inputSupplierCompany">Perusahaan Pemasok</label>
                        <input type="text" class="form-control" name="inputSupplierCompany" id="companySupplier" required>
                    </div>
                    <div class="form-group">
                        <label for="inputSupplierContact">Kontak</label>
                        <input type="text" class="form-control" name="inputSupplierContact" id="contactSupplier" required>
                    </div>
                    <div class="form-group">
                        <label for="inputSupplierTelephone">Nomor Telepon</label>
                        <input type="text" class="form-control" name="inputSupplierTelephone" id="phoneSupplier" required>
                    </div>
                    <div class="form-group">
                        <label for="inputSupplierAddress">Alamat Pemasok</label>
                        <input type="text" class="form-control" name="inputSupplierAddress" id="addressSupplier" required>
                    </div>
                    <div class="row">
                        <div class="col-4 ProvinceUpdate">
                            <div class="form-group Province_Update">
                                <label for="inputSupplierProvince">Provinsi</label>
                                <select id="provinceSupplier" name="inputSupplierProvince" class="form-control selectpicker btnselect provinceSelect" data-live-search="true" required>
                                    <option selected>Pilih Provinsi...</option>
                                    <?php foreach ($Province as $province) : ?>
                                        <option value="<?= $province['id']; ?>"><?= $province['province_name']; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-4" id="form_City_Update">
                            <div class="form-group">
                                <label for="inputSupplierCity">Kabupaten/Kota</label>
                                <select id="cityUpdate" name="inputSupplierCity" class="form-control " required>
                                    <option selected>Pilih Kabupaten/Kota...</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-4" id="form_Subdistrict_Update">
                            <div class="form-group">
                                <label for="inputSupplierSubdistrict">Kecamatan</label>
                                <select id="subdistrictUpdate" name="inputSupplierSubdistrict" class="form-control" required>
                                    <option selected>Pilih Kecamatan...</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn" data-dismiss="modal"><i class="flaticon-cancel-12"></i> Kembali</button>
                        <button type="submit" class="btn btn-primary">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>



<script>
    $(' .btnSupp').click(function() {
        const supplier_id = $(this).data("id");
        const supplier_company = $(this).data("company");
        const supplier_contact = $(this).data("contact");
        const supplier_phone = $(this).data("phone");
        const supplier_address = $(this).data("address");
        const supplier_province = $(this).data("province");
        const supplier_city = $(this).data("city");
        const supplier_subdistrict = $(this).data("subdistrict");

        // // console.log(supplier_id);
        // // console.log(supplier_company);
        // // console.log(supplier_contact);
        // // console.log(supplier_phone);
        // // console.log(supplier_address);
        // // console.log(supplier_province);
        // // console.log(supplier_city);
        // // console.log(supplier_subdistrict);


        $('#idSupplier').val(supplier_id);
        $('#companySupplier').val(supplier_company);
        $('#contactSupplier').val(supplier_contact);
        $('#phoneSupplier').val(supplier_phone);
        $('#addressSupplier').val(supplier_address);
        $('#provinceSupplier').val(supplier_province);
        $('#citySupplier').val(supplier_city);
        $('#subdistrictSupplier').val(supplier_subdistrict);
    });
    $(document).ready(function() {

        $('.Province').on('change', ".provinceID", function() {
            const provinsi = $("#Province").val();

            $.ajax({
                url: "<?= base_url('customers/getCity'); ?>",
                method: "POST",
                type: 'JSON',
                data: {
                    province: provinsi,
                },
                success: function(result) {
                    $("#city").html(result);
                }
            });
        });
        $('#form_City').on('change', "#city", function() {
            const kota = $("#city").val();

            $.ajax({
                url: "<?= base_url('customers/getSubdistrict'); ?>",
                method: "POST",
                type: 'JSON',
                data: {
                    city: kota,
                },
                success: function(result) {

                    $("#subdistrict").html(result);
                }
            });
        });
        $(document).ready(function() {
            $('.ProvinceUpdate').on('change', ".provinceSelect", function() {
                const provinsiUpdate = $("#provinceSupplier").val();

                $.ajax({
                    url: "<?= base_url('customers/getCity'); ?>",
                    method: "POST",
                    type: 'JSON',
                    data: {
                        province: provinsiUpdate,
                    },
                    success: function(result) {
                        $("#cityUpdate").html(result);
                    }
                });
            });
            $('#form_City_Update').on('change', "#cityUpdate", function() {
                const kotaUpdate = $("#cityUpdate").val();
                $.ajax({
                    url: "<?= base_url('customers/getSubdistrict'); ?>",
                    method: "POST",
                    type: 'JSON',
                    data: {
                        city: kotaUpdate,
                    },
                    success: function(result) {
                        $("#subdistrictUpdate").html(result);
                    }
                });
            });
        });
    });
</script>
<?= $this->endSection(); ?>