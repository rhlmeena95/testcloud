<?= $this->extend('layouts/main'); ?>
<?= $this->section('content'); ?>
<h3 class="my-3">
    <strong><?= $title; ?> Cabang <?= session()->get('branch'); ?> </strong>
</h3>
<div class="row layout-top-spacing" id="cancel-row">
    <div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
        <div class="row">
            <div class="col-xl-12">
                <div class="widget-content widget-content-area br-6">
                    <div class="col-sm-12 text-sm-center">
                        <h3 class="inv-list-number"><span class="inv-title">Persetujuan Permintaan Barang </span></h3>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-sm-8 mt-3">
                            <h6 class="inv-created-date"><span class="inv-title">Tanggal Pembuatan : </span> <br><br>
                                <span class="inv-date"><b><?= $StockTransfer['request_at']; ?></b></span>
                            </h6>
                        </div>
                        <div class="col-sm-4 mt-3 d-inline">
                            <h6 class="inv-created-date"><span class="inv-title">Dibuat Oleh : </span> <br><br>
                                <span class="inv-date"><b><?= $StockTransfer['employee_name']; ?></b></span>
                            </h6>
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-xl-8 col-lg-7 col-md-6 col-sm-4 align-self-center">
                            <h6 class="inv-to"> <b> Nama Cabang :</b></h6>
                        </div>
                        <div class="col-xl-4 col-lg-5 col-md-6 col-sm-8 align-self-center order-sm-0 order-1 inv--payment-info">
                            <h6 class=" inv-title"> <b>Status Barang:</b> </h6>
                        </div>
                        <div class="col-xl-8 col-lg-7 col-md-6 col-sm-4">
                            <h2><?= $StockTransfer['branch_name']; ?></h2>
                        </div>
                        <div class="col-xl-4 col-lg-5 col-md-6 col-sm-8 col-12 order-sm-0 order-1">
                            <div class="inv--payment-info">
                                <h2 class="font-weight-bold ">
                                    <?php if ($StockTransfer['status'] == 1) { ?>
                                        <span class="text-warning"> DIKIRIM </span>
                                    <?php } else if ($StockTransfer['status'] == 2) { ?>
                                        <span class="text-success"> DITERIMA </span>
                                    <?php } else if ($StockTransfer['status'] == 0) { ?>
                                        <span class="text-warning"> MEMINTA </span>
                                    <?php } ?>
                                </h2>
                            </div>
                        </div>
                    </div>
                    <div class="table-responsive my-3">
                        <table class="table table-bordered">
                            <thead>
                                <tr class="text-center">
                                    <th>#</th>
                                    <th>Nama Produk</th>
                                    <th>Kuantitas</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $i = 1;
                                foreach ($StockTransferProducts as $product) : ?>
                                    <tr class="text-center">
                                        <td><?= $i++; ?></td>
                                        <td><?= $product['stock_transfer_product_name']; ?></td>
                                        <td><?= $product['stock_transfer_product_quantity']; ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                        <div class="text-center">
                            <?php if ($StockTransfer['status'] == 0) : ?>
                                <form action="<?= base_url('stockTransfer/saveConfirmation'); ?>" method="post">
                                    <input type="hidden" name="stockTransferID" value="<?= $StockTransfer['stockTransferID']; ?>">
                                    <button type="submit" class="btn btn-success btn-lg mt-3" value="1" name="inputStockTransferStatus" onclick="return confirm('Apakah Semua Barang Sudah Di terima?')">Setujui Permintaan</button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?= $this->endSection(); ?>