<?php

namespace App\Controllers\Report;

use App\Models\MasterModel;
use App\Models\PurchasingModel;
use App\Controllers\BaseController;

class TransactionPurchase extends BaseController
{
	function __construct()
	{
		$this->PurchasingModel = new PurchasingModel();
		$this->MasterModel = new MasterModel();
	}
	public function index()
	{
		$branch = $this->request->getGet('branch');
		$month = $this->request->getGet('m');
		$years = $this->request->getGet('y');
		if ($branch && $years) {
			$Purchasing = $this->PurchasingModel->getPurchaseOrderBranchandMonth($branch, $month, $years);
		} else {
			$Purchasing = $this->PurchasingModel->getPurchaseOrderByMonth($month, $years);
		}
		$data = array_merge($this->data, [
			'category'     		=> 'Laporan',
			'title'        		=> 'Transaksi Pembelian',
			'PurchaseOrders' 	=> $Purchasing,
			'Branch'    		=> $this->MasterModel->getBranch(),
			'inputBranch'		=> $branch,
			'month'				=> $month,
			'years'				=> $years,
			'yearsNow'			=> date('Y')
		]);
		// \dd($data);
		return view('report/transactionPurchase', $data);
	}
}
